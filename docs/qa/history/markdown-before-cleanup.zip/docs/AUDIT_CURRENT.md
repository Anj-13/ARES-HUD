> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

# Current independent audit ? 14 November 2026

Baseline: `0036eac` (Nov-14: update the map), initially clean tracked worktree. Root README.md and STATUS.md were missing; other-agent copies were in docs/status-from-otheragent/. No evidence of ongoing simultaneous edits was observed. Previous commit claims ae0cc4a/a2c4abd do not appear in inspected local git log and were not accepted as evidence.

## Phase A / Task 0 verdict

- A1 VERIFIED: parsed capabilities, levels 0?12. Width=2^(L+1), height=2^L; level 12 is 8192x4096, tiles 256px.
- A2 VERIFIED: at levels 10/11/12, degrees/pixel 0.0006866455078125 / 0.00034332275390625 / 0.000171661376953125. North-south m/pixel 40.700705 / 20.350352 / 10.175176; east-west at 18.5 N 38.597441 / 19.298721 / 9.649360. Radius 3,396,190 m, degree=59,274.6975 m. Matches prior rounded table.
- A3 VERIFIED: fresh NASA Trek requests 11/814/2929 and 12/1628/5858: HTTP 200, valid PNG signatures, 58,137 and 55,135 bytes.
- A4 VERIFIED: old block west/east 77.16796875/77.87109375, south/north 18.45703125/19.16015625. USGS overlap 0.63203125 x 0.24296875 degrees = 15.356384% of its 1x1-degree extent. This old block is not the current cache: current manifest has 24 tiles across levels 10?12, 1,356,690 bytes; all hashes match.
- A5 PARTIAL: freshly fetched 36 level-11 tiles, rows 811?816/columns 2926?2931; CTX contact sheet viewed. Western channel and fan are visually confirmed by the agent (not measured and never pixel-color registration). THEMIS image inspected; precise fan correspondence not confidently established. USGS PDF-page comparison was not repeated; do not certify the full A5 acceptance.
- B1 VERIFIED by scan: inspected text decodes UTF-8; no replacement characters or Markdown question-mark punctuation candidates detected. Terminal mojibake alone was not treated as file corruption.
- B2 VERIFIED: .browser-qa/ appears in .gitignore; folder retained.
- B3 VERIFIED: existing dust narrative, accessible marker and injected no-route checks pass in fresh browser runs.
- B4: no application/doc edits before audit report. Prior Task 0 versus 0D change attribution cannot be reconstructed from the old reports' nonexistent local commit IDs.

## Executed validation

`npm.cmd test`: 22 passed, 0 failed: 8 pathfinding, 5 mission, 9 geo tests. `node --check` across all 19 discovered .js/.mjs files excluding node_modules/.browser-qa/.git: no failures.

Headless Microsoft Edge, HTTP server port 8011, virtual-time budget 45000ms. Desktop viewport 1280x1000: initial PASS 49; reported boot failure did not reproduce. Initial narrow run: 45 pass/4 fail due to fixed zoom-12 expectations; explicit 360px run also exposed hard-coded level-12 tile expectations. Corrected only browser-test.html: assert initial fit contains sector without native overzoom, expected cached level follows fitted zoom, reset restores fitted zoom, keyboard zoom compares to prior fitted zoom. Preserved other projection, routing and error checks.

Final runs: desktop PASS 49/49; explicit iframe width 360 CSS px PASS 49/49. Actual evidence in ignored .browser-qa/verified-desktop.html and verified-mobile.html. Harness disables cosmetic animation and wraps panBy to observe keyboard calls; not a physical touch-device test. Images decode and missing-tile routing fallback is exercised. Scientific labels and persistent disclaimer pass existing harness assertions. No tablet exists to test.

## Documentation repair

Restored root README.md and authoritative STATUS.md. Updated architecture baseline without rewriting working code. Preserved older reports under historical banners; updated changelog from actual git log. Existing Option 2 was already selected, so AGENT_RULES_ADDENDUM.md was not changed. Task 0D remains conservatively IN PROGRESS until remaining historical finding-by-finding reconciliation is reviewed. Task 1 code is present and browser regression is green; no reimplementation was needed and no new feature was started.

Changed: browser-test.html; root README.md/STATUS.md; docs/ARCHITECTURE.md, CHANGELOG.md, QA_REPORT.md, FIX_REPORT.md, TEST_REPORT.md, INTEGRATION_REPORT.md, RESOURCE_GAP_AUDIT.md, ARES_HUD_ONE_DAY_AUDIT.md, BUILD_TONIGHT.md, MAP_ARCHITECTURE.md, TASK_0_REPORT.md, TASK_0D_REPORT.md, TASK_1_REPORT.md; historical banners on the three docs/status-from-otheragent/*.md files; this audit and docs/README.md navigation.

## Provenance and limits

Existing asset hashes verified, no production assets or dependencies added. Temporary contact-sheet tiles are under ignored .browser-qa/contact/. Exact source is the existing manifest's Jezero_CTX_BlockAdj_dd WMTS endpoint, default/default028mm; source/credit records retained unchanged in DATA_SOURCES.md. Test-only downloads are not shipped.

No staging, commits, pushes, deployment or submission. Commit reference remains 0036eac. Browser-test.html and Markdown are ignored by repository rules; ordinary git status does not show these edits. This is deliberate compliance with the owner's no-commit instruction, not proof of no edits.

Remaining: full A5 PDF comparison, full historical finding-by-finding reconciliation, public deployment and tablet/timeline/fog/globe work. Do not use this report to claim all requested phases completed. Code/source tests and registered-map browser checks are green; scientific route costs remain simulated.
