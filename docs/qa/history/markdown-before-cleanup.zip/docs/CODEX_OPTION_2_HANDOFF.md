# Codex handoff — Option 2 approved (15 November 2026)

## Run first: Documentation agent — GPT-6.1 Sol

Read AGENTS.md, AGENT_RULES_ADDENDUM.md, FEATURE_PLAN.md and AGENT_TASKS.md. Execute Task 0D documentation reconciliation on the actual repository, after checking whether Task 0 preflight is already green. Establish STATUS.md using verified code, test results and git history. Separate README.md and ARCHITECTURE.md into current implementation and migration target; correct stale NASA asset, test-count and deployment claims. Mark old QA/integration/build reports HISTORICAL with evidence tags, and inventory redundant documents. Do not delete historical evidence or source provenance without owner approval; propose an archive list instead. Do not edit application code. Check Markdown links, UTF-8, and commit Markdown with git add -f. Report actual commands, evidence and remaining gaps. Note that Option 2 is selected: Sunday 15 November 2026 16:00 GMT code freeze, Tier B approved after Tier A is verified.

## Then: Implementation agent — GPT-6 Astra (fresh session)

Read AGENTS.md, AGENT_RULES_ADDENDUM.md, FEATURE_PLAN.md, AGENT_TASKS.md, STATUS.md and actual repository files. Follow the Common header in AGENT_TASKS.md. Do not reimplement verified tasks. Complete Task 0 if needed, then Task 1 (registered Leaflet Mars Trek map), then Task 3 (Send to Tablet). Run tests, node --check and browser verification; update STATUS.md and commit after each green task. Only after Tier A is green, execute Task 2 (Sol timeline), then Task 6 (simulated reconnaissance Fog of War), subject to the Sunday 13:30 GMT feature cutoff. Do not begin any new features after that cutoff. Task 5 is limited to a 60-minute verification spike; elevation-based routing requires separately verified numeric data and explicit further owner approval. Keep the application static and all NASA assets local, preserve pathfinding purity, and do not invent geospatial measurements. Follow the release gates: 14:30 dependency/data freeze, 15:15 public URL verification, 15:45 final commit, 16:00 code freeze. If a task fails acceptance or exceeds its stop point, revert to the last green commit. At each stage provide the report format from AGENT_RULES_ADDENDUM.md. Do not claim tests, deployment or features succeeded without executing checks.

## Release after code freeze

After 16:00 GMT and before the verified event-local 23:59 deadline: produce a maximum 30-second demo video, verify the public application in a private window, complete source and AI-assistant References disclosures, and submit the project in the NASA Space Apps portal before the event-local deadline. Do not assume a deployment exists unless verified.

## v0.3 owner extension - planning only

Task 7 adds Planetary Mode only, dependent on verified Task 1. Follow its 60-minute verification spike and STOP for separate owner renderer/dependency/asset and full-implementation go/no-go. Protect Tier A and B and the 13:30 feature cutoff. The 3D vision is not an implementation instruction; retain direct 2D fallback and the no-new-build policy. See [Task 7](AGENT_TASKS.md#task-7---3d-mars-globe) and [STATUS.md](../STATUS.md).
