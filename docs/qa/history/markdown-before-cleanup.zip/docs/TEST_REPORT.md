> HISTORICAL EVIDENCE: prior report, not current acceptance. [UNVERIFIED] Old test/commit claims unless independently repeated in [AUDIT_CURRENT.md](AUDIT_CURRENT.md). [STATUS.md](../STATUS.md) controls current migration status.

> STATUS: HISTORICAL - describes baseline af9ac9e on 14 November 2026. Superseded by [STATUS.md](../STATUS.md). Finding tags were checked on 14 November 2026. Original timings and claimed checks are retained, not rerun.

## Task 0D reconciliation annotations — rechecked 14 November 2026

- **[RESOLVED] H1 / missing NASA imagery:** 24 genuine local CTX tiles at levels 10–12, source manifest hashes and two NASA reference JPEGs verified. Fresh level-11/12 requests return 200 PNG. Challenge/team eligibility is a separate owner submission check.
- **[OPEN] H2 / public acceptance:** local Edge desktop/narrow/keyboard and static-build tests pass; public URL, deployed revision, private-window and physical-device acceptance remain unverified.
- **[RESOLVED] M1 / no-route UI:** original and React browser harnesses exercise a blocked grid/plan, show unavailable results, omit an active route and recover after reset.
- **[RESOLVED] M2 / identical-endpoint narrative:** browser-checked dust state says no detour is needed at an identical endpoint; other no-route/unchanged/detour states have conditional copy.
- **[RESOLVED] L2 / marker sizing:** every Hab/science native button measures 44 × 44 CSS px at desktop and 360 px; map projection checks pass after pan at three zooms.
- **[RESOLVED] L1 / stale handoff wording:** current README/STATUS identify the React working tree over real local Git history. No freeze tag, new commit or public deployment is invented.
- **[RESOLVED] Registered imagery / documentation baseline:** source matrix, 4 km sector, coordinates, distances, CTX/PDF comparison and local Markdown links rechecked. Eight/14/22/33-test and 16-tile claims below are historical only; current suite is 39 passing tests and cache is 24 tiles.
- **[OPEN] Numeric terrain / geology geometry:** no verified numeric DEM, slope, unit-to-grid overlay or operational safety model. The separately displayed USGS educational map is not a routing raster.
- **[UNVERIFIED] Original run metadata / official submission:** old timing, unavailable commit IDs, event portal, registration, official-guide and submission claims remain archival; fresh evidence does not retrospectively certify them.

Full finding-by-finding evidence, historical commit validation and comparison limits: [baseline closure report](BASELINE_CLOSURE_REPORT.md). [STATUS.md](../STATUS.md) alone records acceptance. The original record follows; its original present-tense statements and numeric results describe its historical revision.

# Test report

Reviewed 14 November 2026; application baseline `af9ac9e`. No application/test source changed in this pass.

## Checks executed in this review

| Check | Result |
| --- | --- |
| node --test pathfinding.test.js | PASS: 8 tests, 0 failures, 0 skipped/cancelled; approximately 583 ms |
| node --check app.js | PASS: no syntax diagnostics |
| node --check pathfinding.js | PASS: no syntax diagnostics |
| Source/history review | All application/test files, package configuration, license, three available commits and supplied QA/fix reports inspected |

Tests cover straight/diagonal costs, deterministic symmetric detour, enclosed goal, blocked endpoints/empty grid, corner cutting, deterministic dust reroute/return, penalty avoidance/negative clamping and identical endpoints. No line/branch coverage percentage was measured.

## Prior reported checks

[QA_REPORT.md](QA_REPORT.md) records Node/npm test passes, syntax checks and an in-memory DOM stub exercising initial state, dust, arrival, return, clearing and reset. The stub was not rerun here and is not browser rendering/event-dispatch verification.

[FIX_REPORT.md](FIX_REPORT.md) records another eight-test npm pass and syntax passes. Both reports record npm.cmd run build failing because no build script exists. Source files are served directly; this is not a successful compiled-build verification. QA reports unavailable Playwright/Puppeteer and failed official-page fetches; these were not repeated here.

## Outstanding issues

| Finding | Status |
| --- | --- |
| [RESOLVED: local NASA assets now present] H1 NASA resource absent | Confirmed by source/register; no NASA observation used |
| [OPEN: see reconciliation] H2 public/browser evidence absent | No verified URL; hosting, MIME, console/network and private-window acceptance outstanding |
| [RESOLVED: current browser evidence] M1 no-route UI | Algorithm cases pass; supplied controls cannot create disconnection; render integration untested |
| [RESOLVED: current browser evidence] M2 arrival narrative | Correct arrival status, but dust copy still describes route comparison for single-point routes |
| [RESOLVED: current README] L1 stale repository wording | README corrected in this pass; final freeze tag not recorded |
| [RESOLVED: current browser evidence] L2 marker sizing | Source requests 32 px height but generic button minimum is 44 px; browser appearance unverified |

No browser, mobile, screen-reader, accessibility scanner, public HTTP or security scanner check was executed in this pass. No exhaustive independent optimality comparison, performance benchmark or full malformed-input suite exists in supplied tests.

Before release, verify desktop and 320/375 px layouts, keyboard controls/focus, live announcements, route readability, scenario controls and console/network on a hosted URL. Exercise no-route rendering in a harness. Owner private-window acceptance and NASA integration remain outstanding.

Passing routing tests does not validate astronaut safety. ARES-HUD is a conceptual prototype, not flight-qualified navigation software.
