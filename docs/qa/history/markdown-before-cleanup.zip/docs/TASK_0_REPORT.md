> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

> HISTORICAL EVIDENCE: prior report, not current acceptance. [UNVERIFIED] Old test/commit claims unless independently repeated in [AUDIT_CURRENT.md](AUDIT_CURRENT.md). [STATUS.md](../STATUS.md) controls current migration status.

> STATUS: CURRENT - Task 0 preflight evidence, recorded 14 November 2026 on the working tree below. Findings supersede the "not verified" Task 0 notes in [STATUS.md](../STATUS.md). Browser checks were run in headless Microsoft Edge on this machine; no public host was tested.

# Task 0 report — preflight (verification, hygiene, no new features)

Baseline before this task: HEAD `a2c4abd` plus the documented dirty prototype tree (uncommitted app.js, index.html, styles.css, package.json; untracked mission.js, datasets.js, exploration.js, mission.test.js, browser-test.html, assets/). Tests at start: `npm.cmd test` → 14 passed, 0 failed. `node --check` passed on all seven root `.js` files.

## A. Tile layer verification (numbers as run, not assumed)

### A1. Tile matrix levels in `assets/trek-capabilities.xml`

Layer `Jezero_CTX_BlockAdj_dd`, TileMatrixSet `default028mm`, TopLeftCorner -180/90, 256 px tiles.

| Level | MatrixWidth | MatrixHeight | ScaleDenominator |
| --- | --- | --- | --- |
| 0 | 2 | 1 | 2.7922763629807472E+08 |
| 1 | 4 | 2 | 1.3961381814903736E+08 |
| 2 | 8 | 4 | 6.9806909074518681E+07 |
| 3 | 16 | 8 | 3.4903454537259340E+07 |
| 4 | 32 | 16 | 1.7451727268629670E+07 |
| 5 | 64 | 32 | 8.7258636343148351E+06 |
| 6 | 128 | 64 | 4.3629318171574175E+06 |
| 7 | 256 | 128 | 2.1814659085787088E+06 |
| 8 | 512 | 256 | 1.0907329542893544E+06 |
| 9 | 1024 | 512 | 5.4536647714467719E+05 |
| 10 | 2048 | 1024 | 2.7268323857233860E+05 |
| 11 | 4096 | 2048 | 1.3634161928616930E+05 |
| 12 | 8192 | 4096 | 6.8170809643084649E+04 |

**Deepest declared level: 12 (8192 x 4096). Confirmed as expected.** This is the matrix the capabilities document declares; it is not proof that every tile exists.

### A2. Tile geometry at 18.5 N (Mars 2000 sphere radius 3,396,190 m; 1 degree = 59,274.6975 m)

| Level | Tile size (deg) | Deg/px | m/px north-south | m/px east-west (x cos 18.5) |
| --- | --- | --- | --- | --- |
| 10 | 0.17578125 | 0.0006866455078125 | 40.70 | 38.60 |
| 11 | 0.087890625 | 0.00034332275390625 | 20.35 | 19.30 |
| 12 | 0.0439453125 | 0.000171661376953125 | 10.18 | 9.65 |

### A3. Live tile requests near 18.45 N, 77.45 E (14 November 2026, ~15:20 GMT)

Template `.../1.0.0/default/default028mm/{level}/{row}/{col}.png`:

| Request | Tile bounds (approx.) | HTTP | Content-Type | Bytes | PNG signature |
| --- | --- | --- | --- | --- | --- |
| Level 11, row 814, col 2929 | 18.457-18.369 N, 77.451-77.539 E | 200 | image/png | 58,137 | yes |
| Level 12, row 1628, col 5858 | 18.459-18.415 N, 77.451-77.495 E | 200 | image/png | 55,135 | yes |

Level 11 rows 811-812, col 2929 also returned 200 image/png (64,785 and 63,018 bytes). No new tiles were added to the repository. This is a point-in-time availability check for those tiles, not a guarantee for the service.

### A4. Cached block versus USGS SIM 3464 coverage

Cached level 10, rows 403-406, columns 1463-1466 (16 tiles):

- North 19.16015625 N, south 18.45703125 N, west 77.16796875 E, east 77.87109375 E.
- USGS sheet extent: 76.8-77.8 E, 17.7-18.7 N.
- Overlap: longitude 77.16796875-77.8 = **0.63203 deg (63.2 % of the USGS longitude span)**; latitude 18.45703125-18.7 = **0.24297 deg (24.3 % of the USGS latitude span)**; area overlap **about 15.4 %** of the stated USGS extent.
- The cached block is therefore offset north inside the USGS sheet: it starts 0.757 deg north of the sheet's south edge.

### A5. Visual delta check (agent observation, not measurement, not registration)

Downloaded 36 level-11 tiles (rows 811-816, columns 2926-2931) to a temporary folder, assembled a 1536 x 1536 contact sheet without reprojection: extent 18.720703125-18.193359375 N, 77.16796875-77.6953125 E. Kept outside the repository.

- **The Jezero delta is clearly visible** in the contact sheet: a branching inflow channel enters from the west and opens into a lobate fan with layered mesas, in the upper-left/centre of the sheet. By tile position that feature sits roughly at 18.45-18.6 N and 77.3-77.5 E; this is a visual estimate from the tile grid, not a measured coordinate.
- **Cached block:** its south edge (18.45703125 N) runs through that latitude range, so the cached 16 tiles include the northern part of the delta and **clip its southern edge**. Delta fragments south of about 18.457 N are not cached.
- **PIA23386 (`assets/jezero-themis.jpg`)**: the rotated THEMIS strip shows the crater rim and floor, but the delta fan is not confidently identifiable in that rendering and its footprint is not established. Comparison is qualitative only.
- **USGS SIM 3464 page-2 sketch** (image extracted from the local PDF): line-art crater outline with the western fan/fringe units inside the northwest part of the crater, consistent with the CTX evidence in style and placement. The sketch is a separate coordinate system and was not overlaid.

Deepest declared level is 12; the cached delivery level is 10.

## B. Hygiene changes

1. **Encoding artefacts fixed:** five literal "?" placeholders replaced with real characters — one in `app.js` (sequence separator now "·") and four in `index.html` (geology panel heading and three unit options now "—"). Scanned `app.js`, `index.html`, `datasets.js`, `exploration.js`, `mission.js`, both test files, `README.md`, `docs/DATA_SOURCES.md`, `docs/RESOURCE_GAP_AUDIT.md`, `docs/assets/README.md`: no remaining "?" used as punctuation. All files are UTF-8.
2. **`.browser-qa/` added to `.gitignore`** (folder does not currently exist; nothing deleted).
3. **QA M2 (dust narrative at identical endpoints) fixed.** The scenario copy is now conditional: identical start/destination, no selected stops, no route with the hazard, no pre-hazard route, unchanged route, or genuine detour each get their own sentence. Previously it always claimed a dashed pre-hazard line and a recomputed route.
4. **QA L2 (science pin size) fixed.** The pin was 32 px wide but stretched to the generic 44 px `min-height`, so it rendered as an ellipse. It is now `width/height/min-width/min-height: 44px`, a true circle at the same anchor.
5. **QA M1 (no-route UI) covered.** `app.js` exposes a test-only grid override (`window.__aresHudTest`); `browser-test.html` injects an all-blocked 40 x 40 grid, checks the status reads "No route available", checks the details text explains the blocked/no-connection case, and checks routing returns after the override is cleared.
6. Sequence list double numbering (`1. 1. Science`) removed; the `<ol>` now supplies the number.
7. **Harness timing:** the harness's fixed wait before the first check was raised from 1.5 s to 3 s after one run out of four failed the tile-decode check on a slow load. Three consecutive runs then passed. The decode check still depends on local load time; a failure means "images not ready", not "tiles broken".

## Commands run and results

- `npm.cmd test` → 14 tests, 14 pass, 0 fail.
- `node --check` on app.js, datasets.js, exploration.js, mission.js, mission.test.js, pathfinding.js, pathfinding.test.js → all OK.
- Headless Edge (`--headless=new`, `--dump-dom`, 1280 px) on `http://127.0.0.1:8000/browser-test.html`: **PASS: 21 browser checks** (15 existing + 6 new), including the three new hygiene checks and the no-route injection; three consecutive passes after the timing fix above.
- Headless Edge screenshots inspected: 1280 px desktop (orbital tiles, planner, 44 px pin) and a 360 px-wide iframe render (single column, wrapped toolbar, no horizontal overflow; `document.scrollWidth` 345 at `innerWidth` 360).

## NOT verified

- Public deployment, mobile touch devices, screen readers, real 360 px hardware viewport, PDF plugin rendering, keyboard traversal of the new hazard copy beyond button focus order.
- No elevation/slope, no geographic registration of the EVA grid, no metric distance. The coverage numbers above are derived from the WMTS matrix, not from a georeferenced mosaic.
- The Tier A migration (Leaflet registered map) has not started; nothing in this task is a Leaflet or registered-map implementation.

## Labels and disclaimers checked

OBSERVED: Trek CTX tiles and both NASA JPEGs; DERIVED: tile longitude/latitude from the WMTS matrix only; INTERPRETED: USGS unit descriptions; SIMULATED: Hab, stops, costs, hazard, dust narrative. Footer disclaimer unchanged and visible: "Hackathon planning demonstrator. Routes and hazards are simulated; not flight-qualified navigation."

## Docs updated

`docs/TASK_0_REPORT.md` (this file), `STATUS.md` (Task 0 status, browser evidence, M1/M2/L2), `docs/DATA_SOURCES.md` (level 11/12 availability, cached bbox and delta coverage). No asset manifest changed; no new asset added.
