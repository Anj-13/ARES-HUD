> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

> HISTORICAL EVIDENCE: prior report, not current acceptance. [UNVERIFIED] Old test/commit claims unless independently repeated in [AUDIT_CURRENT.md](AUDIT_CURRENT.md). [STATUS.md](../STATUS.md) controls current migration status.

# Task 0D documentation baseline report

## Facts established before reconciliation

- HEAD: 5d79741, 14 November 2026 13:56:31 +0000; dirty working tree with untracked Phase 2 modules/assets and preexisting staged snapshot deletions. No release or deployment inferred.
- npm.cmd test: 14 passed, 0 failed; 8 pathfinding and 6 mission tests. Syntax passes for all seven root JS files.
- Local cache: 16 level-10 PNG tiles, rows 403-406/columns 1463-1466, 1,023,802 bytes; manifest hashes and byte counts all match. Two NASA JPEGs and one USGS PDF exist; hashes checked in DATA_SOURCES.md.
- HTML entries: index.html loads app.js and exploration.js; browser-test.html uses inline code and an iframe pointing at index.html. Module responsibilities/exports are in ARCHITECTURE.md Part A.
- Capabilities snapshot declares active levels 0-12; only level 10 is cached. Live higher-level access and delta appearance were not tested. Numeric DEM and geology geometry absent.
- No Task 0 completion evidence found. **Sequencing exception:** owner explicitly requested Task 0D before verified Task 0. No Task 0 completion or migration completion is claimed.

## Commands and outputs

These baseline commands were run before documentation staging. npm output below preserves result names/counts; glyphs and per-test timings are normalized for readability; the suite total is exact. Initial npm run output is available in the task transcript.

### git status --short

```text
 M app.js
 M index.html
D  initial-files/LICENSE
D  initial-files/app.js
D  initial-files/index.html
D  initial-files/package.json
D  initial-files/pathfinding.js
D  initial-files/pathfinding.test.js
D  initial-files/styles.css
 M package.json
 M styles.css
?? assets/
?? browser-test.html
?? datasets.js
?? exploration.js
?? mission.js
?? mission.test.js
?? qa-regression.png
?? qa-screen.png
```

### git log -1 --format=%h %s %ci

```text
5d79741 Nov-14: prototype 1 2026-11-14 13:56:31 +0000
```

### git log --oneline

```text
5d79741 Nov-14: prototype 1
af9ac9e Nov-14: Add the initial files
802e097 Nov-14: Added gitignore file
4443777 Initial commit
```

### git ls-files

```text
.gitignore
LICENSE
app.js
index.html
package.json
pathfinding.js
pathfinding.test.js
styles.css
```

### npm.cmd test

```text
> test
> node --test pathfinding.test.js mission.test.js

PASS ordered stops and cumulative cost
PASS hazard recalculates traverse and return
PASS unreachable mission yields no misleading partial route
PASS layer state is independent and immutable
PASS tile transform matches WMTS top-left and tile span
PASS dataset identifiers, attribution and local assets
PASS straight and diagonal optimal routes
PASS symmetric blocked detour is deterministic
PASS enclosed goal has no path
PASS blocked endpoints and empty grid return null
PASS diagonal cannot cut either blocked corner
PASS fixed dust zone changes route and permits return
PASS penalties influence routing and negatives clamp to zero
PASS same endpoint returns zero cost
Tests 14; pass 14; fail 0; cancelled 0; skipped 0; todo 0; duration_ms 430.7715
```

### Syntax checks

Executed `node --check app.js`, `node --check datasets.js`, `node --check exploration.js`, `node --check mission.js`, `node --check mission.test.js`, `node --check pathfinding.js`, `node --check pathfinding.test.js`: each exit 0, no stdout/stderr.

### Inventory, integrity and search commands

Executed `Get-ChildItem -Recurse -Filter *.md -File`, `Get-Content -Encoding UTF8` for repository documents and application sources, `git log --stat -2`, `git diff --cached --stat`, `rg -n 'TileMatrix>|MatrixWidth|MatrixHeight' assets/trek-capabilities.xml`, and `rg -n 'script|surface|footer' index.html`. Results established the file/entry-point/matrix descriptions above. A Python stdin integrity check recomputed manifest SHA-256 and sizes: `Manifest verification: 16/16 hashes and sizes match; tile bytes: 1023802`. Image/PDF hashes are recorded in DATA_SOURCES.md.

An initial Python export inventory used the Windows default encoding and raised UnicodeDecodeError; rerunning with explicit UTF-8 succeeded. No source edits were made to address that tool invocation. Corrected export inventory output:

```text
app.js exports: (none)
datasets.js exports: datasets
exploration.js exports: (none)
mission.js exports: planMission,moveStop,layerState,tileCoordinate
mission.test.js exports: (none)
pathfinding.js exports: SIZE,HAB,SCIENCE,createGrid,findPath
pathfinding.test.js exports: (none)
```

The stale-claim search was `rg -n 'eight tests|8 tests|no NASA asset|NASA resource absent|four files|H1|af9ac9e|not deployed' docs -g '*.md'`. It found old README/test counts, old no-loader architecture, and historical QA claims. Historical evidence and Task 0D's literal search examples remain intentionally retained; current docs no longer assert those old conditions.

## Changes and stale claims corrected

- Root README now provides one coherent current application description, run/deploy instructions and full Markdown inventory. docs/README.md is a navigation entry; owner request overrides the earlier root-README deferral.
- Root STATUS.md centralizes status/evidence and lists every migration row as NOT STARTED. ARCHITECTURE.md separates current components/state/A* from proposed React/Vite/Leaflet/tablet/Sol/fog/terrain work.
- MAP_ARCHITECTURE.md explicitly describes the current independent explorer/reference/grid spaces. DATA_SOURCES.md retains acquisition URLs, credits and metadata and adds current integrity checks including the PDF and per-tile hashes.
- Eight named historical reports/plans receive banners, current finding annotations and evidence limits. CHANGELOG adds actual 5d79741 history; uncommitted Phase 2 functionality is not invented as a commit.
- AGENTS notices point to owner addendum precedence and STATUS. AGENT_RULES_ADDENDUM.md and AGENT_TASKS.md were not modified. FEATURE_PLAN no longer duplicates a mutable current-state table.
- Corrected stale test count, resource-absence claim, no-loader claim, four-file deployment guidance and stale Git baseline. Retained honest deployment uncertainty. Fixed known question-mark separators in documentation; remaining production artifacts are listed, not changed.

All Markdown paths/classifications are inventoried in README. No document is declared REDUNDANT for permanent deletion. **Archive candidates:** the eight HISTORICAL EVIDENCE documents could move to docs/archive/ after owner review and link updates. Nothing was moved/deleted; test evidence, scientific provenance, schedule and judging references remain available.

## Not verified / owner decisions

No real browser opened in this pass. The 15-check Edge result remains REPORTED; PDF plugin, mobile/touch, accessibility, no-route UI injection, public host/MIME/network/private-window acceptance and official eligibility were not verified. No online sources were fetched. Preserved citations are acquisition/reference evidence, not fresh validation. No attached archive was treated as current evidence.

NASA assets retain OBSERVED classification, pointer arithmetic DERIVED, geological descriptions INTERPRETED and routing assumptions SIMULATED. No new scientific data classes, assets, dependencies or application features were added. Open QA and policy conflict details are in STATUS.md. React/Vite versus the supplied no-build policy needs later reconciliation; this task does not modify the addendum.

## Validation and commit

Final link, UTF-8, non-document hash and documentation-only commit checks are recorded below after execution. The global working-tree diff necessarily contains preexisting production modifications; the Task 0D commit is isolated to explicit Markdown paths and must not consume preexisting staged deletions.

### Final captured test command: npm.cmd test

Exit 0. Exact captured output:

```text

> test
> node --test pathfinding.test.js mission.test.js

✔ ordered stops and cumulative cost (10.783ms)
✔ hazard recalculates traverse and return (84.9467ms)
✔ unreachable mission yields no misleading partial route (1.0465ms)
✔ layer state is independent and immutable (0.5394ms)
✔ tile transform matches WMTS top-left and tile span (0.4798ms)
✔ dataset identifiers, attribution and local assets (8.3274ms)
✔ straight and diagonal optimal routes (5.073ms)
✔ symmetric blocked detour is deterministic (3.3457ms)
✔ enclosed goal has no path (0.6358ms)
✔ blocked endpoints and empty grid return null (0.8279ms)
✔ diagonal cannot cut either blocked corner (1.8414ms)
✔ fixed dust zone changes route and permits return (49.5846ms)
✔ penalties influence routing and negatives clamp to zero (1.0884ms)
✔ same endpoint returns zero cost (1.0895ms)
ℹ tests 14
ℹ suites 0
ℹ pass 14
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 374.3055
```

### Final documentation validation

Python stdin validation: 23 Markdown files decoded as UTF-8; 0 relative path/anchor failures; 39 non-document baseline files compared, 0 changes introduced. No replacement-character/mojibake patterns detected. First validation exposed generated question-mark separators from Windows stdin encoding; corrected documentation with encoding-safe text and reran successfully. Literal question marks remain only where meaningful (URLs, questions and preserved Git status output); production encoding findings remain open.

No target feature is marked complete outside STATUS.md. Task specifications retain literal completion/search examples, and historical reports retain dated evidence under banners.

### Commit isolation checks

`git add -f -- <23 explicit Markdown paths>` exited 0; staged documentation stat: 23 files. Default `git diff --cached --check -- <documentation paths>` exited 2 on existing Markdown two-space hard line breaks in policy/historical documents. They are intentional Markdown formatting, retained to preserve those records. `git -c core.whitespace=-blank-at-eol diff --cached --check -- <documentation paths>` is used to check other whitespace errors without treating Markdown hard breaks as errors. Explicit `git commit --only` paths isolate the documentation from seven preexisting staged non-document deletions.
