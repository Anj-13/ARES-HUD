> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](../BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

> HISTORICAL OTHER-AGENT REPORT. Not authoritative; see [root status](../../STATUS.md) and [current audit](../AUDIT_CURRENT.md).

# ARES-HUD status - single source of truth

Only this file may mark a migration feature DONE. Other documents describe code or proposals and link here for task status.

## Baseline - 14 November 2026

HEAD at inspection: `5d79741acb0b54863499ee3c70446d773e08e168`, **Nov-14: prototype 1**, 2026-11-14 13:56:31 +0000. The inspected application was a **dirty working-tree baseline**, not a reproducible application release at that commit: app.js, index.html, styles.css and package.json differed from HEAD; mission.js, datasets.js, exploration.js, mission.test.js, browser-test.html and assets/ were untracked. Seven initial-files/ deletions were already staged. That tree is now committed as `ae0cc4a` (task-0) together with the preflight fixes, so HEAD is reproducible; no release tag exists yet.

`npm.cmd test`: 14 passed, 0 failed, 0 skipped/cancelled (430.7715 ms). pathfinding.test.js supplies 8 tests; mission.test.js supplies 6. All seven root JavaScript files pass `node --check`. All 16 tile files match their manifest byte counts and SHA-256 values. These checks verify algorithms, syntax and local integrity, not browser presentation or source-service availability. See [Task 0D evidence](../TASK_0D_REPORT.md) for commands and baseline file hashes.

**Sequencing exception - RESOLVED:** Task 0 preflight was not verified when Task 0D ran. It has now been executed as its own task; see [Task 0 report](../TASK_0_REPORT.md). Task 0 covered the tile-matrix numbers, one live level-11 and level-12 tile request, cached-block coverage, the visual delta check, encoding artefacts, QA M1/M2/L2 and browser checks. It added no feature.

## Task 0 preflight - 14 November 2026

See [Task 0 report](../TASK_0_REPORT.md). Tile matrix declares levels 0-12 with deepest level 12 (8192 x 4096). Live requests for one level-11 and one level-12 tile near 18.45 N 77.45 E returned HTTP 200 `image/png`. Cached level-10 block: 77.16796875-77.87109375 E, 18.45703125-19.16015625 N; it overlaps about 15.4 % of the USGS sheet extent and clips the southern edge of the delta seen in level-11 imagery. Encoding artefacts, QA M1/M2/L2 and the sequence-list double numbering were fixed; all seven JS files pass `node --check`, `npm.cmd test` is 14/14, and headless Edge reports 21/21 browser checks. The application tree that the baseline above called dirty is committed by this task.

## Current implementation

VERIFIED means the cited command or source inspection only; browser claims require a browser run.

| Capability | Status | Evidence and boundary |
| --- | --- | --- |
| Weighted eight-direction A*, deterministic dust detour, blocked/no-path/corner handling | VERIFIED | 8 pathfinding tests passed |
| Ordered stops, summed leg costs, rejection of failed leg, reordering | VERIFIED | mission.js inspection; mission tests passed |
| Simulated arrival and return UI handlers | VERIFIED | app.js inspection only; arrival changes current and deselects next stop; browser not rerun |
| NASA CTX loader and local image references | VERIFIED | exploration.js/index.html inspection; 16 manifest hashes/sizes match; not a new visual render check |
| USGS educational PDF and 3-unit inspector | VERIFIED | local PDF exists; exploration.js/index.html source inspection; plugin rendering not checked |
| Tile-plane pan/zoom, angular pointer readout, visibility/opacity | VERIFIED | source inspection and tileCoordinate unit assertion; no real-browser verification this pass |
| 21 browser checks | VERIFIED | Headless Microsoft Edge on 14 Nov 2026 against browser-test.html at 1280 px: "PASS: 21 browser checks", including injected no-route grid, identical-endpoint hazard copy, 44 px science pin, tile/surface fallbacks |
| Desktop layout and 360 px layout | VERIFIED (layout only) | Headless Edge screenshots inspected; 360 px iframe render has no horizontal overflow (scrollWidth 345 at innerWidth 360) |
| Touch, screen readers, assistive technology | NOT VERIFIED | no device or AT run |
| Public deployment | NOT VERIFIED | no verified public URL; repository metadata is not deployment evidence |

## Migration target - planned v0.3

No target modules, React/Vite dependencies or Leaflet vendor files exist in the inspected tree. Existing exploration controls and instantaneous arrival do not constitute registered-map or Sol migration work.

| Item | Status | Commit | Evidence |
| --- | --- | --- | --- |
| React + Vite frontend migration (deferred) | NOT STARTED | none | no code; latest owner request requires explicit approval for a new build step |
| Task 1 registered Leaflet map | NOT STARTED | none | no Leaflet, map-crs.js, sector.js, geo.js, map.js or sector-layers.js |
| Task 3 Send to Tablet | NOT STARTED | none | no plan.js, tablet.html or tablet.js |
| Task 2 Sol timeline | NOT STARTED | none | no sols.js or timeline |
| Task 6 Fog of War | NOT STARTED | none | no fog.js/reconnaissance model |
| Task 7 Planetary Mode 3D Mars globe | NOT STARTED | none | vision/spike specification only; no globe renderer, global texture or verified rover-marker data; spike not executed |
| Task 5 terrain cost | NOT STARTED | none | no numerical DEM, derived slope module or terrain-processing dependency |

## Known gaps and QA findings

- **RESOLVED - H1 absence of any NASA resource:** local CTX tiles and both NASA JPEGs exist and are referenced by current code; hashes verified. This resolves absence only, not challenge eligibility, sector registration or suitability of cached coverage.
- **OPEN - H2 public acceptance:** public URL, deployed revision, MIME/network checks and owner private-window validation absent. Prior local browser evidence remains REPORTED.
- **RESOLVED - L1 stale Git wording:** current README records the baseline and repository link; Task 0 committed the previously dirty prototype tree, so HEAD is now reproducible. No freeze tag exists yet.
- **RESOLVED - M1 no-route UI:** `../../app.js` exposes a test-only grid override; browser-test.html injects an all-blocked grid and confirms "No route available", the blocked-route explanation and recovery after clearing (checks 15-17).
- **RESOLVED - M2 identical endpoints:** the dust narrative is conditional (identical endpoints, no stops, failed route, no pre-hazard route, unchanged route, real detour); checked in headless Edge (check 14).
- **RESOLVED - L2 marker sizing:** the science pin is a 44 px circle (was 32 px wide against a 44 px min-height); measured in headless Edge (check 18).
- **RESOLVED - scientific limits:** conceptual EVA grid is separate from geographic tiles; no metric route distances, DEM/slope, geology geometry identify or location-matched rover image. Delta coverage and higher-level tile availability are now measured in the Task 0 report: the cached block clips the delta's southern edge and level 11/12 tiles were served at test time. No registration follows from either.
- **RESOLVED - release policy precedence:** latest v0.3 owner request retains static hosting and prohibits a new build step without explicit approval. React/Vite migration is deferred for this release; the globe feature exception does not approve a renderer dependency or full implementation. No dependencies were installed.
- **RESOLVED - encoding artifacts:** the five literal question-mark punctuation placeholders in app.js/index.html were replaced with real characters in Task 0.
- **UNVERIFIED - judging/account requirements:** preserved guide/challenge links and team checklist are references; official pages, eligibility, final submission and source-use eligibility were not revalidated here.

Option 2 schedule is policy only: Sunday 15 November 2026 GMT, feature cutoff 13:30, dependency/data freeze 14:30, deployment verification 15:15, final Git commit 15:45, code freeze 16:00. Tier B follows verified Tier A. Task 7 follows verified Task 1 and a successful spike plus separate owner go/no-go; it cannot displace A/B. Task 5 remains independently gated.

Task 0D documentation baseline is recorded by the commit titled `task-0D: reconcile current and target documentation`; see its report. No migration row is promoted by this documentation pass.
