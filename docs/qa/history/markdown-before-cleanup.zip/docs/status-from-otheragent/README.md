> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](../BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

> HISTORICAL OTHER-AGENT REPORT. Not authoritative; see [root status](../../STATUS.md) and [current audit](../AUDIT_CURRENT.md).

# ARES-HUD - Team Martian

> Current: static, no-backend prototype with a registered Leaflet Surface Mode map over cached NASA CTX tiles plus a simulated EVA planner. PLANNED v0.3: separately gated 3D Planetary Mode. See [STATUS.md](STATUS.md) for the authoritative baseline, verification limits and migration task status.

Conceptual Mars EVA planning demonstrator for the [NASA Space Apps 2026 Martian Map challenge](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/).

**Hackathon planning demonstrator. Routes and hazards are simulated; not flight-qualified navigation.**

## What runs today (verified)

Current source, executed Node checks and one headless Microsoft Edge browser run establish:

- A deterministic 40 x 40 simulated 4 km x 4 km sector, nominal 100 m cells, with eight-direction JavaScript A*, weighted entering-cell costs and no diagonal corner cutting.
- Single-destination and ordered, selectable/reorderable three-stop planning. Mission tests verify cumulative cost and complete-route rejection if a leg fails.
- Fixed simulated dust rerouting, hazard-free dashed baseline and Return to Hab. The UI includes instantaneous simulated arrival at the next selected stop; ordinary planning does not move current position.
- One registered Leaflet 1.9.4 map (vendored, BSD-2-Clause) that owns pan, zoom, touch, keyboard, tile loading, screen projection and the scale bar, over 24 cached NASA CTX tiles at WMTS levels 10-12 plus a simulated 40 x 40 grid, Hab, three stops, hazard shading and route. The MarsEQ CRS uses the Mars 2000 radius (3,396,190 m); the browser harness proves tile-index alignment and 4,000 m map distances.
- A separate USGS educational geological PDF/unit inspector, THEMIS context JPEG and Perseverance image inspector.

The USGS reference and the EVA overlays are separate spaces: the map grid and its waypoints are hypothetical, not located on real terrain. The browser harness reports 49/49 checks in headless Microsoft Edge, `npm test` runs 22 Node tests, and every root JavaScript file passes `node --check`. See the [Task 1 report](../TASK_1_REPORT.md). Touch, screen-reader and public-deployment behaviour remain unverified.

## Planned migration (NOT implemented)

| Component | Owner-requested target |
| --- | --- |
| Frontend | Static ES modules for this release; React/Vite deferred, no new build without explicit approval |
| Planetary Mode | Separate locally vendored globe renderer, global Mars imagery and verified real-mission markers; Task 7 spike and owner gate |
| Surface Mode | DELIVERED by Task 1: vendored Leaflet 1.9.4 registered Mars imagery and simulated EVA grid; tablet plan still planned |
| Route algorithm | JavaScript A*, retain tested behavior |
| Terrain processing | Python + NumPy, if verified data requires it |
| Data | NASA resources linked from the challenge, with asset-level provenance |

PLANNED flow: launch globe -> inspect verified rover context or select hypothetical ARES sector -> enter registered Jezero Surface Mode -> plan EVA -> Send to Tablet -> dust/replan -> Return to Hab. Surface-to-Planetary return and direct 2D fallback would preserve accessibility and plan state; tablet needs no 3D. Sol timeline and Fog of War would remain SIMULATED reconnaissance, never real sensing. Original art only: The Martian is narrative inspiration; NASA Eyes is an experience reference, not an embedded API or copied interface.

The globe, tablet handoff, Sol timeline, fog and terrain migration remain unimplemented; the registered Leaflet sector is implemented by Task 1. Task 7 depends on verified Task 1 and a 60-minute spike, followed by separate owner go/no-go; it cannot displace Tier A/B or release gates. The latest request preserves no-backend/no-new-build architecture. See [target architecture](../ARCHITECTURE.md#part-b-planned--gated), [Task 7](../AGENT_TASKS.md#task-7---3d-mars-globe) and [STATUS.md](STATUS.md).

## Run and test

Run from the repository root with Python 3 and Node.js available. No npm install is needed for the current code.

```sh
python -m http.server 8000
npm test
```

Open http://localhost:8000 for the app and http://localhost:8000/browser-test.html for the browser harness. On Windows use `npm.cmd test` if required. HTTP is required for ES modules. The test command runs pathfinding.test.js (8 tests), mission.test.js (5 tests) and geo.test.js (9 tests); this pass recorded 22 passed and 0 failed. No build/dev npm script exists today.

Demo: pan/zoom the registered map, plan selected traverse, toggle dust, simulate arrival, then Return to Hab. Reset restores positions/selections and clears dust; it does not restore a reordered stop list. Hiding hazard shading does not remove the blockage. The map fits the sector on load and labels zoom past level 12 as enlarged imagery. The browser harness intentionally requests one missing tile to exercise the fallback.

## Deployment

Public URL: **none verified**. [Git origin](https://github.com/Anj-13/ARES-HUD) is repository metadata, not hosting evidence. Current working-tree functionality includes untracked files and is not fully represented by HEAD; cloning HEAD alone does not reproduce this baseline.

For a future static deployment include index.html, styles.css, app.js, pathfinding.js, mission.js, datasets.js, exploration.js, map-crs.js, sector.js, geo.js, map.js, sector-layers.js, the vendor/leaflet/ directory and the entire assets/ directory, preserving paths. Tests/harness are optional deployment QA artifacts. Verify HTTP/MIME types, console/network, mobile/keyboard behavior and the full route flow; the owner must check the public URL in a private browser window. Do not infer deployment from configuration.

## Sources, credits and limitations

[DATA_SOURCES.md](../DATA_SOURCES.md) is authoritative for exact URLs, local paths, hashes and scientific limits. CTX imagery is credited to NASA/JPL-Caltech/MSSS via Mars Trek; PIA23386 to NASA/JPL-Caltech/Arizona State University; PIA24485 to NASA/JPL-Caltech/ASU/MSSS. The USGS educational derivative cites Sun, V.Z., and Stack, K.M. (2020), [SIM 3464](https://doi.org/10.3133/sim3464). Imagery is OBSERVED; geological unit explanations are INTERPRETED; tile-coordinate arithmetic is DERIVED, not an EVA registration; grid, locations, hazards and costs are SIMULATED. Leaflet 1.9.4 is vendored under BSD-2-Clause; version, source URL, retrieval date, byte counts and SHA-256 values are recorded in [DATA_SOURCES.md](../DATA_SOURCES.md).

No elevation, slope, physical travel-time/safety model, live telemetry or individual obstacle detection exists. No rover photograph is located at a hypothetical waypoint. Cached resolution and source-date gaps remain documented. Reuse terms and official challenge-resource eligibility need owner review; no NASA endorsement is implied.

Software is [MIT licensed](../../LICENSE), copyright 2026 Anjila Gurung. NASA/USGS assets retain separate credits. Existing project documentation attributes implementation to OpenAI Codex assistance; Codex also assisted this baseline. Task 1 was implemented with DeepSeek V4.1 Flash running in the OpenCode agent harness. Other AI tools or offer redemptions are not established by evidence.

Preserved submission references: [2026 judging guide](https://www.spaceappschallenge.org/resources/judging-awards-guide/), [NASA data requirement](https://github.com/nasa/spaceapps/discussions/1827), [submission clarification](https://github.com/nasa/spaceapps/discussions/1991). The owner selected Option 2: internal code freeze is Sunday 15 November 2026 at 16:00 GMT (Europe/London), with video preparation afterwards. See the [schedule and checkpoints](../AGENT_RULES_ADDENDUM.md#2-schedule-policy-owner-approved--option-2). Official submission remains event-local; official/account requirements were not independently revalidated in this pass.

## Documentation index

CURRENT includes active policy and reference documents; HISTORICAL documents retain prior claims with reconciliation annotations. Only STATUS.md records migration completion. The full inventory and classifications follow.

| Document | Label / classification | Purpose |
| --- | --- | --- |
| [AGENTS.md](../../AGENTS.md) | CURRENT / ACTIVE POLICY | Root discovery instructions and precedence notice |
| [README.md](README.md) | CURRENT / CURRENT DOCUMENTATION | Judge-friendly application overview and complete documentation index |
| [STATUS.md](STATUS.md) | CURRENT / CURRENT DOCUMENTATION | Sole feature-status and verification register |
| [docs/AGENTS.md](../AGENTS.md) | CURRENT / ACTIVE POLICY | Full operating instructions; addendum precedence |
| [docs/AGENT_RULES_ADDENDUM.md](../AGENT_RULES_ADDENDUM.md) | CURRENT / ACTIVE POLICY | Owner approvals and gates; unchanged in Task 0D |
| [docs/AGENT_TASKS.md](../AGENT_TASKS.md) | CURRENT / ACTIVE POLICY | Task specifications including Task 0D; unchanged |
| [docs/ARCHITECTURE.md](../ARCHITECTURE.md) | CURRENT / CURRENT DOCUMENTATION | Current components versus explicitly proposed target |
| [docs/ARES_HUD_ONE_DAY_AUDIT.md](../ARES_HUD_ONE_DAY_AUDIT.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/BUILD_TONIGHT.md](../BUILD_TONIGHT.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/CHANGELOG.md](../CHANGELOG.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/DATA_SOURCES.md](../DATA_SOURCES.md) | CURRENT / CURRENT DOCUMENTATION | Authoritative asset URLs, credits, hashes and science limits |
| [docs/FEATURE_PLAN.md](../FEATURE_PLAN.md) | CURRENT / ACTIVE REFERENCE | Proposed migration and ADR-1, not implementation status |
| [docs/FIX_REPORT.md](../FIX_REPORT.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/INTEGRATION_REPORT.md](../INTEGRATION_REPORT.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/JUDGING_CHECKLIST.md](../JUDGING_CHECKLIST.md) | CURRENT / ACTIVE REFERENCE | Preserved NASA judging/submission requirements |
| [docs/MAP_ARCHITECTURE.md](../MAP_ARCHITECTURE.md) | CURRENT / CURRENT DOCUMENTATION | Current three-space map design by source inspection |
| [docs/QA_REPORT.md](../QA_REPORT.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/README.md](../README.md) | CURRENT / CURRENT DOCUMENTATION | Navigation to root README and STATUS |
| [docs/RESOURCE_GAP_AUDIT.md](../RESOURCE_GAP_AUDIT.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/TASK_0D_REPORT.md](../TASK_0D_REPORT.md) | CURRENT / CURRENT DOCUMENTATION | This documentation baseline evidence and sequencing exception |
| [docs/TASK_0_REPORT.md](../TASK_0_REPORT.md) | CURRENT / CURRENT DOCUMENTATION | Preflight evidence: tile matrix numbers, live tile check, coverage, hygiene fixes, browser checks |
| [docs/TASK_1_REPORT.md](../TASK_1_REPORT.md) | CURRENT / CURRENT DOCUMENTATION | Task 1 evidence: Leaflet spike, sector placement, tiles, 49 browser checks, acceptance greps |
| [docs/TEST_REPORT.md](../TEST_REPORT.md) | HISTORICAL / HISTORICAL EVIDENCE | Dated findings/plans retained with reconciliation annotations |
| [docs/assets/README.md](../assets/README.md) | CURRENT / ACTIVE REFERENCE | Asset-register navigation; no duplicate status |
| [docs/toolgiven.md](../toolgiven.md) | CURRENT / ACTIVE REFERENCE | Offer/research catalogue; actual use not established |
| [docs/CODEX_OPTION_2_HANDOFF.md](../CODEX_OPTION_2_HANDOFF.md) | CURRENT / ACTIVE REFERENCE | Owner handoff instructions; not implementation evidence |
| [docs/DOCS_CHANGE_REPORT_V03.md](../DOCS_CHANGE_REPORT_V03.md) | CURRENT / CURRENT DOCUMENTATION | v0.3 documentation changes, spike gates, owner decisions and validation |
