> React migration update, 14 November 2026: the owner explicitly requested React + Vite integration using `react-ui-handoff/`. That request supersedes older build deferral statements here. Static hosting, existing algorithms, provenance, separate globe/elevation gates and release schedule remain applicable. Current architecture is in ARCHITECTURE.md; acceptance is recorded only in ../STATUS.md.

# FEATURE_PLAN.md — ARES-HUD v0.3 feature plan

**Team:** Martian · **Event:** NASA Space Apps 2026, *Interplanetary Survival Guide: Martian Map*
**Companions:** [AGENT_RULES_ADDENDUM.md](./AGENT_RULES_ADDENDUM.md) · [AGENT_TASKS.md](./AGENT_TASKS.md)
**Status of this document:** planning only. Nothing here is implemented until the matching task in `AGENT_TASKS.md` is reported green with evidence. **Owner approved schedule Option 2:** Tier B may proceed after verified Tier A; Sunday 15 November 2026 at 16:00 GMT is the code freeze, with a 13:30 feature cutoff. See `AGENT_RULES_ADDENDUM.md` section 2.

---

## 1. Vision in one paragraph

PLANNED v0.3: a two-scale Mars exploration and EVA demonstrator with original art and source/simulation labels. Planetary Mode would offer a rotatable, zoomable real Mars globe; Surface Mode would retain every v0.2 feature below: registered Leaflet Jezero CTX map, 40x40 hypothetical 4 km x 4 km sector, multi-stop A*, dust, Return to Hab, coordinates, scale, provenance, validated Send to Tablet, simulated Sol timeline and reconnaissance. This is not an implementation claim. The former React/Vite target is deferred by the latest no-build owner instruction.

### View A: Planetary Mode (Task 7, separately gated)

Authentic NASA Mars Trek global imagery adapted to a pinned, locally vendored globe renderer would provide context. Source-linked Curiosity/Gale and Perseverance/Jezero markers require verified mission coordinates, coordinate conventions, epoch and metadata. Published historical traverses must be labeled and sourced; no invented current positions or tracks. NASA Eyes is an interaction goal only, not an API or interface to copy.

### View B: Surface Mode (Tasks 1, 3, 2, 6 retained)

Leaflet 1.9.x would remain the sole 2D viewport/projection owner for both mission control and tablet. Verified CTX imagery is OBSERVED; grid coordinates are DERIVED only after registration verification. Hypothetical astronaut positions, costs, hazards, schedules and sensors remain SIMULATED. Task 5 remains a separately gated numeric-elevation investigation.

### Transition and 30-second target demo

Launch globe -> select a real rover for factual context or select the ARES-HUD EVA sector -> enter registered Jezero Surface Mode -> plan EVA -> Send to Tablet -> simulate dust/replan -> Return to Hab. Provide Return to Planetary Mode and preserve plan state. Rover context does not authorize creating a second EVA site; Curiosity's Gale route must never be overlaid on Jezero. No globe rendering is required on the tablet. Reduced motion uses an immediate view switch instead of animated descent. If Task 7 is unavailable, retain direct entry to the functioning 2D map and record the globe as NOT IMPLEMENTED. Record only features actually verified for the final demo.

## 2. Current baseline reference

See [STATUS.md](../STATUS.md) for current capabilities, test evidence and migration status. Owner-supplied schedule and v0.3 vision updates are policy inputs, not a new browser or deployment verification. This file specifies proposed work. Numerical findings below remain assumptions to verify in Task 0; they do not prove live tile availability or delta coverage.

### Findings from reading the files (verify in Preflight)

1. **Maximum zoom is level 12.** `assets/trek-capabilities.xml` declares TileMatrix levels 0-12 for `Jezero_CTX_BlockAdj_dd`. Level `L` has `2^(L+1)` columns by `2^L` rows of 256 px tiles; each tile spans `180 / 2^L` degrees; origin (-180, 90). Angular size per pixel is therefore `0.000687°` at level 10, `0.000343°` at level 11, `0.000172°` at level 12.
2. **Ground size per pixel (arithmetic, Mars 2000 sphere radius 3,396,190 m, so 1° latitude ≈ 59,275 m).** North-south ≈ 40.7 m/px at level 10, ≈ 20.4 m/px at level 11, ≈ 10.2 m/px at level 12. East-west is multiplied by cos(latitude) ≈ 0.95 near 18.4° N. The catalog's native 0.0001° (about 6 m) is **not** served beyond level 12 according to the capabilities file.
3. **Consequence for the grid.** At level 10 a 100 m cell is about 2.5 px, which is why zooming only blurs. At level 12 it is about 10 px, which is workable.
4. **The cached block probably misses the delta.** Level 10 rows 403-406 span about 18.46°N to 19.16°N and columns 1463-1466 span about 77.19°E to 77.87°E. The USGS SIM 3464 coverage recorded in `datasets.js` is 17.7-18.7°N, 76.8-77.8°E. The two overlap only in a thin northern strip, so the "delta sampling concept" stop is probably not on the delta. **Preflight Task 0 must confirm this by rendering and visual comparison before the sector is chosen.**
5. **A 4 km x 4 km sector is not square in equirectangular pixels.** East-west pixels are shorter on the ground than north-south pixels, so a 4 km square needs a longitude span of `4000 / (59,275 x cos(lat))` degrees and a latitude span of `4000 / 59,275` degrees.

## 3. Feature inventory

Priority key: **Must** (concept fails without it), **Should** (large value), **Stretch** (needs unverified data or time).

### F7 - 3D Mars globe (new feature, spike and owner gate)

Depends on verified Task 1. Investigate a permissively licensed, pinned and vendored static renderer, preferably with explicit Mars radius/custom ellipsoid support. Verify global WMTS imagery/projection/texture compatibility, legitimate acquisition, offline asset size, coordinate alignment, WebGL/fallback and laptop performance in a 60-minute spike. No renderer is selected or installed by this plan. Full implementation requires separate owner go/no-go; cannot displace Tier A/B. Exact acceptance and stop rules: [Task 7](AGENT_TASKS.md#task-7---3d-mars-globe).

### F1 — Registered map (Must, Tier A)

One pan/zoom surface in which imagery, grid, Hab, waypoints, hazards and routes share a single coordinate transform.

- Sector: a 4 km x 4 km lon/lat bounding box, 40x40 cells of 100 m, row 0 = north.
- `geo.js`: pure sector and grid maths only (`gridToLatLng`, `latLngToGrid`, `metersBetween`, bearing, tile-index helper for the download script). Unit-tested in Node. Leaflet owns projection to the screen (see ADR-1).
- Tiles for the sector cached at the best verified level (target 12) plus margin; served to a Leaflet tile layer from `assets/`.
- Lon/lat readout, scale bar in metres, layer toggles and opacity retained.
- Labels: imagery `OBSERVED`; coordinate mapping `DERIVED`; sector placement and Hab `SIMULATED / HYPOTHETICAL`.
- Why it matters: it turns NASA imagery from a backdrop into the surface the plan actually lives on, which addresses the **Relevance** criterion.

### F2 — Mission-control view with Sol timeline (Should, Tier B)

- Ordered Sols (default 8), each with stops, a planned route and a short log entry.
- Scrubber + play/pause; trail of path traveled (solid) and future path (dashed).
- Readout: Sol, lon/lat, metres travelled, metres to Hab, modeled cost, current stop.
- Position inside a Sol is interpolated by cumulative modeled cost (stated as such).
- Hazard events can be pinned to a Sol; passing one triggers a replan and a log line.
- All content `SIMULATED`. Optional later idea: use Perseverance's published traverse as the "lone traveler" (access and format **not verified**).

### F3 — Send to Tablet (Must, Tier A)

- Shared **plan object** (inputs only: sector id, Hab, stops, hazard flag, current position, schema version, checksum). The tablet recomputes routes with the same deterministic A*, which keeps the payload tiny and the two views consistent.
- Tablet view: ~360 px, high contrast, large type, local mini-map, heading arrow and distance to next stop, Return to Hab, Simulate dust hazard, modeled cost, no-route state.
- Handoff: (1) in-page slide-in animation; (2) URL-hash payload plus a locally generated QR code so a judge can open it on a phone from the public URL; (3) optional `BroadcastChannel` for two windows.
- Original visual design inspired by a wrist device; nothing copied from the film.

### F6 — Fog of War as simulated reconnaissance (Should, Tier B)

- Planning knowledge layer, not an imagery mask. Cells are `UNKNOWN` or `REVEALED` by a **simulated sensor radius** around the astronaut's trail.
- `UNKNOWN` cells carry a configurable `SIMULATED` uncertainty penalty in A*; reveals trigger replans.
- Real orbital imagery stays visible. The fog only dims the planning overlay and shows uncertainty.
- Mandatory label: `SIMULATED RECONNAISSANCE — not real obstacle detection`.

### F5 — Terrain-aware cost (Stretch, Tier C, gated)

- Gate: identify a georeferenced elevation product (with horizontal resolution, vertical units, datum, nodata) that covers the sector. Search `assets/trek-catalog.json` first.
- If verified: offline script samples to the 40x40 grid, computes slope, writes `assets/derived/slope.json` with full metadata; slope layer labelled `DERIVED`; slope penalty added to A* in one documented module; route explanation splits cost into distance and slope.
- Thresholds (8° / 15° from the original brief) are **design assumptions**, configurable and labelled `SIMULATED / INTERPRETED`, never standards.
- If not verified: stop. Keep costs `SIMULATED`. Document the negative result; it is itself a valid Validity finding.

### F4 — Geology as a real layer (Optional, not scheduled)

Convert official USGS SIM 3464 GIS data (listed on the USGS publication page, doi 10.3133/sim3464; format and size **not verified**) to GeoJSON offline, reproject from Mars Transverse Mercator (central meridian 77.5° E, sphere radius 3,396,190 m) to lon/lat, draw polygons and support a point-in-polygon "unit under this stop" lookup. Remains `INTERPRETED`, with no traversability claim. Left out of this round by owner choice; kept here so the idea is not lost.

## 3a. Architecture decision ADR-1: Leaflet owns the viewport

**Decision.** One Leaflet map (1.9.x, pinned and vendored, BSD-2-Clause) is the only 2D viewport and projection for Surface Mode mission control and the tablet. A separately approved 3D renderer would own Planetary Mode only. The earlier plan to hand-write CSS pan/zoom is withdrawn.

**Why.** Pan, pinch, inertia, keyboard handling, tile loading, lat/lng-to-pixel projection, bounds, scale control and layer management are solved problems. Writing them again adds code to test and creates two coordinate systems that can drift. The tablet reuses the same factory, so both views agree by construction.

**Why my earlier objection was wrong.** An earlier draft rejected Leaflet because the Trek matrix was said not to match its default CRS. Reading Leaflet's `EPSG4326` definition suggests the opposite: its transformation gives a 2 x 1 tile world at zoom 0, the same as the Trek WMTS matrix, so Leaflet zoom equals the WMTS level. This is from reading the source, not from a run, so Task 1 step 1 proves it with browser checks before anything is built on it.

**Responsibilities.**

| Concern | Owner |
| --- | --- |
| Surface Mode pan, zoom, touch, keyboard, inertia, bounds | Leaflet |
| Surface Mode lat/lng <-> screen pixels, tile loading, scale control, attribution | Leaflet (custom CRS `MarsEQ`, R = 3,396,190 m) |
| Layers, panes, markers, vector overlays (canvas renderer for cells) | Leaflet, driven by `sector-layers.js` |
| Grid cell <-> lat/lng, metres, bearing, tile indices for the download script | `geo.js` (pure, Node-tested, no Leaflet import) |
| Routing | `pathfinding.js` and `mission.js` (never import Leaflet) |
| Plan serialisation | `plan.js` |
| Planetary rendering / global texture / mission markers | Task 7 renderer and data modules, only after separate approval |

**Costs and risks.** One new vendored dependency (about 42 KB gzipped, to be confirmed); a custom CRS to verify; canvas overlays are not keyboard-focusable, so markers are `divIcon` buttons; existing `browser-test.html` checks that target the old explorer must be rewritten. **Stop rule:** if the CRS checks fail after 20 extra minutes, report to the owner. Do not silently fall back to a hand-written viewport.

## 4. Data-class map

| Item | Class | Note |
| --- | --- | --- |
| CTX orbital tiles | OBSERVED | NASA/JPL-Caltech/MSSS via Mars Trek |
| Grid-cell lon/lat | DERIVED | arithmetic from tile matrix and sector bbox |
| Sector placement, Hab, waypoints | SIMULATED | hypothetical, on real terrain |
| Hazards, costs, Sol schedule | SIMULATED | no physical model |
| Fog reveal radius, uncertainty penalty | SIMULATED | not sensor data |
| Slope (only if Task 5 passes) | DERIVED | from verified elevation, coarse |
| Slope thresholds / penalties | SIMULATED or INTERPRETED | assumptions, not standards |
| Geology unit descriptions | INTERPRETED | USGS, paraphrased |
| Perseverance image PIA24485 | OBSERVED | regional context only, not at a waypoint |

## 5. Plan-object schema (shared by F2 and F3)

```json
{
  "schemaVersion": 1,
  "sectorId": "jezero-sector-1",
  "hab": {"x": 5, "y": 20},
  "current": {"x": 5, "y": 20},
  "stops": [{"id": "delta", "x": 34, "y": 20, "selected": true}],
  "hazard": false,
  "sol": 1,
  "labels": {"hab": "HYPOTHETICAL", "costs": "SIMULATED"},
  "checksum": "<hash of the fields above>"
}
```

Grid coordinates are authoritative. Lon/lat are computed from `sectorId`, never stored in the plan.

## 6. Build order and dependencies

```
Task 0 Preflight ─► Task 0D Docs baseline ─► Task 1 Registered map (Leaflet) ─┬─► Task 3 Send to Tablet
                                           ├─► Task 2 Sol timeline ─► Task 6 Fog of War
                                           └─► Task 5 Terrain cost (gated spike first)
```

Task 3 depends on the plan object and geo helpers from Task 1. Task 6 depends on the trail from Task 2. Task 5 depends only on Task 1 but is gated on data. NEW Task 7 branches from verified Task 1: 60-minute verification spike -> separate owner go/no-go -> optional full implementation. Scheduling does not let Task 7 displace Tier A (0, 0D, 1, 3) or Tier B (2, 6). Task 5 remains separately gated.

## 7. Risk register (new work)

| Risk | Likelihood | Impact | Mitigation |
| --- | --- | --- | --- |
| Cached tiles do not contain the delta | High (by arithmetic) | High | Preflight confirms; download correct tiles |
| Level 12 tiles missing for the sector | Medium | High | Fall back to level 11; recompute cell pixel size; state limit in UI |
| Sector looks distorted (non-square) | Medium | Medium | Use cos(lat) scaling in `geo.js`; test corners |
| Leaflet CRS does not match the Trek matrix | Low | High | Step 1 spike with four browser checks; stop and report |
| Leaflet added late in the schedule | Medium | Medium | 45-minute spike; no fallback without owner approval |
| Docs drift from code | High | Medium | Task 0D, `STATUS.md`, addendum rule 14 |
| Tile layer or Trek unavailable at runtime | Low | Medium | Everything cached locally; failure message; routing independent |
| QR generation needs a library | Medium | Low | Fallback copyable URL; vendored MIT library only with LICENSE |
| Phone cannot reach the plan URL | Medium | Medium | Needs public host; keep in-page handoff as the primary demo |
| Fog misread as real detection | Medium | High | Mandatory label, tooltip, README note, never mask real imagery |
| Elevation product not available | High | Medium | Gate with a time-boxed spike; negative result documented |
| Globe data/renderer feasibility | Not established | High | Task 7 spike; preserve 2D if no legal global imagery, coordinate agreement, acceptable offline footprint or WebGL performance |
| Scope vs freeze | High | High | Tier policy in the addendum; revert to last green commit |
| Simulation credibility | Medium | High | Persistent labels and disclaimer on every view |

## 8. Judging alignment

| Criterion | Evidence this plan adds | Honest remaining weakness |
| --- | --- | --- |
| Impact | Local EVA planning loop with return-to-Hab | Concept stage, not operational |
| Creativity | Film-inspired mission-control → tablet handoff with original design; Sol timeline | Mini-maps and route planners exist; novelty is the integration |
| Validity | Tests for geo transforms, plan serialisation, determinism; clear labels | Costs are simulated; slope absent unless Task 5 passes |
| Relevance | Registered NASA CTX imagery as the surface the plan lives on; coordinates and metric scale derive from the tile matrix | No elevation or geology geometry unless Tasks 5 / F4 land |
| Presentation | One 30-second target flow: globe/context → registered map → traverse → tablet → dust/replan → return; direct 2D fallback | Must record only features that actually run |

## 9. Open questions for the owner

1. **RESOLVED:** Option 2 selected. Sunday 15 November 2026, 16:00 GMT code freeze; 13:30 feature cutoff. Tier B approved after Tier A verification.
2. Is a real public URL available (GitHub Pages or other) so the QR / phone handoff can be demonstrated?
3. Should the Sol demo be a fully simulated mission, or later use Perseverance's published traverse (needs verification)?
4. Which permissively licensed renderer/version should be approved after the Task 7 spike? No candidate is selected by this document.
5. Does the owner authorize full Task 7 implementation after reviewing feasibility evidence, without displacing Tier A/B?
6. What limits apply to new dependency bytes, offline globe texture/download size and GPU memory? Spike must measure/report these; no acceptance ceiling is invented here.
