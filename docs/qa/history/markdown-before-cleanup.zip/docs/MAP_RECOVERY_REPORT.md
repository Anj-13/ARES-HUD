> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

# Map recovery and feature review

Baseline commit: 0036eac; no new commit, staging, publication or submission.

## Finding and change

Ports 8000/8011 closed fresh HTTP connections without serving files. The screenshot is consistent with incomplete/stale assets, but the user's actual browser cache was not inspected. No missing-map production-code defect reproduced on a fresh origin.

Added serve.py: loopback-only threaded development server, stable repository directory, no-store cache headers, ignored old If-Modified-Since validators. Started detached with stdout/stderr directed to .browser-qa/ logs. Use http://localhost:8012/; restart with python serve.py. The application remains entirely static and needs no production Python backend.

Changed files: serve.py, README.md, STATUS.md, docs/ARCHITECTURE.md and this report. Existing audit/browser-harness edits remain uncommitted. No datasets, libraries or asset hashes changed.

## Executed evidence

- npm.cmd test: 22 passed, 0 failed.
- Headless Edge desktop 1280x1000: 49/49 checks pass on port 8012.
- Headless Edge explicit 360px iframe: 49/49 checks pass on port 8012.
- Inspected .browser-qa/fresh-map.png: NASA terrain, grid, Hab, stops, route, scale and zoom controls visibly rendered.
- Browser checks cover zoom/pan, alignment, keyboard, local imagery decoding, hazard reroute, return, identical endpoints, injected no-route and failed-tile recovery.
- Existing OBSERVED/DERIVED/INTERPRETED/SIMULATED labels and persistent disclaimer preserved. No changed application JS requires new syntax checks.

## Implemented versus outstanding

Present and regression-tested: Leaflet 1.9.4 registered 2D surface map; local NASA Mars Trek CTX; 4 km sector/40x40 grid; metric calculations; multi-stop A*, simulated arrival, dust reroute, Return to Hab; layer controls and source cards. USGS educational PDF and Perseverance published image remain separate context views, not georegistered data layers.

Not implemented: mission-control-to-tablet serialization and independent tablet view; Sol timeline; simulated reconnaissance; 3D globe and verified mission markers; numeric elevation/slope route costs. No public deployment verified. 3D requires its own spike and explicit go/no-go before implementation. No global imagery or renderer acquired in this fix.

Open: physical-phone/touch validation, public-host verification, full historical documentation reconciliation and the outstanding Task 0 PDF comparison. A passing surface-map harness is not acceptance of the full v0.3 vision.
