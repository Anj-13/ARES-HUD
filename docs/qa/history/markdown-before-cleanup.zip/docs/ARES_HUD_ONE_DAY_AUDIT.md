> HISTORICAL EVIDENCE: prior report, not current acceptance. [UNVERIFIED] Old test/commit claims unless independently repeated in [AUDIT_CURRENT.md](AUDIT_CURRENT.md). [STATUS.md](../STATUS.md) controls current migration status.

> STATUS: HISTORICAL - describes baseline pre-build planning (no source revision recorded) on 14 November 2026. Superseded by [STATUS.md](../STATUS.md). Finding tags were checked on 14 November 2026. Original timings and claimed checks are retained, not rerun.

## Task 0D reconciliation annotations — rechecked 14 November 2026

- **[RESOLVED] H1 / missing NASA imagery:** 24 genuine local CTX tiles at levels 10–12, source manifest hashes and two NASA reference JPEGs verified. Fresh level-11/12 requests return 200 PNG. Challenge/team eligibility is a separate owner submission check.
- **[OPEN] H2 / public acceptance:** local Edge desktop/narrow/keyboard and static-build tests pass; public URL, deployed revision, private-window and physical-device acceptance remain unverified.
- **[RESOLVED] M1 / no-route UI:** original and React browser harnesses exercise a blocked grid/plan, show unavailable results, omit an active route and recover after reset.
- **[RESOLVED] M2 / identical-endpoint narrative:** browser-checked dust state says no detour is needed at an identical endpoint; other no-route/unchanged/detour states have conditional copy.
- **[RESOLVED] L2 / marker sizing:** every Hab/science native button measures 44 × 44 CSS px at desktop and 360 px; map projection checks pass after pan at three zooms.
- **[RESOLVED] L1 / stale handoff wording:** current README/STATUS identify the React working tree over real local Git history. No freeze tag, new commit or public deployment is invented.
- **[RESOLVED] Registered imagery / documentation baseline:** source matrix, 4 km sector, coordinates, distances, CTX/PDF comparison and local Markdown links rechecked. Eight/14/22/33-test and 16-tile claims below are historical only; current suite is 39 passing tests and cache is 24 tiles.
- **[OPEN] Numeric terrain / geology geometry:** no verified numeric DEM, slope, unit-to-grid overlay or operational safety model. The separately displayed USGS educational map is not a routing raster.
- **[UNVERIFIED] Original run metadata / official submission:** old timing, unavailable commit IDs, event portal, registration, official-guide and submission claims remain archival; fresh evidence does not retrospectively certify them.

Full finding-by-finding evidence, historical commit validation and comparison limits: [baseline closure report](BASELINE_CLOSURE_REPORT.md). [STATUS.md](../STATUS.md) alone records acceptance. The original record follows; its original present-tense statements and numeric results describe its historical revision.

# ARES-HUD — Midnight Feasibility Audit

**Team:** Martian  
**Challenge:** [NASA Space Apps 2026 — Interplanetary Survival Guide: Martian Map](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/)  
**Reviewed inputs:** Team Martian's original `README.md`, `toolgiven.md`, *Technical & Product Specification: Project ARES-HUD*, the uploaded official 13 November 2026 **Judging & Awards Guide** and **Global Offers PDF**.  
**Verdict:** **GO for a scoped, truthful v0.1 by midnight tonight; NO-GO for the full original 18-hour spec.** The internal **application freeze is 00:00 Sunday 15 November 2026**; the official demo and submission work take place after that. A 24-hour budget is no longer the effective time remaining.

## 1. The one-sentence project

**ARES-HUD is a Mars EVA-planning demonstrator that puts a NASA-sourced map of a localized Martian region behind an interactive route planner, then shows how a *simulated* hazard changes the preferred route back to a hypothetical habitat.**

This preserves the team's *The Martian* / video-game mini-map identity without claiming astronaut-grade safety or live sensors.

## 2. Audit — what must change

| Original claim / feature | Finding | v0.1 decision |
| --- | --- | --- |
| **5–10 km radius** in project pitch versus **4 km × 4 km** in specification | Inconsistent geography. A 4 km-wide square extends only 2 km from its centre along cardinal axes. | **Use a 4 km × 4 km demonstration window.** Mark the larger radius as future work. |
| Jezero Western Delta imagery, elevation and slope will export together | NASA Mars Trek offers these kinds of analysis, but layer coverage, export formats, alignment and local resolution are **not guaranteed** for the chosen window. | **First obtain and document one real Mars Trek basemap.** Use simulated route-cost cells unless a georeferenced DEM is actually obtained and verified. |
| 40×40/50×50 grid represents foot-scale cliffs and boulders | A 4 km / 40-cell grid is **100 m per cell**, far too coarse for individual boulder or footpath detection. | Call it a **coarse illustrative planning grid**, not obstacle detection. |
| Green <8°, amber 8–15°, red >15° are safe/hazard thresholds | These numbers are not established as NASA EVA pass/fail limits by the submitted sources. | **Remove numerical slope thresholds from v0.1**, or disclose them as demonstration-only heuristics if verified elevation data is added. |
| Geological map directly marks sand traps or stable bedrock | Regional geologic units do not directly establish local load-bearing ability or trafficability. | **Do not auto-label sand traps from USGS units.** Keep USGS geology as optional contextual information. |
| `[OBSERVED]` slope/cost grid | Observed orbital imagery ≠ measured pathfinding cell costs. | Mark the basemap **NASA OBSERVATION** and cost surface **SIMULATION**; only genuine computed geospatial quantities with documented methods may be **DERIVED**. |
| Fog of War reveals *true* cell costs via LiDAR | No actual LiDAR or sensor stream is present. | **Cut** moving sensor cones. Any Fog of War, if added, must be labeled **SIMULATED / visualization only**. |
| Oxygen, battery, radio, radiation, live weather, range rings | Several arbitrary models would distract and risk appearing scientifically validated. | **Cut from core**; optional cosmetic simulated telemetry only after core passes all tests. No claims of safe return range. |
| Moving dust/radiation hazard and automatic rerouting | Multiple hazard models are unnecessary. | **Keep one user-triggered simulated hazard zone** and deterministic A* recomputation. Add explicit **Return to Hab** action. |
| Three rover POV photos precisely matched to waypoints | Surface image acquisition metadata can be available, but a matching geographic location must be demonstrated, not guessed. | **One optional credited rover image** as a reference panel; label **'illustrative surface image — not verified at selected map waypoint'** unless coordinates are documented. |
| Two complete modes (planning table and visor/wrist) | Double layout effort. | **One responsive HUD**; a minimal CSS-only compact mode is stretch. |
| One-year domain via Porkbun | Claim/verification/renewal adds setup work. | **Skip**. Use GitHub Pages or another existing static host. |
| 60–90 second submission video | **Conflicts with 2026 submission guidance.** | **Video ≤30 s**, or **≤7 slides**. Keep a longer walkthrough only as optional supplementary material. |
| Agent-generated implementation is assumed correct | Codex/Copilot can write code but cannot validate NASA data lineage or demonstrate that a simulated cost is measured. | Human owner audits every sourced asset, formula, and final demo. |

## 3. Midnight v0.1 feature contract (MUST)

1. **Real NASA visual evidence:** a Mars Trek image/layer for one Martian area, with exact source URL, layer/mission name if known, coverage/scale if known, and credits. Display a source link **inside the application**. No invented coordinates, instrument or resolution. The team must verify access/use conditions for the exported asset.
2. **Hypothetical Hab and one science destination:** user can select a destination on a bounded map; the Hab is fixed. Mark both as **hypothetical positions** unless tied to validated real coordinates. Show a short science objective.
3. **Two routes:** use A* over a deterministic 40×40 illustrative cost grid. Show **direct/shortest** vs **lower simulated exposure** route, or one A* route before/after hazard. Route lengths use **approximate map-scale distances** only when the spatial scale is actually calibrated.
4. **Emergency scenario:** a button named **'Simulate dust hazard'** adds a visible rectangular/circular high-cost or blocked region that intersects the first route; A* recomputes around it. A **'Return to Hab'** control plans from the simulated current position to Hab.
5. **Scientific honesty:** visually distinguish **NASA SOURCE**, **DERIVED (only when verified)**, **SIMULATED**. Persistent line: *'Hackathon planning demonstrator — simulated hazards/routes; not flight-qualified navigation.'*
6. **Working public app by midnight:** app loads without secrets or paid APIs; show credits, source links, instructions and tested public URL. **Produce the ≤30-second demo video and submit the official form on Sunday, not in tonight's coding window.**

### Strong stretch features (only if the six MUST items are done)

- One Perseverance raw image with exact gallery link, sol/camera/image ID **as available**, and the correct 'not location-verified' caveat.
- A simple compact/wrist-HUD styling toggle (CSS only).
- An optional **simulated** oxygen percentage display with all assumptions shown (do not call it suit prediction).
- Derived slope costs **only if** correctly aligned elevation data, actual units/projection and slope computation have been tested.

### Explicitly out of scope this weekend

True LiDAR, fog-of-war sensor fusion, moving weather physics, live Martian weather, real radiation nowcasting, realistic suit life-support forecasting, real-time comms, boulder avoidance, 3D terrain, calibrated safety limits, multiple science-stop schedules, offline NASA GIS pipelines, account/backend, domain acquisition.

## 4. Data truth table

| Visible element | Source/data condition | Displayed label |
| --- | --- | --- |
| NASA Mars Trek image or exact NASA layer | Actual downloaded or linked NASA asset; metadata logged | `NASA SOURCE` |
| Perseverance photo | Actual photo with gallery URL/credit | `NASA PHOTO` |
| Path cost grid | Hand-designed/testing grid without validated terrain measurements | `SIMULATED COST` |
| Hazard (dust or 'restricted sector') | Synthetic button-triggered scenario | `SIMULATED HAZARD` |
| A* route over synthetic costs | Algorithmically computed *from the synthetic grid* | `MODEL OUTPUT — SIMULATED INPUTS` |
| Distance or time | Only calculated if scale exists; walking speed is hypothetical | `ESTIMATE / ASSUMED SPEED` |
| Geology label | Only if actual mapped unit and geolocation established | `INTERPRETED — USGS SOURCE` |

**Never** turn a Mars Trek screenshot into numerical slope values by interpreting pixel color, unless the layer's documented numeric legend and coordinate transform are explicitly validated. Never place rover imagery as if it were captured at a clicked pixel without geolocation evidence.

## 5. Deployment strategy and fallback gates

**Recommended stack:** `index.html` + `style.css` + plain JavaScript (ES modules or one file) + HTML Canvas or SVG + local `/assets/` NASA-sourced map. No backend, secrets, build dependencies, or billing. A local static server may be used for testing; GitHub Pages can host it.

- **After 75–90 minutes of NASA data research:** If a *georeferenced* elevation grid is unavailable, **stop chasing DEMs**. Use a genuinely sourced NASA image as backdrop and a clearly *simulated* 40×40 planning grid. The correct scientific statement is 'NASA imagery provides scene context; our A* demonstration does **not** measure physical terrain safety.'
- **If Mars Trek basemap export is blocked:** document the obstacle; seek an alternate accessible NASA challenge-listed map/layer. Do **not** create a fake NASA base image or claim scientific accuracy from artwork. A genuine Perseverance image could still be used as science context, but **a photo-only mock-up is a weaker match** to the layered map objective.
- **If A* is unreliable:** revert to a deterministic, tested shortest-path grid before polishing visual effects.
- **If dynamic rerouting cannot be completed:** keep the map and a static before/after alternate-route comparison; submit a working partial prototype honestly.
- **If time is running out:** submission/demo/docs outrank optional visual details. Finish the NASA Space Apps Project tab, not only GitHub.

## 6. Implementation decisions for agents

- Grid: **40×40** on a **4 km×4 km conceptual extent** = **100 m/cell nominal**. Explicitly call it too coarse for individual obstacles.
- Movement: 8 neighbors; cardinal distance `1`, diagonal `sqrt(2)`, but **disallow diagonal corner-cutting** through blocked cells.
- A* edge cost: `movementDistance × (1 + costPenalty[nextCell])` for nonnegative penalties. `Infinity`/blocked means no traversal. Euclidean A* heuristic × minimum traversal cost is admissible; return `no path` safely.
- Direct route uses zero hazard penalty; alternative route uses the changed simulated grid. UI must show that differences are *scenario assumptions*, not measurements.
- Deterministic seed and a preselected example ensure the hazard definitely intersects the initial route and causes a visually demonstrable reroute.
- The only UI-dependent simulation needed is an **instantaneous hazard trigger**. No simulation clock required.
- Document how example costs were chosen; they are invented for interface testing.

## 7. Saturday-to-midnight build budget (planning example)

**Internal freeze:** 00:00 on Sunday 15 November 2026 (the end of Saturday 14 November). If the start time is later than roughly midday, shorten or drop non-core blocks rather than extending the freeze. The following is a **12-hour capacity budget**, not a claim about hours remaining right now.

| Elapsed build time | Work | Exit / stop condition |
| --- | --- | --- |
| 0:00–1:00 | Repo boot, inspect NASA resource, record provenance | Usable asset found or fallback explicitly chosen (no fake NASA data) |
| 1:00–3:00 | Responsive dark HUD, map, Hab, destination, provenance labels | Interactive map renders locally |
| 3:00–5:30 | Deterministic cost grid, A* and path tests | Open/detour/blocked/corner-cut/no-path test cases pass |
| 5:30–7:00 | Dust hazard injection, route recomputation, Return to Hab | An obvious before/after route change and return behavior |
| 7:00–8:15 | Genuine NASA data usage audit, UI disclosure, credits | One used NASA source linked and not misrepresented; note Relevance limitation if contextual only |
| 8:15–9:30 | Keyboard/mobile checks, error handling, lightweight visual polish | Usable with no console errors |
| 9:30–10:30 | Static deployment, check public URL/incognito | Hosted site works without API keys |
| 10:30–12:00 | Final test, source register, README, commit/tag, contingency | Code frozen and reproducible by midnight |

**Absolute cutoffs:** **21:30** no new features; **22:30** dependency/data freeze; **23:15** public deploy verification; **23:45** final code freeze commit. The official demo video is **tomorrow**, after midnight. The event project submission deadline remains **Sunday 15 November 2026, 23:59 local event time**.

## 7A. What the judges will actually evaluate

From the **official NASA Space Apps 2026 Judging & Awards Guide (13 November 2026), pages 5–8**, each criterion is scored from **1 to 5**:

| Criterion | Evidence ARES-HUD should provide by midnight | Pitfall |
| --- | --- | --- |
| **Impact** | Explain who needs a localized EVA decision tool and why the return route matters | Unsubstantiated claim that the system is ready to keep real astronauts alive |
| **Creativity** | Interactive wrist/visor mini-map with a sudden hazard detour | Cosmetic complexity without an operational interaction |
| **Validity** | Deterministic route algorithm, tests, transparent grid assumptions, accessible UI | Treating synthetic terrain costs as NASA-measured hazards |
| **Relevance** | Actually used challenge-listed NASA asset with provenance, meaningful layer/inspection affordance | A NASA image used only as decoration while all outputs are entirely synthetic |
| **Presentation** | Clear first-run demo state, visible before/after change, understandable legend | A beautiful interface that cannot be explained in 30 seconds |

**Highest risk remains Relevance**, because a real Mars visual does not by itself make a simulated route NASA-derived. If a genuine validated geographic data layer is available, prioritize a meaningful interaction with it (measured surface layer inspection or appropriately validated terrain quantity) over extra effects; otherwise disclose the limitation honestly. **Do not auto-extract slope from a map screenshot.**

See [JUDGING_CHECKLIST.md](JUDGING_CHECKLIST.md) for the exact team eligibility, 30-second/7-slide rules, language, references, and official submission process.

## 8. Acceptance checklist

- [ ] App runs from clean checkout, with no cloud account and no secrets.
- [ ] At least one **actually used**, challenge-listed NASA source is credited and shown in app; all source URLs resolve.
- [ ] The NASA image and synthetic routing grid are explicitly differentiated.
- [ ] Hab, science destination and route can be seen at once.
- [ ] Simulated hazard alters the route; if unreachable, UI says so.
- [ ] Return-to-Hab route works after hazard trigger.
- [ ] Grid tests cover open, blocked, detour, and no-path cases.
- [ ] No falsely precise slope, oxygen, distance, radio or rover-photo location claim.
- [ ] README states implemented vs proposed functionality; tool/AI assistance disclosed.
- [ ] Public link works in private/incognito window **by midnight**.
- [ ] App code is committed/frozen by midnight.
- [ ] **Sunday only:** demo video is ≤30 seconds (or deck ≤7 slides), required form fields/references filled, and project submitted through NASA Space Apps.

## 9. Global Offers and AI-agent decision

| Tool | Decision for day 1 | Why |
| --- | --- | --- |
| **Codex** | **Use if already accessible** | General coding/build/testing agent; **not one of the 11 copied NASA Global Offers**. Grant repo workspace; review generated code and tests. |
| **GitHub Copilot Free** | **Use optionally** | The relevant Global Offer for editor-level code help. Free chat/agent usage is limited; do not depend on its quota. |
| **Microsoft Copilot** | Optional | Second-opinion explanations/pitch copy, not source of NASA scientific facts. |
| **GitHub Pages** | **Use** | Free static deployment, not a listed Global Offer; avoids trial setup. |
| **Miro templates** | Skip unless needed | Simple Markdown backlog is faster when solo. |
| **GoDaddy/Porkbun domain offer** | Skip | Domain verification and renewal terms are unnecessary for judges. |
| **Azure, Google Cloud, Miro Business** | Skip | Unneeded account and card/trial complexity. |
| **Planetary Computer, Meteomatics, Google Maps** | Skip | Primarily **Earth** services; not sources for Mars terrain or weather. |

**Agent model:** One coding agent at a time in the working branch; assign **data-source verification to the human owner**. Parallel agents editing the same `index.html`/`app.js` risk merge and integration overhead. Review each milestone before moving on.

## 10. Primary links and evidence

- [2026 challenge (official)](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/); [full readable challenge and resources (local-event mirror)](https://hackathlone.com/challenges/interplanetary-survival-guide-martian-map)
- [NASA Mars Trek](https://trek.nasa.gov/mars/); [Mars Trek capabilities/about](https://trek.nasa.gov/mars/jpl/config/textAbout.html)
- [Perseverance raw images](https://mars.nasa.gov/mars2020/multimedia/raw-images/); [USGS Mars maps](https://astrogeology-usgs.hub.arcgis.com/pages/interactive-maps-mars)
- [2026 official Judging & Awards Guide](https://www.spaceappschallenge.org/resources/judging-awards-guide/) — team's uploaded PDF dated 13 November 2026; pages 3, 5–8.
- [2026 schedule and submission deadline](https://www.spaceappschallenge.org/2026/)
- [NASA Space Apps team response — challenge-listed NASA data and citations](https://github.com/nasa/spaceapps/discussions/1827)
- [2026 submission clarification — demo <=30 seconds / <=7 slides](https://github.com/nasa/spaceapps/discussions/1991)

**Evidence limitations:** This audit verified Mars Trek's *general* support for downloading/layering/slope tools, **not** a specific Jezero layer's exportability, resolution, instrument attribution, or map projection. Those remain to be checked against the chosen actual asset. The team-supplied Global Offers are described in `toolgiven.md`; Codex is outside that copied offer list.
