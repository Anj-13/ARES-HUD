> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

> HISTORICAL EVIDENCE: prior report, not current acceptance. [UNVERIFIED] Old test/commit claims unless independently repeated in [AUDIT_CURRENT.md](AUDIT_CURRENT.md). [STATUS.md](../STATUS.md) controls current migration status.

> HISTORICAL DESIGN REFERENCE - checked by source inspection on 14 November 2026 against the dirty working tree over 5d79741. This describes the existing three-space design, not Leaflet. See [current architecture](ARCHITECTURE.md#part-a-current-implementation) for proposals and [STATUS.md](../STATUS.md) for verification limits.

# Map architecture

Three independent spaces prevent false registration:

1. **Mars Trek explorer:** a 1024x1024 CSS tile plane, 4x4 unchanged WMTS images. Pointer drag and buttons pan; zoom scales around viewport center. Geographic pointer readout uses the documented level-10 matrix origin (-180,90), tile dimensions 256px, and angular span 180/1024 degrees. See tileCoordinate in mission.js. No Earth map library or assumed WGS84 conversion.
2. **USGS geological reference:** original educational PDF in a separate object viewer, with downloadable fallback and unit selector. Its map service uses a different Mars projected CRS; no overlay transform or feature click-identify is asserted.
3. **EVA simulation:** existing 400x400 SVG and 40x40 grid. Grid coordinates are integers, not longitude/latitude. The 4km extent is conceptual. The NASA THEMIS image is now separate rather than deceptively registered beneath the grid.

Dataset metadata lives in datasets.js, with source snapshots and tile manifest in assets/. Each record has ID, name, organization, URL, local resource, mission, coverage, CRS, resolution, classification, attribution and limitations. Unknown fields are null.

mission.js composes unchanged A* results for ordered stops. Failure of any leg produces no complete route. Hazard changes re-evaluate all remaining stops from simulated current position. Simulate arrival completes the next selected stop and replans the rest; Return to Hab cancels traverse mode and routes from current position. This is an instantaneous simulation, not motion telemetry. Costs are additive abstract weights.

Layer controls affect display only, including hazard shading: hiding a hazard never removes its route blockage. Source cards distinguish OBSERVED imagery, INTERPRETED geology and SIMULATED markers/costs. No DERIVED slope exists. Local imagery failures show fallback messages without changing routing. A PDF plugin is optional because a full-document link remains available.

Runtime remains static and dependency-free. Worldview and Curiosity are credited inspirations; their data and route geometry are not used.
