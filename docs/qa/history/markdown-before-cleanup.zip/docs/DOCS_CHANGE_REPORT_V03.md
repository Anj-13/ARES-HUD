> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

# DOCS CHANGE REPORT - planned ARES-HUD v0.3

Documentation only. The prior Task 0D audit, test/asset findings and historical reports remain preserved. Baseline commit before this update: e1c6638 plus existing uncommitted application changes and staged snapshot deletions. No Task 7 spike, renderer installation, asset acquisition or implementation took place. STATUS.md lists Task 7 NOT STARTED, commit none, with no verification evidence fabricated.

## Files changed in this documentation commit

- AGENTS.md: Discovery policy/approved root entry points, latest no-new-build precedence.
- README.md: Planned two-scale vision, unchanged current implementation, refreshed index.
- STATUS.md: Task 7 NOT STARTED and policy/schedule evidence limits.
- docs/AGENTS.md: Current workflow precedence notice; old operating instructions retained.
- docs/AGENT_RULES_ADDENDUM.md: Scoped globe exception, separate gates, per-scale viewport ownership and Sunday schedule.
- docs/AGENT_TASKS.md: New standalone Task 7 specification and 2D-only viewport scope; other task details preserved.
- docs/FEATURE_PLAN.md: v0.3 Planetary/Surface views, transition and original v0.2 feature inventory.
- docs/ARCHITECTURE.md: Part A preserved; globe assets/markers/controller/fallback in Part B only.
- docs/DATA_SOURCES.md: WMTS documentation check and unverified globe/coordinate source queue; existing hashes/credits preserved.
- docs/CODEX_OPTION_2_HANDOFF.md: Handoff includes separate Task 7 gate and corrected event-local submission wording.
- docs/DOCS_CHANGE_REPORT_V03.md: This report, exact test transcript, decisions and validation.

Some policy/task/plan files already contained partial v0.3 text when this turn began; this commit preserves/completes it together with the preceding staged owner-schedule reconciliation. Previously ignored owner documents become tracked documentation. No existing application change or staged non-document deletion is included.

## Conflicts resolved

- Old blanket globe prohibition now has only the explicitly scoped Task 7 exception; all other prohibitions remain. Exception is feature approval, not selection of a renderer or full implementation authority.
- Leaflet is sole Surface Mode/2D owner; proposed globe renderer owns Planetary Mode only. Existing Task 1 checks are scoped to 2D, not a prohibition on legitimate globe projection.
- v0.3 planning is separate from current three-space code and from v0.2 acceptance. No registered map or globe is asserted to exist today.
- Latest no-new-build request governs this release; earlier React/Vite migration is deferred. No dependency/build code changed. Any future new build needs explicit owner approval.
- Option 2 overrides Saturday/midnight gates: Sunday 15 November 2026 GMT 13:30 feature cutoff, 14:30 dependency/data freeze, 15:15 deployment check, 15:45 final Git commit, 16:00 code freeze. Submission remains event-local 23:59; a 7h59 buffer is true only if that timezone is GMT.
- Tier A remains 0/0D/1/3, Tier B 2/6 after verified A. Task 7 depends on verified 1, cannot displace A/B, and has a separate owner go/no-go. Task 5 retains its independent numeric-data/owner gate.
- Root README/STATUS were already explicitly owner-requested; stale root-README deferral and index entries for root owner-input copies no longer present were corrected. Source of feature completion remains STATUS.md only.

## Exact Task 7 spike criteria and stop conditions

The authoritative complete specification is [Task 7](AGENT_TASKS.md#task-7---3d-mars-globe).

Maximum **60 minutes**, ending no later than **13:30 GMT Sunday**. Suggested split: 15 minutes renderer/license/static loading, 20 imagery/capabilities/acquisition, 20 real-browser/performance/fallback, 5 evidence/recommendation. Begin only after verified Task 1 and only with A/B and release time protected. This documentation task does not begin the spike.

Required evidence: exact renderer/version/license/vendor files and byte counts, justified static loading and Mars-radius/custom-ellipsoid behavior; actual global WMTS capabilities and authorized texture/conversion path; projection/coordinate/UV/pole/seam alignment; CORS/pixel-read result if browser acquisition needs it; offline encoded bytes/decoded dimensions/GPU estimate; identified laptop/browser/WebGL limits, first usable load, responsiveness/frame rate and observable peak memory; context loss, missing texture, unsupported WebGL, keyboard/focus/reduced-motion/360px checks and honest direct 2D fallback. Unknown measurements stay unmeasured. Prefer explicit Mars support, never silently Earth defaults.

STOP at 60 minutes or feature cutoff, failed prerequisite, risk to A/B, unavailable authoritative imagery/coordinates, unclear permissions, incompatible texture/projection, unresolved required CORS, unapproved/unacceptable size, no viable static renderer or failed browser/fallback checks. Preserve 2D, label 3D NOT IMPLEMENTED, report evidence and STOP for separate owner decision even if feasible. No implementation or new feature spike after cutoff; dependency/data and release gates remain binding.

Full acceptance after owner go requires real credited rotatable/zoomable Mars, verified source-linked rover markers, distinct hypothetical sector, both transition directions with preserved plan, original art, no tablet 3D, keyboard/reduced-motion/responsive fallback, real browser/asset-failure tests and all existing tests passing. Nothing here certifies that acceptance.

## OWNER DECISIONS

1. After the spike, select/approve a renderer with exact pinned version, permissive license and locally vendored package. No candidate is preselected.
2. Give separate go/no-go for full Task 7 implementation and an implementation stop point/time budget, without displacing A/B or release gates.
3. Set maximum new dependency bytes, total offline/download asset size, texture dimensions/GPU-memory budget and acceptable laptop load/frame/memory limits. Spike reports measurements/proposals; no invented ceiling is a safety or acceptance standard.
4. Approve any new dependency or acquisition/conversion method/terms; reconfirm explicitly if a build step is desired. No globe dependency or asset approval is inferred from vision approval.

## Sources and checks

[Official Mars Trek WMTS documentation](https://trek.nasa.gov/tiles/apidoc/trekAPI.html?body=mars) was opened through the web tool: it describes RESTful WMTS, capability-derived parameters and PNG/JPG variants. [NASA API portal](https://api.nasa.gov/) returned a key-signup/JavaScript shell. Neither fetch verifies a global layer, texture availability, renderer, mission coordinates or browser CORS. Other provided reference URLs are discovery/reference inputs, not newly verified datasets. No new credits, hashes or coordinate values were fabricated. Source-register integrity checks from Task 0D remain intact.

Current npm.cmd test executed with exit 0; exact captured output follows. Historical 15-check browser pass remains REPORTED; no browser performance, WebGL or implementation acceptance was executed in this documentation turn.

```text

> test
> node --test pathfinding.test.js mission.test.js

✔ ordered stops and cumulative cost (6.6423ms)
✔ hazard recalculates traverse and return (33.2329ms)
✔ unreachable mission yields no misleading partial route (0.6318ms)
✔ layer state is independent and immutable (0.902ms)
✔ tile transform matches WMTS top-left and tile span (0.591ms)
✔ dataset identifiers, attribution and local assets (7ms)
✔ straight and diagonal optimal routes (6.1956ms)
✔ symmetric blocked detour is deterministic (3.0618ms)
✔ enclosed goal has no path (0.609ms)
✔ blocked endpoints and empty grid return null (0.4613ms)
✔ diagonal cannot cut either blocked corner (0.7015ms)
✔ fixed dust zone changes route and permits return (30.2233ms)
✔ penalties influence routing and negatives clamp to zero (1.2043ms)
✔ same endpoint returns zero cost (1.0215ms)
ℹ tests 14
ℹ suites 0
ℹ pass 14
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 267.064
```

## Final validation

Executed Python stdin validation: 25 Markdown files decode as UTF-8; zero relative path/anchor errors, mojibake patterns or README inventory omissions. All 39 non-document files match the start-of-turn SHA-256 baseline. Eight historical evidence documents match the prior audit commit after normalizing checkout line endings; an initial strict byte comparison detected CRLF/LF checkout differences, not content changes. All existing 14 Node tests passed (exact transcript above). Task 7 remains NOT STARTED; no browser/spike evidence fabricated. Explicit documentation-only commit paths preserve preexisting staged snapshot deletions and application edits.
