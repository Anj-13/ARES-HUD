> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

# ARES-HUD architecture

## Part A: CURRENT IMPLEMENTATION

Current code inspected at `0036eac` plus uncommitted feature work on 14 November 2026; fresh feature evidence is in [FEATURE_IMPLEMENTATION_REPORT.md](FEATURE_IMPLEMENTATION_REPORT.md). Fresh test evidence and limitations are in [AUDIT_CURRENT.md](AUDIT_CURRENT.md); [STATUS.md](../STATUS.md) alone records acceptance. Prior report commit identifiers are not treated as verified local history.

Local development: `python serve.py` serves the repository on loopback port 8012 with no-store headers. This helper is not a production backend; static hosting remains unchanged.

### Components and exports

| File | Responsibility / exports |
| --- | --- |
| ../index.html | Entry; loads vendored Leaflet, then app.js and exploration.js as modules; styles.css; local reference assets |
| ../browser-test.html | ES-module harness: projection spike plus application checks driving index.html in an iframe; 81 checks |
| ../app.js | Scenario state, Leaflet layer orchestration and DOM handlers; `window.__aresHudTest` hooks exist for the harness only |
| ../map-crs.js | Exports MARS_RADIUS (3,396,190), METRES_PER_DEGREE, createMarsEq/MARS_EQ and marsDistance. MarsEQ extends L.CRS.EPSG4326 with the Mars radius; it contains no pixel maths of its own |
| ../sector.js | Exports SECTOR (bounds, centre, Hab, stops), TILE_BOUNDS, MIN_ZOOM, MAX_NATIVE_ZOOM, MAX_ZOOM |
| ../geo.js | Pure grid and sector maths: gridToLatLng, gridCornerToLatLng, latLngToGrid, metersBetween, bearing, tileIndex, tileRange, sectorSpanMeters, cellLat, cellLng. No Leaflet, no screen projection |
| ../geo.test.js | 9 Node tests: grid round-trip, bounds, 4,000 m spans, 100 m cells, bearing, tile indices/ranges for levels 10-12, outside-sector rejection |
| ../map.js | Exports createSectorMap(element, options) and PANE_Z: Leaflet map, panes, local tile layer, scale/attribution controls, resetView, probeTileError |
| ../sector-layers.js | Exports drawGrid, drawHazards, drawRoute, drawMarkers: Leaflet polylines, rectangles and divIcon markers built from geo.js positions. Never imports pathfinding.js |
| ../exploration.js | Source cards, USGS reference panel and surface-image fallback; no viewport code |
| ../datasets.js | Exports datasets: four NASA/USGS resource metadata records with unknown fields null |
| ../mission.js | Exports planMission, moveStop, layerState (tileCoordinate was removed in Task 1) |
| ../pathfinding.js | Exports SIZE, HAB, SCIENCE, createGrid, findPath; pure grid/search, independent of Leaflet |
| ../pathfinding.test.js | 8 Node tests; no exports |
| ../mission.test.js | 5 Node tests for mission ordering/cost/failure, layer immutability and local dataset assets |
| ../scripts/fetch-tiles.mjs | Idempotent tile downloader and manifest writer |
| ../scripts/vendor-leaflet.mjs | Downloads and hashes the pinned Leaflet 1.9.4 files |
| ../vendor/leaflet/ | Leaflet 1.9.4 (BSD-2-Clause) JavaScript, CSS, images and LICENSE |
| ../styles.css | Dark HUD, responsive layout, Leaflet control and divIcon marker styling, native focus styles |
| ../package.json | ES module mode; test script only; no runtime dependencies or build tooling |
| ../assets/ | 24 CTX PNGs by level plus manifest, catalog/capabilities snapshots, USGS PDF/service metadata and two NASA JPEGs |

### One registered map

One Leaflet map owns the Surface Mode viewport: pan, zoom, touch, keyboard, scroll wheel, tile loading, lat/lng-to-screen projection and the scale bar. The application has no CSS-transform pan/zoom and no second lon/lat-to-pixel function; every overlay is placed by Leaflet from geo.js coordinates.

- CRS: MarsEQ, i.e. EPSG4326 with R = 3,396,190 m (Mars 2000 sphere). Because the Trek WMTS matrix is also a plain geographic grid with origin -180, 90, Leaflet zoom equals the WMTS level with no zoomOffset, and Leaflet y equals the row. The zoom-0, tile-index, distance and 4,000 m spike assertions in browser-test.html prove this.
- Tiles: `assets/trek/{z}/{y}-{x}.png`, tileSize 256, noWrap, minZoom 10, maxNativeZoom 12, maxZoom 14, bounds = sector plus one tile margin, tileerror handler, attribution "NASA/JPL-Caltech/MSSS, via NASA Mars Trek". Zooming past 12 shows an explicit overzoom notice.
- Panes (z-index): tiles 200, grid 410, hazards 420, fog 430 (simulated knowledge outlines), routes 450, markers 600. Leaflet creates a separate canvas per pane for grid, hazards, reconnaissance and routes; a shared renderer would override pane ordering.
- The view fits the 4 km sector bounds on load and on reset, so a narrow screen still shows the Hab and every stop; zoomSnap 0.5 and maxBoundsViscosity 1 apply.
- Markers are L.marker with L.divIcon containing a native button, keyboard true and an aria-label.
- Reduced motion disables zoomAnimation, fadeAnimation, markerZoomAnimation and inertia.

### State and data flow

app.js holds hazard, current cell, goal, mission flag, a test-only grid override and three stop records with selected state/order, all on the simulated 40 x 40 grid. Selection, ordering, hazard, position and arrival changes trigger a redraw: createGrid, optional override, planMission, then rebuild of the hazard rectangles, route polylines, markers, status text and segment list. Plan selected traverse switches to mission mode over the selected stops. Simulate arrival moves current to the next selected stop and deselects it. Return to Hab sets the goal to the Hab. Reset clears hazard, restores current/goal, reselects all stops and preserves their order. Layer toggles call Leaflet add/remove or setOpacity; hiding hazard shading never unblocks cells because blocking lives in the grid, not the layer.

planMission concatenates leg paths without duplicate junctions and sums cost; any failed leg returns null, so no misleading partial route is drawn. A dashed polyline shows the pre-hazard route whenever a hazard is active. No persistence, backend or live movement exists.

### A* and hazard inputs

Grid: 1,600 cells with penalty, blocked and hazard flags. The app's endpoints come from sector.js: Hab (4,20) and stops at (23,14), (14,10) and (28,26). pathfinding.js keeps its own exported HAB (5,20) and SCIENCE (34,20) sample constants for its tests only. Rows 0-7 and 33-39 have penalty 0.8; other rows zero. Dust blocks columns 18-22, rows 12-28 inclusive. All are SIMULATED.

findPath rejects invalid/non-integer or blocked endpoints and returns null when disconnected. It explores eight fixed-order neighbours; diagonals require both adjacent orthogonal cells traversable. Entering cost is step length * (1 + max(0, penalty)), step lengths 1 or sqrt(2). The Euclidean heuristic is admissible for the generated finite non-negative costs. A sorted open array uses insertion-order ties; score/parent maps record improvements and stale entries are skipped. The result includes endpoints plus an abstract cost; a single point has zero cost. The UI reports grid steps, simulated cost units and a DERIVED great-circle trail length in metres.

### Limits

The sector, Hab, stops, grid, hazard and costs are SIMULATED; only the imagery is OBSERVED. Registration comes solely from the tile matrix; it is not a survey of the real landing site. There is no elevation model, slope product, terrain processor or production 3D globe. Tablet handoff, Sol timeline and simulated reconnaissance are implemented as described below. Software remains a conceptual prototype, not flight-qualified navigation.

### Tablet, timeline and simulated knowledge

- `plan.js`: validated input-only base64url payload, schema 1, FNV-1a corruption checksum. Optional reconnaissance snapshot carries enabled state, fixed 0.5 penalty and revealed cell keys. Grid cells remain separate from geographic coordinates; the receiving client resolves sector geometry locally. See feature report for size/validation limits and the schema extension.
- `tablet.html` / `tablet.js`: independent same-origin Leaflet map using the existing factory and overlay functions; local route computation, heading, distance, dust, Return to Hab and reset. Native dialog in mission control embeds this static page; copying the URL reproduces a snapshot, not live synchronization. The tablet has no WebGL.
- `sols.js`: eight hypothetical Hab-to-science-to-Hab excursions and cumulative modeled costs; `positionAt` interpolates by cost, not physical time. `mission-controls.js` owns scrub/play/pause/speed, log, reference trail and marker. Ordinary planner actions exit preview. Handoff snaps to the last reached integer cell.
- `fog.js`: pure radius-three reveal and immutable uncertainty-penalty application. The controller rebuilds knowledge from the traveled reference trail at a scrub point, renders outline-only cells in the fog pane, and recalculates a candidate remainder from the reached cell. The reference replay itself is fixed. This is planning knowledge, not observed obstacle detection.
- Native controls and focus restoration, reduced-motion stepping, visible scientific labels and non-flight-qualified warning are browser-tested. No runtime service, backend or extra dependency was introduced. Tests: plan.test.js, sols.test.js and fog.test.js, plus the extended browser harness.

## Part B: TARGET ARCHITECTURE — NOT YET IMPLEMENTED

Everything in this part is the PLANNED v0.3 target, not implementation. [STATUS.md](../STATUS.md) alone records feature status. The latest owner request preserves static ES modules and no backend; a new build step requires explicit approval, so earlier React/Vite migration is deferred. Task 7 is separately gated and cannot replace Task 1 or displace Tier A/B.

### Two-scale ownership and transition (proposed)

Planetary Mode would use a separately selected, pinned and locally vendored permissive renderer. Surface Mode and tablet would use Leaflet 1.9.x only. No 3D is required on tablet. The globe would present authentic global Mars imagery and source-linked real mission facts; selecting the hypothetical ARES sector would open the registered 2D Jezero map. Selecting Curiosity supplies Gale context, never a Gale route on Jezero. Return to Planetary Mode would preserve the validated surface plan and focus.

A view controller would pause/dispose hidden globe resources, support reduced-motion immediate transitions and avoid dual render loops. Unsupported/lost WebGL, missing global assets or a failed Task 7 gate would show an honest unavailable state and direct access to the verified 2D map. This fallback is a target requirement, not a claim that the current conceptual grid is already registered.

Proposed globe assets would live in a dedicated local cache with source URL, credit, retrieval date, bytes, hashes and conversion lineage. Mission marker data would store authoritative coordinate source, frame/convention, epoch and location type (landing site or dated position); missing current positions/traverses would be omitted, never inferred. Astronaut sector/positions/hazards/costs remain SIMULATED; real imagery OBSERVED, coordinate conversions DERIVED after verification, geological interpretation INTERPRETED.


Leaflet owns the Surface Mode viewport under the MarsEQ CRS (FEATURE_PLAN ADR-1); that part of the plan is implemented and described in Part A. The spike verified matrix alignment, tile indexing and Mars distance behaviour in browser-test.html. Pure routing remains independent of Leaflet. A custom image overlay must not imply unverified geographic registration.

| Proposed module | Intended responsibility |
| --- | --- |
| View controller (proposed name: views.js) | Switch Planetary/Surface Mode, preserve validated state/focus and handle reduced motion/fallback; static modules |
| Proposed globe.js / globe-missions.js | Planetary renderer adapter and source-linked verified mission markers; no 2D projection ownership |
| Proposed assets/globe/ manifest | Local global texture/tiles, metadata, hashes and any documented conversion lineage |
| map-crs.js | DELIVERED by Task 1: verified Leaflet Mars CRS |
| sector.js / geo.js | DELIVERED by Task 1: hypothetical sector definition, pure grid/geographic/metre/bearing math; no screen projection |
| map.js / sector-layers.js | Shared Leaflet map factory and geographic overlays |



| offline terrain processor / derived slope asset | Optional Python + NumPy or documented equivalent after verified numeric elevation and owner gate |

### Migration map (proposals only)

Rows for Task 1 below describe existing code pending full acceptance; the current modules are described in Part A and status is recorded only in [STATUS.md](../STATUS.md).

| Current file | Target | Action | Task |
| --- | --- | --- | --- |
| app.js / index.html | static Surface Mode UI plus shared map factory | replace integration after acceptance, preserve routing/tests | 1 |
| exploration.js custom viewport | Leaflet map.js / map-crs.js | replace after CRS checks | 1 |
| mission.js tileCoordinate | Leaflet projection / pure geo helpers | replace old screen-linked arithmetic; retain mission composition | 1 |
| pathfinding.js / mission.js | same pure route engine | keep tested contracts | 1-6 |
| datasets.js / assets/ | source records and verified cache | keep, extend provenance only for actual new assets | 0/1 |
| none | sector.js, geo.js, sector-layers.js | new | 1 |
| none | plan.js and tablet files | new | 3 |
| none | sols.js / fog.js | new | 2/6 |
| none | terrain processor / slope | new, gated | 5 |
| none | globe adapter, mission data, local imagery cache and view transitions | new, gated spike then owner go/no-go | 7 |

No old file is authorized for deletion by this table; application changes belong to later tasks.
