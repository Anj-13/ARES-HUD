> ACTIVE REFERENCE - historical offer catalogue, not proof of redemption or current pricing/terms. Actual tool/implementation evidence is in [STATUS.md](../STATUS.md) and the root README.

# Global Offers — Tool Guide for Team Martian

**NASA Space Apps Challenge 2026 · Interplanetary Survival Guide: Martian Map**

**Source check (14 November):** The team also provided the official 11-page NASA Space Apps **Global Offers PDF**, confirming all eleven offer descriptions and numerical limits summarized here. This is an offer catalogue, **not** the judging rules; the separately uploaded 12-page 13 November **Judging & Awards Guide** controls the submission/eligibility details. See [JUDGING_CHECKLIST.md](JUDGING_CHECKLIST.md).

This file documents the **11 Global Offers** provided in the team's pasted 2026 Global Collaborators text. It explains what each tool is, what it can do, how to claim it, and whether its data/services are useful for a project focused on Mars. **It does not imply any offer has been claimed.** This edition adds a focused decision for the ARES-HUD one-day MVP while preserving the full offer catalogue.

## ARES-HUD: decisions for tonight’s code freeze (00:00 Sunday 15 November)

**Use:**

- **Codex, if already available** — a coding agent for building and testing the static frontend. **Codex is NOT included among the 11 Global Offers you pasted**; its availability is separate, so do not assume Space Apps provides Codex access or credits.
- **GitHub Copilot Free (Global Offer)** — optional autocomplete, chat and code review inside supported editors, subject to its free usage limits. Pick **one agent to own each code edit**; Copilot can provide help without creating conflicting branches.
- **GitHub Pages** — simple no-cost static deployment. Not a listed Global Offer; avoids cloud billing setup.
- **NASA Mars Trek + Perseverance resources** — scientifically relevant source material, **not** a Global Offer. Every displayed asset needs real provenance.

**Skip before midnight:** Azure, Google Cloud, Miro Business, Porkbun domain, Meteomatics, Microsoft Planetary Computer, Google Maps, and Earthdata Worldview. The Earth datasets cannot substitute for Mars measurements. **Microsoft Copilot** or a **Miro board template** are optional for planning, not required for coding.

**Critical distinction:** Code generation is not data verification. Do not let an agent infer measured slopes, hazard thresholds, oxygen consumption, location-matched rover photographs, or live Mars conditions from generic map imagery. The route penalty grid is **simulated** until verified georeferenced terrain measurements are integrated. See [AGENTS.md](AGENTS.md) and [one-day audit](ARES_HUD_ONE_DAY_AUDIT.md).

## How to claim an offer

1. Log in to [NASA Space Apps Challenge](https://www.spaceappschallenge.org/).
2. Open your profile/avatar menu and select **Offers**, or try the [2026 Global Offers page](https://www.spaceappschallenge.org/2026/global-offers/) while signed in.
3. Select the offering, click **Claim Offer**, and follow its provider-specific instructions.
4. Review eligibility, payment verification, expiration, and usage limits before activating a trial.

The offers are **optional**; you may use any number or none. The generic product links below are for learning about the services; **they may not activate Space Apps-specific benefits**. The claiming steps come from the provided offer descriptions and [NASA Space Apps organizer guidance](https://github.com/nasa/spaceapps/discussions/2035).

## Fast comparison

**Relevance** is an assessment for a Mars-focused coding project, not an official Space Apps rating. Actual usefulness depends on the team's later idea.

| # | Tool / offer | Type | Possible role | Mars relevance | Key access note |
| --- | --- | --- | --- | --- | --- |
| 1 | [Microsoft Azure](https://azure.microsoft.com/en-us/free/) | Cloud computing | Host an app, API, storage, or processing | Conditional | Eligible new users: **US$200 / 30 days**; verification may require payment card |
| 2 | [Microsoft Planetary Computer](https://planetarycomputer.microsoft.com/) | Earth-data APIs | Learn/use STAC and Earth-geospatial datasets | Low for Mars data | Public catalog and STAC API; some datasets need access token |
| 3 | [Microsoft Copilot](https://copilot.microsoft.com/) | AI assistant | Research, writing, explanations, planning support | Optional | Free access; other features depend on license/region |
| 4 | [GitHub Copilot](https://github.com/features/copilot) | Coding assistant | Editor code suggestions, chat, review, CLI | **Useful for a solo coder** | Free plan: up to **2,000 completions/month**, limited chat/agent use |
| 5 | [Microsoft Teams Free](https://www.microsoft.com/en-us/microsoft-teams/teams-free) | Collaboration | Chat, calls, file sharing if teammates join | Conditional | Up to 100 people; 60-minute meetings; 5 GB/user |
| 6 | [Google Cloud](https://cloud.google.com/free) | Cloud computing | Hosting, Firebase, backend, storage, ML services | Conditional | Trial **US$300 / 90 days**; card verification, no automatic charge after trial |
| 7 | [Meteomatics Weather API](https://www.meteomatics.com/en/weather-api/) | Weather API | Earth weather/climate comparisons | **Low for direct Mars data** | **1,000 queries/day**, hackathon-only access |
| 8 | [Miro Education](https://miro.com/education/) | Collaboration / canvas | Research notes, diagrams, brainstorming | Optional | Eligible students: 2 years free; educators: free indefinitely |
| 9 | [Miro Business](https://miro.com/pricing/) | Collaboration / canvas | Advanced team boards and planning | Optional | **14-day trial**; payment details required; cancel to avoid charges |
| 10 | [Miro Board Templates](https://miro.com/templates/nasa-space-apps/) | Collaboration templates | Ready-made hackathon planning/presentation boards | Optional | Free templates; sign in and use a template |
| 11 | [Free domain + website hosting](https://www.spaceapps.earth/) | Domain / hosting | Public project site and shareable URL | Conditional | **1 year**, non-premium domain only; SSL included; Porkbun fulfillment |

## Offer details

### 1. Microsoft Azure

- **What it is:** Microsoft's cloud platform for deploying web applications, APIs, databases, storage, and compute resources.
- **What it can do here:** Could provide a public deployment, backend processing, or a place to store permitted data assets if the chosen concept needs them.
- **Provided offer:** Eligible new Azure customers can receive **US$200 credit for 30 days**, plus free services subject to their specific quotas and durations.
- **How to access:** Claim via Space Apps → Azure page → **Try Azure for Free**.
- **Conditions:** Phone number, non-prepaid card, and Microsoft/GitHub sign-in may be needed. After trial credit expires, paid services require upgrading to pay-as-you-go. Check billing settings and spending limits.
- **Links:** [Azure free account](https://azure.microsoft.com/en-us/free/) · [Azure documentation](https://learn.microsoft.com/en-us/azure/)
- **Support (from offer):** samfal@microsoft.com

### 2. Microsoft Planetary Computer

- **What it is:** A cloud-hosted **Earth/environmental science** data catalog and APIs using the STAC (SpatioTemporal Asset Catalog) standard.
- **What it can do here:** Useful for learning geospatial data workflows or explicit Earth-versus-Mars comparisons **if the idea needs one**.
- **What it does *not* do:** Its extensive Earth catalog should **not** be assumed to supply Martian topography, Mars weather, or rover observations. Start with the challenge-listed NASA Mars resources for that.
- **Provided offer:** Data Catalog and STAC API publicly accessible without account; most datasets can be accessed anonymously, but some downloads may be throttled or need a free token.
- **How to access:** Open the catalog directly or claim from Space Apps.
- **Links:** [Planetary Computer](https://planetarycomputer.microsoft.com/) · [Documentation](https://planetarycomputer.microsoft.com/docs/) · [Data catalog guide](https://planetarycomputer.microsoft.com/docs/concepts/data-catalog/)
- **Support (from offer):** samfal@microsoft.com

### 3. Microsoft Copilot

- **What it is:** A general AI assistant for answers, brainstorming, drafting, and explanations.
- **What it can do here:** Could assist with documentation, research questions, or reviewing a plan **once the project direction is chosen**.
- **Provided offer:** Free individual access; Microsoft 365-related capabilities vary by license, region, and product.
- **How to access:** Claim through Space Apps → open/sign in to Copilot.
- **Limitations:** Verify generated scientific claims against NASA/mission sources; do not cite AI output as if it were NASA data. Declare AI assistance in the project submission as required.
- **Link:** [Microsoft Copilot](https://copilot.microsoft.com/)
- **Support (from offer):** samfal@microsoft.com

### 4. GitHub Copilot

- **What it is:** A coding assistant for completions, coding chat, agent assistance, code review, and selected command-line workflows.
- **What it can do here:** Help a solo developer work through code, tests, debugging, and documentation. It cannot replace checking scientific data, APIs, or model assumptions.
- **Provided offer:** **Copilot Free**, no credit card; up to **2,000 code completions per month**, with limited chat/agent use. Paid tiers are **not** included in this offer.
- **How to access:** Claim through Space Apps → sign into GitHub → choose **Copilot Free**.
- **Editors:** Supported environments include VS Code, Visual Studio, JetBrains IDEs, Eclipse, Xcode, and Neovim, with feature differences.
- **Links:** [GitHub Copilot](https://github.com/features/copilot) · [Copilot documentation](https://docs.github.com/en/copilot)
- **Support (from offer):** samfal@microsoft.com

### 5. Microsoft Teams Free

- **What it is:** Free meetings, messaging, file sharing, and screen sharing.
- **What it can do here:** Communicate with future teammates or mentors and share status/demo screens. Less essential for an entirely solo workflow.
- **Provided offer:** Meetings up to **100 participants**, **60 minutes** each, unlimited chat messages, screen sharing, and **5 GB storage/user**.
- **How to access:** Claim via Space Apps → **Explore Teams Free** or sign up with Microsoft account.
- **Link:** [Microsoft Teams Free](https://www.microsoft.com/en-us/microsoft-teams/teams-free)
- **Support (from offer):** samfal@microsoft.com

### 6. Google Cloud

- **What it is:** Google's cloud platform for hosting, databases, storage, application services, APIs, and machine learning. Firebase is included among the platform's services.
- **What it can do here:** An alternative to Azure if the chosen implementation needs online storage, application hosting, backend services, or processing.
- **Provided offer:** **US$300 trial credit for 90 days**. The supplied offer says there is **no auto-charge when the free trial ends**.
- **How to access:** Claim via Space Apps → Google Cloud → **Get started for free**.
- **Conditions:** Card verification; moving to paid usage requires an explicit upgrade. Review the particular services' free allowances. **Google Maps primarily maps Earth and is not a default Martian map source.**
- **Links:** [Google Cloud free](https://cloud.google.com/free) · [Google Cloud documentation](https://cloud.google.com/docs) · [Firebase](https://firebase.google.com/)
- **Support (from offer):** cloudstartupsupport@google.com

### 7. Meteomatics Weather API

- **What it is:** API for historical, observed, and forecast **Earth** weather/climate using Meteomatics models and data.
- **What it can do here:** Useful only if a project explicitly needs Earth conditions, a comparison, or an Earth analog; **not an API for real Mars weather**.
- **Provided offer:** **1,000 API queries per day** across features, active **during the hackathon**. More than **1,800 parameters**, including temperature, wind, precipitation, solar radiation, and marine conditions.
- **How to access:** Claim via Space Apps → complete the Meteomatics sign-up form → receive API credentials.
- **Formats:** JSON, CSV, XML, PNG; Python connector and normal HTTP requests are supported.
- **Links:** [Meteomatics API](https://www.meteomatics.com/en/weather-api/) · [API documentation](https://www.meteomatics.com/en/api/)
- **Support (from offer):** support@meteomatics.com

### 8. Miro Education Plan

- **What it is:** Collaborative online whiteboard for diagrams, research notes, design, and planning.
- **What it can do here:** Organize challenge reading, create diagrams, and keep notes even as a solo participant.
- **Provided offer:** **Students: free for 2 years; educators: free indefinitely** subject to eligibility/application.
- **How to access:** Claim via Space Apps → apply as student or educator and sign in.
- **Link:** [Miro for Education](https://miro.com/education/)
- **Support (from offer):** [Miro support form](https://help.miro.com/hc/en-us/requests/new)

### 9. Miro Business Plan

- **What it is:** Enhanced Miro collaboration/business workspace.
- **What it can do here:** More advanced collaboration if the project gains teammates; not required for a coding-first solo project.
- **Provided offer:** **14 days free** for Space Apps participants.
- **How to access:** Claim via Space Apps → Miro pricing page → Business **Try for Free**.
- **Conditions:** Payment information required; cancel or downgrade **before the trial ends** to avoid charges.
- **Link:** [Miro pricing](https://miro.com/pricing/)
- **Support (from offer):** [Miro support form](https://help.miro.com/hc/en-us/requests/new)

### 10. Miro Board Templates

- **What it is:** Prebuilt whiteboard layouts, including Space Apps/hackathon planning boards.
- **What it can do here:** Organize research, task breakdown, decisions, and a final presentation without building a planning template from scratch.
- **Provided offer:** Free access to hackathon templates, including a Hackathon Template Board and a Hackathon Project Coach Board named in the supplied offer text.
- **How to access:** Claim via Space Apps → select **Use Template** → sign in to Miro.
- **Links:** [NASA Space Apps Miro template](https://miro.com/templates/nasa-space-apps/) · [Miro hackathon template](https://miro.com/templates/miro-hackathon/)
- **Support (from offer):** [Miro Community](https://community.miro.com/)

### 11. GoDaddy Registry — Free Domain and Website Hosting (fulfilled through Porkbun)

- **What it is:** A one-year domain name and website-hosting benefit for Space Apps participants, with a free SSL certificate for that period.
- **What it can do here:** Offer an easy-to-share public address and possible project hosting **if needed**; a separate free demo host is also a valid choice.
- **Provided offer:** Free domain/hosting for **one year**; **non-premium domains only**. Confirm the exact included hosting product and renewal prices during redemption.
- **How to access:** Claim via Space Apps or the linked [SpaceApps domain offer portal](https://www.spaceapps.earth/) → search an eligible domain → enter contact information → verify your email/code if prompted → complete checkout with **Porkbun**.
- **Conditions:** Don't assume every domain extension is included; review what renews after the first year and whether payment information is requested.
- **Links:** [SpaceApps domain offer](https://www.spaceapps.earth/) · [Porkbun](https://porkbun.com/)
- **Support (from offer):** support@porkbun.com

## Important distinctions for this challenge

1. **Global Offers ≠ official Mars datasets.** Cloud hosting, collaboration, and coding assistants are useful development resources, but they do **not** satisfy NASA's minimum data-use requirement by themselves.
2. **Earth ≠ Mars.** Microsoft Planetary Computer, Meteomatics, Google Maps, and NASA Worldview are predominantly Earth-oriented. Their existence in an offer list or challenge page does not turn them into Mars data APIs.
3. **Avoid surprise charges.** Azure and Google Cloud trials involve verification; Miro Business requires payment details; the domain may renew after one year. The limits above summarize the text supplied by the team, not a guarantee that provider terms cannot change.
4. **Use only what the idea needs.** For a solo developer, starting locally and adding infrastructure later can be simpler than claiming every offer.
5. **Attribution:** Keep an accurate record of any AI helpers, external data, open-source packages, images, and hosting used in the final submission. NASA organizers require a qualifying challenge-listed NASA source for Global Awards and citation of resources actually used: [NASA Space Apps organizer clarification](https://github.com/nasa/spaceapps/discussions/1827).

## Tool decision log — fill with actual usage before submission

| Tool | Using? (yes/no/undecided) | Why | Account/offer claimed? | Cost/expiry reviewed? |
| --- | --- | --- | --- | --- |
| Microsoft Azure | Undecided | | | |
| Microsoft Planetary Computer | Undecided | | | |
| Microsoft Copilot | Undecided | | | |
| GitHub Copilot | Undecided | | | |
| Microsoft Teams | Undecided | | | |
| Google Cloud | Undecided | | | |
| Meteomatics Weather API | Undecided | | | |
| Miro Education | Undecided | | | |
| Miro Business | Undecided | | | |
| Miro Board Templates | Undecided | | | |
| Free domain and hosting | Undecided | | | |

## Tonight’s tool policy

- Preferred workflow: **one primary coding agent** (Codex, if already available) plus editor assistance from **GitHub Copilot Free** only if desired. These are development tools; generated code still needs testing and human review.
- **Do not claim a paid cloud credit or domain tonight** for a static app. Use GitHub Pages or another already-configured free static host.
- **Never use Meteomatics, Microsoft Planetary Computer or Google Maps as a source of Mars atmospheric, terrain or rover data.**
- The official 2026 Judging Guide requires the **References** field to list **all external resources** used, including code/text/images even if free/open source. List third-party libraries and project assets; transparently note AI assistance actually used.
- Production cutoff is **00:00 Sunday 15 November**. Official demo/submission follows on Sunday; [JUDGING_CHECKLIST.md](JUDGING_CHECKLIST.md) records the rules.

## Source notes

- **Primary source for offer descriptions, numerical limits, and support contacts:** the 2026 **Global Collaborators / Global Offers** text copied by Team Martian and the subsequently uploaded official **11-page Global Offers PDF**. Specific redemption URLs were **not present in the pasted text**, so this guide links to verified public product/documentation pages and the Space Apps offer portal instead.
- **Official claims and current conditions:** [NASA Space Apps 2026 Global Offers](https://www.spaceappschallenge.org/2026/global-offers/) (requires sign-in for some details).
- **Offer access instructions:** [NASA Space Apps organizer answer on claiming offers](https://github.com/nasa/spaceapps/discussions/2035).
- **Challenge resources:** [Interplanetary Survival Guide: Martian Map](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/).

*Prepared for Team Martian. Tool descriptions are a research reference, not an implementation plan.*
