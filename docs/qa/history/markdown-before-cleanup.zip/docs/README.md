# Documentation navigation

[Current overview](../README.md) · [Authoritative status](../STATUS.md) · [Baseline closure evidence](BASELINE_CLOSURE_REPORT.md)

Every supporting Markdown document is classified below. CURRENT REQUIREMENTS are owner instructions/plans, not implementation claims. HISTORICAL records retain original observations and times under explicit banners; current finding tags point to fresh evidence. Only root STATUS.md records task acceptance. Source, route and safety claims are limited to the evidence described.

| Document | Classification | Purpose / reconciliation |
| --- | --- | --- |
| [AGENTS.md](AGENTS.md) | CURRENT REQUIREMENTS | Operating instructions with latest owner build exception. |
| [AGENT_RULES_ADDENDUM.md](AGENT_RULES_ADDENDUM.md) | CURRENT REQUIREMENTS | Owner approvals, release gates, static hosting and separate feature gates. |
| [AGENT_TASKS.md](AGENT_TASKS.md) | CURRENT REQUIREMENTS | Original acceptance prompts; historical paths mapped by migration report. |
| [ARCHITECTURE.md](ARCHITECTURE.md) | CURRENT | Verified React/store/Leaflet responsibilities and gated target section. |
| [ARCHITECTURE_PRE_REACT.md](ARCHITECTURE_PRE_REACT.md) | HISTORICAL | Preserved pre-React component/state architecture. |
| [ARES_HUD_ONE_DAY_AUDIT.md](ARES_HUD_ONE_DAY_AUDIT.md) | HISTORICAL | Original feasibility and judging assumptions; findings now annotated. |
| [AUDIT_CURRENT.md](AUDIT_CURRENT.md) | HISTORICAL | Earlier independent audit; its outstanding reconciliation is superseded by this record. |
| [BASELINE_CLOSURE_REPORT.md](BASELINE_CLOSURE_REPORT.md) | CURRENT EVIDENCE | Task 0/0D/1 closure checks, provenance, full document inventory and limitations. |
| [BUILD_TONIGHT.md](BUILD_TONIGHT.md) | HISTORICAL | Original Saturday plan; Sunday schedule in owner addendum supersedes it. |
| [CHANGELOG.md](CHANGELOG.md) | CURRENT / HISTORICAL | Actual local Git history followed by preserved historical narrative. |
| [CODEX_OPTION_2_HANDOFF.md](CODEX_OPTION_2_HANDOFF.md) | CURRENT REQUIREMENTS | Owner task sequencing and Option 2 handoff; no task completion evidence. |
| [DATA_SOURCES.md](DATA_SOURCES.md) | CURRENT SOURCE REGISTER | Verified assets/credits/hashes; acquisition phases explicitly historical. |
| [DOCS_CHANGE_REPORT_V03.md](DOCS_CHANGE_REPORT_V03.md) | HISTORICAL | Documentation-only v0.3 vision changes; no current implementation claim. |
| [FEATURE_IMPLEMENTATION_REPORT.md](FEATURE_IMPLEMENTATION_REPORT.md) | HISTORICAL EVIDENCE | Pre-React tablet/timeline/recon verification, superseded by migration evidence. |
| [FEATURE_PLAN.md](FEATURE_PLAN.md) | CURRENT REQUIREMENTS | Feature vision, simulation labels and separately gated features. |
| [FIX_REPORT.md](FIX_REPORT.md) | HISTORICAL | Original af9ac9e stabilization findings with updated finding tags. |
| [GATED_FEATURE_SPIKES.md](GATED_FEATURE_SPIKES.md) | CURRENT INVESTIGATION | Recorded globe/elevation spike limits; full-feature gates remain applicable. |
| [INTEGRATION_REPORT.md](INTEGRATION_REPORT.md) | HISTORICAL | Original Phase 2 source/mission integration, not current cache inventory. |
| [JUDGING_CHECKLIST.md](JUDGING_CHECKLIST.md) | CURRENT REQUIREMENTS / UNVERIFIED EXTERNAL | Owner submission checklist; portal/official-event details are not certified here. |
| [MAP_ARCHITECTURE.md](MAP_ARCHITECTURE.md) | HISTORICAL | Original three-space design; link now points to actual current architecture. |
| [MAP_RECOVERY_REPORT.md](MAP_RECOVERY_REPORT.md) | HISTORICAL | Local server/cache recovery evidence, not current server instructions. |
| [QA_REPORT.md](QA_REPORT.md) | HISTORICAL | Original QA H1/H2/M1/M2/L1/L2 findings with current individual annotations. |
| [REACT_MIGRATION_REPORT.md](REACT_MIGRATION_REPORT.md) | CURRENT EVIDENCE | Directory/file map, integration and browser/build evidence; readout supplement in this report. |
| [README.md](README.md) | CURRENT | Exhaustive classified navigation for every supporting Markdown file. |
| [RESOURCE_GAP_AUDIT.md](RESOURCE_GAP_AUDIT.md) | HISTORICAL | Original resource capability table, reconciled against current features and remaining terrain gaps. |
| [TASK_0D_REPORT.md](TASK_0D_REPORT.md) | HISTORICAL | Prior baseline/report claims; local commit objects checked in current evidence. |
| [TASK_0_REPORT.md](TASK_0_REPORT.md) | HISTORICAL | Earlier preflight; page-2-sketch claim corrected in this record. |
| [TASK_1_REPORT.md](TASK_1_REPORT.md) | HISTORICAL | Original Leaflet measurements; rerun and tightened in current checks. |
| [TEST_REPORT.md](TEST_REPORT.md) | HISTORICAL | Original eight-test report; current counts and evidence are in STATUS/report. |
| [THIRD_PARTY.md](THIRD_PARTY.md) | CURRENT | Pinned package purposes, full license locations and AI disclosure. |
| [assets/README.md](assets/README.md) | CURRENT | Correct public/ path mapping and 24-tile asset register entry. |
| [status-from-otheragent/Opencode-DeepSeek-V4.1-flash-free-work.md](status-from-otheragent/Opencode-DeepSeek-V4.1-flash-free-work.md) | HISTORICAL | Other-agent notes; implementation/commit claims not authoritative. |
| [status-from-otheragent/README.md](status-from-otheragent/README.md) | HISTORICAL | Old overview/commands; dead architecture anchor repaired. |
| [status-from-otheragent/STATUS.md](status-from-otheragent/STATUS.md) | HISTORICAL | Archived status snapshot; root STATUS alone is authoritative. |
| [toolgiven.md](toolgiven.md) | HISTORICAL SOURCE REFERENCE | Owner-provided Global Offers list; external offer availability not re-certified. |

[QA evidence directory](qa/) contains retained original screenshots, migration evidence and baseline-closure JSON/PDF-render/contact-sheet figures. Historical root file paths map through the [migration map](REACT_MIGRATION_REPORT.md#moved-reused-and-modified-files); original application files remain in `legacy/`. No historical record was deleted.
