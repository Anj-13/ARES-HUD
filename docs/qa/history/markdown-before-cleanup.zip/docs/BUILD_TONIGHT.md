> HISTORICAL EVIDENCE: prior report, not current acceptance. [UNVERIFIED] Old test/commit claims unless independently repeated in [AUDIT_CURRENT.md](AUDIT_CURRENT.md). [STATUS.md](../STATUS.md) controls current migration status.

> STATUS: HISTORICAL - describes baseline pre-build planning (no source revision recorded) on 14 November 2026. Superseded by [STATUS.md](../STATUS.md). Finding tags were checked on 14 November 2026. Original timings and claimed checks are retained, not rerun.

## Task 0D reconciliation annotations — rechecked 14 November 2026

- **[RESOLVED] H1 / missing NASA imagery:** 24 genuine local CTX tiles at levels 10–12, source manifest hashes and two NASA reference JPEGs verified. Fresh level-11/12 requests return 200 PNG. Challenge/team eligibility is a separate owner submission check.
- **[OPEN] H2 / public acceptance:** local Edge desktop/narrow/keyboard and static-build tests pass; public URL, deployed revision, private-window and physical-device acceptance remain unverified.
- **[RESOLVED] M1 / no-route UI:** original and React browser harnesses exercise a blocked grid/plan, show unavailable results, omit an active route and recover after reset.
- **[RESOLVED] M2 / identical-endpoint narrative:** browser-checked dust state says no detour is needed at an identical endpoint; other no-route/unchanged/detour states have conditional copy.
- **[RESOLVED] L2 / marker sizing:** every Hab/science native button measures 44 × 44 CSS px at desktop and 360 px; map projection checks pass after pan at three zooms.
- **[RESOLVED] L1 / stale handoff wording:** current README/STATUS identify the React working tree over real local Git history. No freeze tag, new commit or public deployment is invented.
- **[RESOLVED] Registered imagery / documentation baseline:** source matrix, 4 km sector, coordinates, distances, CTX/PDF comparison and local Markdown links rechecked. Eight/14/22/33-test and 16-tile claims below are historical only; current suite is 39 passing tests and cache is 24 tiles.
- **[OPEN] Numeric terrain / geology geometry:** no verified numeric DEM, slope, unit-to-grid overlay or operational safety model. The separately displayed USGS educational map is not a routing raster.
- **[UNVERIFIED] Original run metadata / official submission:** old timing, unavailable commit IDs, event portal, registration, official-guide and submission claims remain archival; fresh evidence does not retrospectively certify them.

Full finding-by-finding evidence, historical commit validation and comparison limits: [baseline closure report](BASELINE_CLOSURE_REPORT.md). [STATUS.md](../STATUS.md) alone records acceptance. The original record follows; its original present-tense statements and numeric results describe its historical revision.

# BUILD_TONIGHT.md — ARES-HUD code-freeze operations

**Team:** Martian  
**Date:** Saturday 14 November 2026  
**Internal freeze:** **00:00 Sunday 15 November 2026 (midnight tonight)**.  
**Not the official deadline:** the NASA project must be submitted by **23:59 Sunday 15 November** in the team's **event-local time**, per the 13 November 2026 Judging & Awards Guide.  
**Video:** Sunday **after** the application is frozen; official video is **at most 30 seconds**.

## What must be finished by midnight

1. A running, publicly accessible, no-login **ARES-HUD** static web app.
2. One legitimate **NASA Mars resource actually displayed or used**, plus exact working link/source metadata in the app and README. **Do not claim measured slope from image pixels.** Prefer meaningful interaction with authentic geographic/mission data, not just an attractive backdrop; if you cannot obtain numerical data, call that limitation out.
3. A map/Hab marker/at least one selectable science destination. Hab and invented waypoints labelled hypothetical.
4. Deterministic **40×40 A*** routing over explicitly simulated traversal costs, with a legible route and clear blocked/no-path behavior.
5. **Simulate dust hazard** button changes grid cells and leads to a visible reroute; **Return to Hab** works.
6. Responsive, readable dark tactical interface with labels: `NASA SOURCE`, `SIMULATED HAZARD`, `SIMULATED COST`, `MODEL OUTPUT`; persistent prototype/flight-safety disclaimer.
7. Automated pathfinding tests (open/blocked/detour/unreachable/no diagonal corner cutting) and a reproducible local run command.
8. README updated to say **implemented vs. proposed**, asset source and license/credit, public app URL, actual AI/tool use, and known limitations.

## Time boxes — 12-hour capacity plan, compress if starting later

| Clock checkpoint (Europe/London) | Deliverable | Cut if late |
| --- | --- | --- |
| **13:00** | Repo works locally; NASA asset chosen or source limitation recorded | Stop DEM hunting after ~60–75 min |
| **15:00** | Working HUD layout + map + Hab + destination controls | Eliminate dual HUD modes |
| **17:30** | A* routes; unit tests pass | No routing animations |
| **19:00** | Hazard reroutes and Return to Hab works | Drop moving storm simulation |
| **20:15** | NASA source links and provenance correct; judge-friendly explanatory text | Drop optional geology overlays |
| **21:30** | Usable responsive interface; no new features from here onward | Drop visual polish and telemetry |
| **22:30** | Static deployment and check in private window; dependencies frozen | No domain purchase/setup |
| **23:15** | Final regression pass, README and reference register reconciled | No extra images/feature requests |
| **23:45** | Commit/tag a known working build, save public URL | Fix only critical failures |
| **00:00** | **Code freeze** | Move to Sunday demo/submission workflow |

The checkpoint table assumes a start around midday Saturday. If starting later, **skip stretch goals**, not testing and source attribution. Do not assume Codex can produce verified Mars science or automatically integrate correct external datasets.

## Definition of done: live demo flow

**Open app → see a NASA-credited Mars context → select science waypoint → inspect proposed route → click “Simulate dust hazard” → see route reroute → click “Return to Hab” → inspect source/simulation badges.**

A project that looks attractive but has no reproducible route interaction is **not done**. An app that falsely claims NASA-measured hazard costs is **not done**.

## Feature stop-list

**Do not implement before code freeze:** 3D globe, NASA-looking synthetic imagery, LiDAR, Fog of War, moving weather physics, radiation monitor, realistic suit O2 or battery, comms range, oxygen tether rings, true foot-scale obstacle detection, multiple routes based on unverified DEM, authentication, server/backend, special domain purchase, paid cloud.

**Optional only if all DONE gates pass before 21:30:** one verified Perseverance POV image with exact gallery source/metadata, compact CSS wrist/helmet skin, a UI explanation of a genuinely sourced map layer.

## Emergency fallback gates

- **NASA visual missing at 13:00:** use an explicitly labeled map placeholder and proceed with route functionality; ask human owner to supply/verify a real file. Do not claim NASA asset integration is complete.
- **No georeferenced slope by early afternoon:** keep costs simulated. Do not spend the evening parsing GIS formats.
- **A* tests not green at 17:30:** move all effort to algorithm/test debugging; use Dijkstra if simpler and clearly identify the actual algorithm used.
- **Hazard rerouting unreliable at 19:00:** make it deterministic: fixed start, fixed waypoint, fixed blocked region along first route, guaranteed detour if possible.
- **Deployment failing at 22:30:** deploy simplest static HTML/CSS/JS from existing GitHub Pages rather than adding frameworks or cloud services.
- **Remaining time <1 hour:** freeze features, fix critical errors, reconcile README to reality, verify public link.

## Codex prompt — paste verbatim to start

> Read `BUILD_TONIGHT.md`, `AGENTS.md`, `JUDGING_CHECKLIST.md`, `README.md`, and `toolgiven.md`. It is Saturday 14 November 2026 and **the app must be runnable, tested and deployed by 00:00 Sunday 15 November**. Produce executable static frontend code now, not more planning documents. Implement a deterministic 40×40 A* EVA route demonstration with a hypothetical Hab, selectable science waypoint, one-click simulated dust hazard and Return to Hab. Add a visible NASA resource panel and distinguish authentic NASA images from synthetic costs; do not invent NASA coordinates, measured slopes or rover photo locations. Write tests, execute them, show evidence, then guide deployment to a public static URL. Do not add a backend or any stretch features. Do not produce the demo video tonight. At every milestone report what runs, what is simulated, which sources are actually integrated, and blockers. Stop adding features by 21:30; freeze by midnight.

## Sunday: demo and submission, separate task

- Prepare **one official 30-second maximum video** (or at most 7 slides). Video may be spoken in a non-English language **only with English subtitles**; all project form text and linked materials should be in English.
- Record the actual finished app. Do not film features that were planned but not implemented.
- Complete required Project tab fields and **References field** listing every external code, text, image, NASA resource and used third-party tool/library.
- Confirm the team has **one registered member in the same Local Event** (this is sufficient for local-team eligibility); the Universal Event requires two members.
- Agree to the originality/terms/permissions statements; avoid copyright-protected *The Martian* footage or music without permission.
- Submit well ahead of **23:59 Sunday 15 November local event time** and verify the project is marked submitted.

Primary source: NASA Space Apps **Judging & Awards Guide**, dated **13 November 2026**, team-provided PDF, pages 3 and 5–8; [online version](https://www.spaceappschallenge.org/resources/judging-awards-guide/).
