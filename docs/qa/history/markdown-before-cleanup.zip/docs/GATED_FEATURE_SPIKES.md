# Gated feature investigations - 14 November 2026

These are verification artifacts, not integrated product features. No globe dependency or asset was added to the production app. Full Task 7 acceptance has NOT passed. No commit or deployment.

## Task 7: globe investigation

NASA's [WMTS documentation](https://trek.nasa.gov/tiles/apidoc/trekAPI.html?body=mars) links its configuration and getLayerServices endpoint. Local catalog product UUID a4f540e4-79a5-4a20-8265-1216a5da37f7 was resolved using [NASA's layer service](https://trek.nasa.gov/mars/TrekServices/ws/index/getLayerServices?uuid=a4f540e4-79a5-4a20-8265-1216a5da37f7), HTTP 200. This is a separate global product, not the regional Jezero CTX mosaic.

Verified [GetCapabilities](https://trek.nasa.gov/tiles/Mars/EQ/msss_atlas_simp_clon/1.0.0/WMTSCapabilities.xml):

- Layer `msss_atlas_simp_clon`, MGS MOC Atlas, Global Color Mosaic; Mars Global Surveyor / Mars Orbiter Camera. Catalog describes primarily May-June 1999 wide-angle red observations. Candidate attribution NASA/JPL/MSSS; exact redistribution wording and the mosaic's color processing still need final source review.
- EPSG:104905 identifier in the XML; equirectangular/geographic matrix with upper-left -180,90, east-increasing columns and south-increasing rows. Geographic bounds -179.9999885,-89.9999958 to 179.9999862,89.9999916. The WGS84BoundingBox is the service's OGC wrapper, not proof of an Earth datum for Mars. Planetocentric/planetographic latitude convention needs explicit authoritative confirmation before mission markers.
- Style `default`, matrix set `default028mm`, levels 0-6. Level L has 2^(L+1) columns and 2^L rows, 256px tiles. Format image/png. The advertised ResourceURL contains a double slash before style; used exactly as advertised, HTTP 200 for both level-0 tiles.
- Level 0 assembles a 512x256 global texture, 0.703125 degrees per pixel. This is coarse context only; no surface scale or elevation can be inferred from it. Source coverage near the poles/seam and physical landmark alignment are not certified by a successful decode.

### Disposable rendering test

`.browser-qa/globe-spike/` contains a static, offline Three.js r160 test and two locally downloaded NASA PNGs. This directory is ignored and must not be deployed. [SphereGeometry](https://threejs.org/docs/pages/SphereGeometry.html) accepts an explicit radius; the spike uses 3,396,190 m and uniform scale for numeric camera convenience. The [r160 module](https://raw.githubusercontent.com/mrdoob/three.js/r160/build/three.module.js) is 1,272,972 bytes and works directly as an ES module without a build. [MIT licence](https://raw.githubusercontent.com/mrdoob/three.js/r160/LICENSE), 1,081 bytes. r160 is a tested candidate pin, not approval or a claim that it is the latest release.

Candidate comparison: Three.js provides the required sphere and offline ES module with modest dependency scope; raw WebGL would require maintaining mesh/shader/context/input plumbing and lacks this tested renderer abstraction. Other large globe engines were not vetted in this time box. No renderer has been approved for production.

Actual browser: Windows, Intel Core i3-7130U @2.70GHz, Intel HD Graphics 620 via ANGLE/D3D11; Edge 157.0.0.0, WebGL2, MAX_TEXTURE_SIZE 16384. Headless viewport 1256x908 (requested outer window 1280x1000). The performance.now instrumentation reported 222.8ms to first textured render under headless virtual-time testing. This is not a wall-clock performance benchmark or acceptance result. Local canvas pixel read succeeded. Two source PNGs total 88,039 bytes; renderer + licence + textures total 1,362,092 bytes, excluding HTML/XML/QA metadata. Decoded RGBA texture plus mipmaps is approximately 699,051 bytes, excluding framebuffer/geometry/driver overhead. Peak memory and interactive frame rate NOT MEASURED.

Button rotation and zoom passed. Separate headless cases exercised absent WebGL, missing local texture and forced context loss: each displayed an explicit failure and a keyboard-accessible Surface Mode link. Narrow runs requested 360px outer windows, but a strict 360px globe content viewport, drag/touch, focus transfer, repeated enter/leave cleanup, keyboard behavior and reduced-motion behavior are NOT certified. The spike has no automatic animation loop.

Mapping proposed: source u=(longitude+180)/360 and v=(latitude+90)/180; Three sphere x=cos(lat)*cos(lon), y=sin(lat), z=-cos(lat)*sin(lon), with north at positive Y. This matches the mesh's mathematical UV orientation; reference-point/seam visual registration is NOT VERIFIED. Development download and local pixel read do not establish NASA browser CORS. No external browser CORS is required by the proposed local-runtime architecture.

### Mission marker evidence, not deployed markers

[NASA Perseverance EDL assessment](https://ntrs.nasa.gov/citations/20210024644) reports landing on 18 February 2021 at 18.44463 N, 77.45088 E. [NASA Curiosity EDL assessment](https://ntrs.nasa.gov/api/citations/20130010129/downloads/20130010129.pdf?attachment=true) reports 4.5895 S, 137.4417 E. These are historical landing sites, not current positions. The precise latitude/datum conventions and their compatibility with the global texture were not established, so no markers or tracks were integrated. Curiosity remains Gale context only.

### Gate and next action

Full implementation is blocked by incomplete coordinate/landmark and lifecycle/performance verification, plus separate owner approval. Retain 2D. Recommended next technical step: verify latitude convention and landmarks, complete desktop/360px/keyboard/context restoration and repeated lifecycle measurements, then present a specific renderer/texture-size budget for approval. Estimated remaining spike 30-45 minutes; integrated globe, state-preserving transitions and acceptance approximately 2-3 hours after a successful spike and approval, subject to the 13:30 GMT 15 November feature cutoff. These are estimates, not promises.

The current addendum section 1 explicitly says "separate owner go/no-go required for full implementation"; Task 7 says "STOP for separate owner go/no-go". No full globe implementation proceeded.

## Task 5: numeric elevation investigation

The [USGS Mars 2020 Jezero landing-site products page](https://astrogeology.usgs.gov/search/map/mars-2020-jezero-crater-landing-site-products) is a candidate official source for CTX/HiRISE digital terrain models. Search metadata identifies a 20 m/pixel CTX DEM and TRN products. Opening the product page returned HTTP 403; stopped this acquisition step. No GeoTIFF, numeric elevations, nodata values, vertical units or registration were verified. The cached Trek catalog query explicitly excludes DEM, ConfidenceRaw and Slope categories; it cannot prove that Trek has no numeric elevation.

No terrain-cost code or fake elevation was added. Do not substitute MOLA color hillshade or image brightness.

Manual acquisition if the page opens for the owner: open the USGS page above, select its **Mars 2020 Science Investigation CTX DEM Mosaic** related product, download the numerical DEM (not orthophoto/hillshade) plus its metadata/readme. Place the unmodified files in `assets/elevation/source/` and preserve the exact download URL. Before integration, inspect CRS, horizontal/vertical units and datum, nodata and pixel registration; compare coverage to sector.js; compute metric-unit slopes with a documented resampling/nodata method and test it. The Task 5 spike and separate owner approval still apply. Do not claim the search snippet itself validates the raster.

## Acquired files: spike only

Retrieval date: 14 November 2026. Every entry below returned HTTP 200; filenames are local QA paths, not production assets.

| Local file | Bytes | SHA-256 | Exact source |
| --- | --- | --- | --- |
| .browser-qa\globe-spike\tile-0.png | 44128 | 014f5a30f4c40f8add4b23d71f2fa6833263138aa49c16f63d1e25f594e07915 | [source](https://trek.nasa.gov/tiles/Mars/EQ/msss_atlas_simp_clon/1.0.0//default/default028mm/0/0/0.png) |
| .browser-qa\globe-spike\tile-1.png | 43911 | 30720afa92b7210f16f28789985b085c6d785dcd4e079fef8ee7511000ef72f2 | [source](https://trek.nasa.gov/tiles/Mars/EQ/msss_atlas_simp_clon/1.0.0//default/default028mm/0/0/1.png) |
| .browser-qa\globe-spike\three.module.js | 1272972 | 76dea8151bc9352aef3528b4262e249b2604f62543828328db978d060d61a495 | [source](https://raw.githubusercontent.com/mrdoob/three.js/r160/build/three.module.js) |
| .browser-qa\globe-spike\LICENSE | 1081 | 852e0e8699169bf9f6fdc6bda3e682d078dcbc738b5d33e74df594721bff271d | [source](https://raw.githubusercontent.com/mrdoob/three.js/r160/LICENSE) |
