> React migration update, 14 November 2026: the owner explicitly requested React + Vite integration using `react-ui-handoff/`. That request supersedes older build deferral statements here. Static hosting, existing algorithms, provenance, separate globe/elevation gates and release schedule remain applicable. Current architecture is in ARCHITECTURE.md; acceptance is recorded only in ../STATUS.md.

# AGENT_TASKS.md — Paste-ready prompts for the coding agent

**How to use:** give the agent one task at a time, in this order: **0 → 0D → 1 → 3 → 2 → 6**, and **5** only after its spike passes. Always start a task with the **Common header** below. **Schedule Option 2 is now approved:** Tier B Tasks 2 and 6 are authorized after Tier A is verified, subject to the Sunday 15 November 13:30 GMT feature cutoff. Task 5 remains separately gated. NEW Task 7 depends on verified Task 1: spike first, then separate owner go/no-go for full implementation; never displace Tier A/B. See `AGENT_RULES_ADDENDUM.md` section 2 for the 16:00 GMT freeze and release gates.

Companions: [AGENT_RULES_ADDENDUM.md](./AGENT_RULES_ADDENDUM.md) · [FEATURE_PLAN.md](./FEATURE_PLAN.md)

---

## Common header (prefix to every task)

```
Read, in this order: AGENTS.md, AGENT_RULES_ADDENDUM.md, FEATURE_PLAN.md,
DATA_SOURCES.md, MAP_ARCHITECTURE.md, INTEGRATION_REPORT.md, and STATUS.md
(once Task 0D has created it).

Obey AGENT_RULES_ADDENDUM.md sections 1-4 exactly, including the OWNER-APPROVED
Option 2 schedule: Sunday 15 Nov 2026 13:30 GMT feature cutoff and 16:00
GMT code freeze. Tier B is allowed only after verified Tier A; Task 5
implementation still requires separate owner approval. Where it conflicts with
AGENTS.md, the addendum wins for the approved items only. Static HTML/CSS/JS,
ES modules, no build, no backend. The only pre-approved dependency is Leaflet
1.9.x vendored in vendor/leaflet/ (addendum rule 5); any other dependency needs
the justification the addendum requires. Keep pathfinding.js pure and all
existing tests green. Leaflet owns only Surface Mode/2D viewports (addendum rule 13); a separately approved Task 7 renderer would own Planetary Mode only. At the
end of every task update STATUS.md (addendum rule 14).
Never invent coordinates, elevation, rover metadata or provenance. Keep the
OBSERVED / DERIVED / INTERPRETED / SIMULATED labels visible. Original art only;
nothing from the film The Martian.

Run npm test and node --check on every changed file. Open the app in a real
browser (headless is fine) and extend browser-test.html where relevant. End
with the TASK REPORT in the addendum's format. Commit with "task-N: ..." when
green. If you hit the stop point, revert to the last green commit and report.
```

---

## Task 0 — Preflight (verification, hygiene, no new features)

Stop point: 45 minutes.

```
TASK 0: PREFLIGHT. Verify facts and fix hygiene. Do not add features.

A. VERIFY THE TILE LAYER (report numbers, do not assume)
1. Read assets/trek-capabilities.xml. List every TileMatrix level and its
   MatrixWidth/MatrixHeight for layer Jezero_CTX_BlockAdj_dd. Confirm the
   deepest level (expected: 12).
2. For levels 10, 11 and 12, compute tile size in degrees (180 / 2^L),
   degrees per pixel (/256) and metres per pixel using the Mars 2000 sphere
   radius 3,396,190 m (1 degree latitude = 2*pi*R/360). East-west metres per
   pixel = north-south value * cos(latitude). Put the table in the report.
3. Using the tile template in assets/trek/manifest.json, request one tile at
   level 11 and one at level 12 near 18.45 N, 77.45 E. Report HTTP status and
   whether a PNG was returned. If the network is unavailable, say so and stop
   this step; do not guess.
4. Compute the lat/lon bounds of the CURRENTLY CACHED block (level 10, rows
   403-406, cols 1463-1466): lat = 90 - row*(180/1024), lon = -180 +
   col*(180/1024). Compare with the USGS SIM 3464 coverage in datasets.js
   (17.7-18.7 N, 76.8-77.8 E). Report the overlap in degrees and as a share of
   the USGS extent.
5. Download level 11 or 12 tiles covering lat 18.2-18.7 N, lon 77.2-77.7 E
   (a contact sheet is enough, do not commit unless needed). Compare visually
   with assets/jezero-themis.jpg (PIA23386) and assets/jezero-geology.pdf page
   2. State whether the delta is visible and where. Label this "visually
   confirmed by the agent", not measured. Never register by pixel colour.

B. HYGIENE
1. Fix mojibake: replace every "?" that stands in for an em dash or other
   special character in index.html, app.js, datasets.js, DATA_SOURCES.md,
   RESOURCE_GAP_AUDIT.md and tests. Save as UTF-8.
2. Add .browser-qa/ to .gitignore. Do not delete the folder.
3. Fix QA findings M2 (dust narrative at identical endpoints) and L2 (science
   pin size) and add a test or browser check for each. Add a UI-level no-route
   check using an injected unreachable grid in browser-test.html (QA M1).
4. Documentation reconciliation is Task 0D. Here, only fix the mojibake
   characters in the markdown files; do not restructure README or ARCHITECTURE.

DELIVERABLE: the Task 0 report, the numbers from A1-A5, and the commit.
ACCEPTANCE: all existing tests pass; new checks pass; no "?" artefacts; the
report states clearly whether the cached block contains the delta and what
the deepest served level is.
```

---

## Task 0D — Documentation baseline: current implementation vs migration target

Depends on Task 0. Documentation only; no application code, tests or assets change. Stop point: 45 minutes.

Why: README.md, ARCHITECTURE.md and several reports were written for earlier states of the repository and now contradict the code (for example ARCHITECTURE.md says no NASA asset loader exists and lists six files; README.md says eight tests; TEST_REPORT.md and QA_REPORT.md still report "NASA resource absent"). Readers cannot tell what runs today from what is planned.

```
TASK 0D: DOCUMENTATION BASELINE. (Historical task constraint: the later explicit
v0.3 owner request authorizes scoped addendum edits in a separate docs pass.)
Separate "what exists and runs today" from
"the migration target". Documentation only: do not change application code,
tests, assets or AGENT_RULES_ADDENDUM.md. If you find a code bug, list it in
the report; do not fix it here.

STEP 1 - ESTABLISH FACTS (run commands; do not copy from old docs)
- git log -1 --format="%h %s %ci"; git status --short; git ls-files.
- npm test: record total tests and pass/fail per test file.
- For every .js and .html file: one line on its responsibility and, for
  modules, its exports (grep export). Note which HTML files load which modules.
- Assets present: tile level, rows, columns, count, total size; PDFs; images.
- Which documented claims are stale: grep all .md files for "eight tests",
  "8 tests", "no NASA asset", "NASA resource absent", "placeholder", "four
  files", "pathfinding.js together", "H1", "af9ac9e", "not deployed".
Put these facts in a block at the top of your report.

STEP 2 - CREATE STATUS.md (single source of truth at the repo root)
Sections:
1. Baseline: commit hash, date, test count and result, how it was verified.
2. Current implementation. A table: capability | status (VERIFIED / REPORTED /
   NOT VERIFIED) | evidence (command output, file, browser check).
3. Migration target. A table with one row per item: Task 1 registered Leaflet
   map, Task 3 Send to Tablet, Task 2 Sol timeline, Task 6 Fog of War,
   Task 5 terrain cost. Columns: item | status (NOT STARTED / IN PROGRESS /
   DONE) | commit | evidence. Every row starts NOT STARTED unless git history
   proves otherwise.
4. Known gaps and open QA findings, each tagged OPEN or RESOLVED with evidence.
Rule stated at the top of STATUS.md: only this file may call a feature DONE;
other documents link here.

STEP 3 - RESTRUCTURE README.md
- Add a status banner under the title: current implementation phase, what is
  planned, link to STATUS.md.
- Sections in this order: What runs today (verified) | Planned migration (NOT
  implemented) | Run and test | Deployment | Sources, credits and limitations |
  Documentation index.
- Merge the appended "Phase 2 implemented upgrade" and "NASA integration
  verification" text into one coherent "What runs today" section. Remove
  duplicated or contradictory paragraphs. Keep: the prototype disclaimer, NASA
  and USGS credits, AI-assistant disclosure, MIT licence note.
- Correct: test count from the real run; the deployment file list (all JS
  modules and assets/, not only four files); public URL stays "none verified"
  unless you can verify one.
- Documentation index: every .md file with a label CURRENT or HISTORICAL and
  one line on its purpose.

STEP 4 - RESTRUCTURE ARCHITECTURE.md into two parts
Part A, Current architecture (as built, with baseline commit): full component
table including mission.js, datasets.js, exploration.js, mission.test.js,
browser-test.html, assets/; the three independent spaces (Trek explorer, USGS
reference, EVA grid); state and data flow including traverse mode, stops and
simulated arrival; the local NASA tile loader; limits.
Part B, Target architecture (migration, NOT implemented): Leaflet owns the
viewport (ADR-1 in FEATURE_PLAN.md); sector.js, geo.js, map.js, plan.js,
tablet, sols, fog, slope modules and their responsibilities.
Then a Migration map table: current file | target | action (keep / replace /
delete / new) | task. Label Part B clearly in its heading and first line.
MAP_ARCHITECTURE.md: add a banner saying it describes the current three-space
design and pointing to ARCHITECTURE.md Part B for the target.

STEP 5 - MARK HISTORICAL DOCUMENTS (add banners and tags; do not rewrite)
Files: QA_REPORT.md, FIX_REPORT.md, TEST_REPORT.md, CHANGELOG.md,
ARES_HUD_ONE_DAY_AUDIT.md, BUILD_TONIGHT.md, INTEGRATION_REPORT.md,
RESOURCE_GAP_AUDIT.md. Banner at the top of each:
"> STATUS: HISTORICAL - describes baseline <hash> on <date>. Superseded by
STATUS.md. Finding tags below were checked on <date>."
Next to each finding or gap in those files add [RESOLVED], [OPEN] or
[UNVERIFIED] with a short evidence note (for example QA H1 "NASA resource
absent": check against the Phase 2 tiles and tag accordingly; H2 deployment:
tag from README facts). Bring CHANGELOG.md up to date from git log only (list
actual commits; invent nothing). AGENTS.md: add ONE line at the top pointing
to AGENT_RULES_ADDENDUM.md as taking precedence for approved items; change
nothing else in it.

STEP 6 - CONSISTENCY CHECK (run and report results)
- No document other than STATUS.md says a target feature is DONE or
  implemented.
- grep shows no remaining "eight tests" or "NASA resource absent" outside
  historical banners and tags.
- Every relative markdown link resolves to an existing file.
- No "?" in place of dashes; all files UTF-8.
- Every statement you kept about current behaviour is backed by a command you
  ran or a file you read; otherwise label it REPORTED or NOT VERIFIED.

ACCEPTANCE: git diff --stat shows only .md files (and .gitignore if touched in
Task 0); STATUS.md exists; README and ARCHITECTURE have separate Current and
Target sections; every historical doc has a banner and finding tags; the
Task 0D report lists what you could not verify. Use git add -f for markdown.
```

---

## Task 1 — Registered map on Leaflet (foundation)

Depends on Tasks 0 and 0D. Stop point: 3.5 hours, of which the Leaflet spike (step 1) is 45 minutes.

Architecture decision (ADR-1 in `FEATURE_PLAN.md`): **Leaflet owns the Surface Mode viewport.** The target 2D implementation must have no custom CSS-transform pan/zoom or second screen-projection function. Task 7 is a separate, gated Planetary Mode renderer.

```
TASK 1: REGISTERED MAP ON LEAFLET. Replace the two disconnected maps (the
custom CSS tile explorer and the separate SVG grid) with ONE Leaflet map.
Leaflet owns the viewport: pan, zoom, touch, keyboard, tile loading,
lat/lng-to-screen projection and the scale bar. Do NOT keep or write manual
CSS-transform pan/zoom code, and do NOT write another function that converts
lon/lat to screen pixels. Every overlay is positioned by lat/lng through
Leaflet.

DECISIONS (record any change and why)
- Leaflet: latest stable 1.9.x release, exact version pinned, vendored in
  vendor/leaflet/ (leaflet.js, leaflet.css, LICENSE). No CDN, no plugins, no
  2.x or alpha builds. Record version, source URL, retrieval date, bytes and
  SHA-256 in DATA_SOURCES.md and README, and add it to the References draft.
  If the network is unavailable, STOP and ask the owner to supply the files.
- Custom CRS "MarsEQ" in map-crs.js: extend L.CRS.EPSG4326 with R = 3396190
  (Mars 2000 sphere radius, metres). Expectation to PROVE in step 1: Leaflet's
  EPSG4326 transformation makes zoom 0 a 2 x 1 tile world (512 x 256 px), the
  same as the Trek matrix (level L = 2^(L+1) columns x 2^L rows of 256 px
  tiles, origin -180, 90), so Leaflet zoom equals the WMTS level with no
  zoomOffset and Leaflet's y equals the WMTS row. Also confirm that the
  distance() method uses the R property in the vendored version.
- Local tile layer: template assets/trek/{z}/{y}-{x}.png, tileSize 256,
  noWrap true, minZoom 10, maxNativeZoom = deepest verified level (target 12),
  maxZoom = maxNativeZoom + 2 (show a visible notice when overzoomed),
  bounds = sector plus a one-tile margin, tileerror handler, attribution
  "NASA/JPL-Caltech/MSSS, via NASA Mars Trek".
- Sector: a 4 km x 4 km operating area as a lon/lat bounding box. Height in
  degrees = 4000 / 59275. Width in degrees = 4000 / (59275 * cos(lat_center)).
  Place it where Task 0 confirmed the delta is visible, with the Hab west of
  the delta and the science stop on or near it. Placement is SIMULATED /
  HYPOTHETICAL; the imagery under it is OBSERVED.
- Grid: 40 x 40 cells, 100 m nominal, row 0 = north, column 0 = west.
- geo.js stays, but is PURE sector and grid maths with no pixel projection:
  gridToLatLng, latLngToGrid, metersBetween (sphere R = 3396190), bearing, and
  tileIndex(lon, lat, level) used only by the tile download script. It does
  not import Leaflet. Leaflet does everything that involves the screen.

STEPS
1. LEAFLET SPIKE (45 min max; report the results, then continue).
   Vendor Leaflet, build MarsEQ, and add browser checks to browser-test.html
   (Leaflet needs a DOM, so these cannot be Node tests):
   a) zoom 0 world size is 512 x 256 px; point (lat 90, lng -180) projects to
      (0, 0) and (lat -90, lng 180) to (512, 256).
   b) At zoom 10 the NW corner of tile row 403, column 1463 (lat = 90 - 403 *
      180/1024, lng = -180 + 1463 * 180/1024) projects to pixel
      (1463*256, 403*256) within 0.01 px. Repeat for one point at zoom 12.
   c) crs.distance for 1 degree of latitude equals 59,274.7 m within 1 m.
   d) map.distance between two lat/lngs 4000 m apart (computed from geo.js
      maths) is 4000 m within 1 m.
   If any check fails, spend at most 20 more minutes diagnosing. If it still
   fails, STOP and report. Do not fall back to CSS transforms or to another
   library without owner approval.
2. Create sector.js: sectorId "jezero-sector-1", bounding box, Hab and stop
   grid coordinates, and a short comment on how each number was chosen and
   what is simulated.
3. Create geo.js and geo.test.js (Node): grid<->lat/lng round trip, four
   corners and centre, 4000 m north-south and east-west spans within 1 m,
   bearing, tileIndex for known points at levels 10, 11, 12.
4. Create scripts/fetch-tiles.mjs (Node, idempotent) that downloads only the
   tiles covering the sector plus a one-tile margin at the deepest verified
   level (and coarser levels only if needed) into assets/trek/{z}/{row}-{col}.png.
   Extend assets/trek/manifest.json with level, URL, bytes and SHA-256. Report
   total added size.
5. Create map.js exporting createSectorMap(element, options) used by BOTH
   mission control and the tablet (Task 3). It builds the Leaflet map with
   MarsEQ, keyboard handling on, maxBounds = sector plus margin
   (maxBoundsViscosity 1), zoomSnap 0.5, and these panes (z-index): tiles 200,
   grid 410, hazards 420, fog 430, routes 450, markers 600. Use the canvas
   renderer for grid, hazard and fog cell layers.
6. Create sector-layers.js: drawGrid (gridlines as one multi-polyline),
   drawHazards(grid), drawRoute(path, style) with dashed style for the
   pre-hazard route, drawMarkers (Hab, stops, astronaut). Markers are L.marker
   with L.divIcon containing a native button, keyboard true, with aria-label.
   These modules never import pathfinding.js; app.js passes data in.
7. Readouts: on mousemove show lat/lng (DERIVED) and the grid cell; add
   L.control.scale({imperial:false}); show the sector bounding box and cell
   size in metres.
8. Layer manager: toggles and opacity call Leaflet layer add/remove or
   setOpacity. Hiding hazard shading must never unblock cells (existing
   behaviour).
9. Reduced motion: if prefers-reduced-motion is set, disable zoomAnimation,
   fadeAnimation, markerZoomAnimation and inertia.
10. Remove the old viewport: delete the custom pan/zoom code and #tiles in
    exploration.js, tileCoordinate in mission.js (and any test of it), and the
    SVG grid drawing in app.js. Move PIA23386 (THEMIS) to Sources only. Update
    browser-test.html so the existing intents (tiles decode, zoom, pan, reset,
    missing-tile fallback, routing after asset failure, hazard, return) are
    tested through the Leaflet map.
11. Labels: imagery OBSERVED; grid-cell lat/lng DERIVED; sector, Hab, stops,
    hazards, costs SIMULATED.
12. Documentation: update STATUS.md (Task 1 row), move the Leaflet map from
    ARCHITECTURE.md Part B to Part A only after it is verified, and update
    DATA_SOURCES.md and README.

ACCEPTANCE
- Spike checks a-d pass in browser-test.html.
- Code check (report the grep results): no CSS-transform pan/zoom code, no
  getBoundingClientRect-based map positioning, no lon/lat-to-pixel function
  outside Leaflet.
- After pan and zoom at three zoom levels, for Hab, one stop and one route
  vertex, map.latLngToContainerPoint(gridToLatLng(x, y)) matches the DOM
  marker centre (or the Leaflet layer point for canvas vertices) within 1 px.
- 4 km north-south and east-west extents each measure 4000 m within 1 m by
  map.distance.
- At the maximum native zoom a 100 m cell is more than 8 screen px wide
  (measure with latLngToLayerPoint).
- The delta is visibly inside the sector ("visually confirmed by the agent").
- tileerror shows a message and routing still works.
- All existing tests, geo.test.js and browser checks pass.
- Keyboard: arrow keys pan, plus and minus zoom, Tab reaches the Hab and stop
  markers with visible focus.
STOP POINT: 3.5 hours. If level 12 tiles are unavailable, use level 11, say so
in the UI and report, and continue.
```

---

## Task 3 — Send to Tablet

Depends on Task 1. Stop point: 2.5 hours.

```
TASK 3: SEND TO TABLET. Add a mission-control to wrist-tablet handoff with an
original design. No film assets, screenshots or recreated film UI.

PLAN OBJECT (plan.js, pure)
Implement exactly the schema in FEATURE_PLAN.md section 5: schemaVersion,
sectorId, hab, current, stops[], hazard, sol, labels, checksum. It carries
INPUTS only. The tablet recomputes routes with the same deterministic A*.
Functions: makePlan(state), serializePlan(plan) -> base64url string,
parsePlan(string) -> {ok:true, plan} or {ok:false, error}, validatePlan,
checksum (simple deterministic hash is fine; this is integrity, not security).
plan.test.js: round trip, tampered checksum rejected, wrong schemaVersion
rejected, out-of-range grid coordinates rejected, malformed base64 rejected,
oversized input rejected.

MISSION CONTROL
Add a "Send to Tablet" button. On press: build the plan from current state,
animate a tablet frame sliding in on the same page (respect
prefers-reduced-motion: no slide, just appear), populate it.

TABLET VIEW (tablet.html plus tablet.js, shared modules from Task 1)
- Layout around 360 px wide, high contrast, large type, original styling.
- Local mini-map: a second Leaflet map instance created by the same
  createSectorMap() factory as mission control (Task 1), restricted with
  maxBounds and centred on the astronaut; same overlay modules. No separate
  projection code.
- Heading arrow and distance to next waypoint in metres (geo.js), next stop
  name, modeled route cost labelled SIMULATED.
- Buttons: Return to Hab, Simulate dust hazard, Reset. Native buttons,
  keyboard operable, 44 px targets.
- Hazard on the tablet replans locally. Show the dashed pre-hazard route and
  the new solid route. If no route: show "NO ROUTE AVAILABLE" and draw nothing.
- Persistent disclaimer and data-class badges on the tablet too.

HANDOFF OPTIONS (no backend)
1. In-page slide-in (primary demo path).
2. "Open on phone": render the URL tablet.html#<serialized plan> and a QR
   code. Generate the QR locally. Either write a small encoder or vendor an
   MIT-licensed library in /vendor/ with its LICENSE and an entry in README;
   state which and why. If generation fails, show the URL with a Copy button.
   Note in the UI that a phone needs the public URL to open the link.
3. Optional: BroadcastChannel "ares-plan" so a second window updates live.
   Mark as optional; skip if time is short.

ACCEPTANCE
- Plan sent from mission control shows identical stops, Hab and route on the
  tablet (browser check compares both route paths).
- Opening tablet.html with a valid hash reproduces the plan; an invalid hash
  shows a clear error panel, never a crash or blank page.
- Dust hazard on the tablet changes only the tablet's route.
- Tablet usable at 360 px width with no horizontal scroll, keyboard reachable.
- plan.test.js and all existing tests pass; browser-test.html extended.
- Labels: plan fields HYPOTHETICAL/SIMULATED; imagery OBSERVED.
STOP POINT: 2.5 hours. Drop BroadcastChannel first, then QR (keep the Copy
URL), never the in-page handoff.
```

---

## Task 2 — Sol timeline (Tier B — owner approved, after verified Tier A)

Depends on Task 1. Stop point: 2 hours.

```
TASK 2: SOL TIMELINE. Let the user watch one hypothetical astronaut's
multi-day activity unfold on the registered map. All SIMULATED.

MODEL (sols.js, pure)
- mission.sols: ordered list of {sol, label, stops[], logEntry, hazardEvent?}.
  Default 8 Sols, one EVA each, built from the existing stops; every Sol
  starts and ends at the Hab.
- Route per Sol from planMission. Cumulative cost array per route.
- positionAt(sol, t) where t in [0,1] interpolates along the Sol's path by
  cumulative modeled cost (document that this is cost-based, not physical).
- A Sol is labelled "Sol" only; the legend may mention a Sol is about 24 h 39
  min as general knowledge. No clock, weather or telemetry.
- Optional hazardEvent {cells, atT}: when scrubbing past atT, replan the
  remainder and append a log line.

UI
- Scrubber with Sol and time, play/pause, speed (1x/2x/4x), keyboard operable
  (arrow keys step, space toggles play). Respect prefers-reduced-motion by
  defaulting to paused and stepping instead of animating.
- Trail: solid line for path traveled, dashed for future path (Leaflet
  polylines in the routes pane).
- Readout panel (SIMULATED badge): Sol, lon/lat (DERIVED), metres traveled,
  metres to Hab (straight geodesic AND route length), modeled cost, current
  stop, log entry.
- Mission log list with the current Sol highlighted.

TESTS (sols.test.js)
- positionAt deterministic; t=0 equals start, t=1 equals end.
- Every returned position lies on the planned path.
- Trail length equals cumulative route length up to t.
- Sol with hazardEvent produces a valid replanned path or a no-route state.

ACCEPTANCE: scrubbing to any Sol/time yields a deterministic position; trail
matches the route; end of the final Sol is the Hab; units labelled m/km;
SIMULATED shown; browser check scrubs three points and compares the marker.
STOP POINT: 2 hours. Drop speed control, then hazard events, never the
scrubber.
```

---

## Task 6 — Fog of War as simulated reconnaissance (Tier B — owner approved, after Task 2)

Depends on Task 2. Stop point: 1.5 hours. Explicitly approved by the owner in the addendum.

```
TASK 6: FOG OF WAR. Implement it as SIMULATED RECONNAISSANCE on the planning
layer. It must never be presented as real detection and must never hide real
imagery as if it were unobserved.

RULES
- The orbital imagery is already OBSERVED for the whole sector. Do not mask
  or darken it. Fog applies only to the planning overlay: cells are UNKNOWN or
  REVEALED in the astronaut's simulated knowledge. Draw fog as a Leaflet layer
  in the fog pane (interactive false), above the grid and below the routes.
- Reveal rule (fog.js, pure): a cell is REVEALED if it lies within R cells of
  any point on the traveled trail (default R = 3, i.e. about 300 m, a
  SIMULATED sensor radius, configurable constant). Start state: only the
  Hab neighbourhood is revealed.
- Planning effect: UNKNOWN cells get an uncertainty penalty added to the A*
  cell penalty (default 0.5, configurable, SIMULATED). With the penalty set to
  0 the behaviour must equal the pre-fog behaviour exactly.
- Revealing new cells triggers a replan of the remaining route; log it in the
  mission log ("Reconnaissance revealed N cells; route updated").
- Mandatory visible label: SIMULATED RECONNAISSANCE - not real obstacle
  detection. Toggle "Fog of War" off by default in mission-control view, on in
  the Sol demo if the owner enables it. Add a short help text explaining the
  difference between real orbital coverage and simulated knowledge.
- Do not use fog to imply hidden hazards exist. Hazard cells remain explicit
  scenario inputs.

TESTS (fog.test.js)
- reveal set grows monotonically along the trail; deterministic.
- penalty 0 gives identical routes to before (compare with existing tests).
- with penalty > 0 and a known corridor, the planner prefers the revealed
  corridor when path lengths are comparable.
- reveal event causes a replan result that is valid or no-route.

ACCEPTANCE: label always visible when fog is on; real imagery never masked;
tests pass; accessibility: fog is conveyed by pattern or outline as well as
tone, not colour alone.
STOP POINT: 1.5 hours.
```

---

## Task 5 — Terrain-aware cost (Tier C, gated)

Depends on Task 1. The **spike (step 1) is time-boxed to 60 minutes** and must be reported to the owner before step 2 starts.

```
TASK 5: TERRAIN-AWARE COST, GATED.

STEP 1 - VERIFICATION SPIKE (60 minutes max, report then STOP)
Find out whether NASA Mars Trek (or another NASA/USGS source) provides an
elevation product that (a) covers the sector from sector.js, (b) can be
downloaded or fetched as numeric georeferenced data (not a rendered image),
and (c) documents horizontal resolution, vertical units, datum, projection
and nodata. Method: search assets/trek-catalog.json for entries with
elevation, topography, DEM, MOLA, HRSC or CTX-DEM in the label, category or
description whose bbox contains the sector; then check Trek's documented
tile/API pages for how to obtain them. Report for each candidate: name,
URL, resolution, coverage, access method, licence/credit, size.
If nothing qualifies, STOP. Do not use screenshots, shaded relief, image
brightness or hand-drawn elevation. Document the negative result in
DATA_SOURCES.md and RESOURCE_GAP_AUDIT.md and end the task.

STEP 2 - ONLY IF STEP 1 SUCCEEDS AND THE OWNER APPROVES
1. Offline script scripts/make-slope.js (or Python, state which) that samples
   the elevation to the 40x40 grid, computes slope (Horn/Sobel in metres on
   the sphere), and writes assets/derived/slope.json with metadata: source,
   resolution, method, units, date, sector id, limitations.
2. Resolution warning: if the DEM resolution is coarser than the cell size,
   say slope is smoothed and cannot represent astronaut-scale obstacles.
3. Add a slope penalty to the cell cost in one documented module (units,
   weights, rationale). Thresholds 8 and 15 degrees are design assumptions
   from the original brief, NOT validated standards; expose as configurable
   constants labelled SIMULATED/INTERPRETED. Weight 0 must reproduce the
   existing behaviour exactly.
4. Slope layer in the layer manager labelled DERIVED with legend and source
   card. Route explanation showing cost split: distance vs slope.
5. Tests: five spot-check cells against an independent calculation in the test
   file; flat-terrain case equals old behaviour; raising the weight changes
   the route in a constructed case.

ACCEPTANCE: UI states "derived from orbital elevation, coarse"; no claim of
safety or traversability; every number traceable to the source metadata;
all existing tests pass.
```

---

## Task 7 - 3D Mars globe

NEW task; not part of Task 1 and never a replacement for the registered 2D map. Depends on **verified Task 1** in STATUS.md. Feature vision approved; full implementation is NOT authorized yet. Protect Tier A (0, 0D, 1, 3) and Tier B (2, 6) first. Task 5 has its own independent gate. This documentation pass does not start the spike.

### Step 1 - verification spike (60 minutes maximum; report then STOP)

Start only if Task 1 is verified and the remaining A/B acceptance and release windows are protected. End by 13:30 GMT Sunday 15 November even if 60 minutes remain. Suggested budget: renderer/license/static-loading 15 min; imagery/capabilities/acquisition 20 min; browser/performance/fallback 20 min; evidence and owner recommendation 5 min. Do not turn this spike into production integration.

1. Compare candidate globe renderers from their official documentation/source and license. Prefer explicit Mars radius/custom ellipsoid support; verify coordinate conventions and radius units, not an Earth default. Propose an exact version, vendored files under vendor/<name>/, permissive LICENSE and justification; list uncompressed/compressed dependency bytes and any workers, WASM, fonts or other runtime assets. No CDN or new build step. No candidate or dependency is approved automatically.
2. Discover NASA Mars Trek GLOBAL imagery through the official WMTS documentation. Read each candidate's GetCapabilities XML: exact endpoint, layer identifier/title, style, TileMatrixSet and SupportedCRS, matrix levels/limits, bbox, origin, row/column counts, tile dimensions, ResourceURL and actual PNG/JPG extension. A Jezero mosaic is regional, not a global texture. Do not guess endpoints or infer availability from a layer name.
3. Determine whether an authorized single NASA-sourced equirectangular global texture is obtainable, or documented WMTS tile conversion is feasible. Verify usage conditions, credit, acquisition method, coverage (seams/poles/no-data), longitude direction/domain, latitude convention and renderer UV orientation. Document any resampling/conversion and source lineage. No illegal scraping, unbounded tile enumeration, Earth textures or synthetic NASA-like substitute.
4. Test browser CORS if acquisition requires browser fetch/canvas; record actual request origin/headers and pixel-read outcome. Server-side acquisition success does not prove browser CORS. Runtime must use local assets with no API key or network dependency. Report encoded bytes, decoded dimensions, estimated texture memory (including mipmaps) and total offline package size. Any unapproved size/licensing constraint is a stop, not permission to ship.
5. Run in a real browser on an identified typical laptop: browser/version, OS, CPU/GPU, viewport, WebGL version/MAX_TEXTURE_SIZE. Measure first usable load, drag/zoom responsiveness/frame rate, peak memory where observable (otherwise label not measured), repeated enter/leave behavior and context loss. Test a blocked/unsupported WebGL context and missing texture: show an honest unavailable message plus keyboard-accessible direct Surface Mode, never crash or show fake Mars. Record measured results for owner go/no-go; do not fabricate universal performance thresholds.
6. Verify alignment of source-linked reference points and texture seams; test reduced motion, keyboard controls, focus transfer and narrow layout (360 px minimum). Planetary renderer owns only its globe; Leaflet remains sole Surface Mode viewport owner. Dispose/pause the globe when hidden to avoid dual render loops. No 3D on tablet.
7. Report candidate matrix, exact citations, feasibility failures, acquisition/CORS evidence, offline/download/GPU budgets, laptop measurements, tests and proposed limits. Update Task 7 in STATUS.md with actual evidence only. **STOP for separate owner go/no-go** on renderer, dependency/assets and full implementation, even if all checks succeed.

### Stop conditions and fallback

Stop at 60 minutes, the 13:30 cutoff, failed Task 1 prerequisite, risk to A/B, unavailable authoritative global imagery/coordinates, unclear license, incompatible projection/texture, unresolved CORS when required, unacceptable or unapproved footprint, no viable static renderer or failed browser/fallback checks. Preserve the functioning 2D map; record the globe as NOT IMPLEMENTED. Do not spend deployment/submission time debugging 3D. No feature/data/dependency work beyond 14:30; public check 15:15, final commit 15:45, code freeze 16:00 GMT. No full implementation without an explicit owner decision; implementation stop point/budget must be agreed in that decision.

### Step 2 - full implementation acceptance (ONLY after owner go)

- Rotatable/zoomable real Mars globe using verified NASA imagery; source links, exact credit and persistent disclaimer visible. Correct Mars radius/coordinate/texture mapping demonstrated; no Earth default silently accepted.
- Verified rover markers (Curiosity and Perseverance where evidence permits) with source-linked mission metadata, coordinate frame, epoch, and location type (landing site, published dated position, or historical traverse). Unknown current positions are not established; omit unverified markers/tracks. Real mission facts must remain distinct from SIMULATED astronaut elements. Never place a Gale traverse on Jezero.
- Selectable SIMULATED/HYPOTHETICAL ARES-HUD sector transitions to the existing registered Jezero Surface Mode; Return to Planetary Mode preserves the validated surface plan. Rover selection supplies context, not a new surface sector. Direct Surface Mode remains available without WebGL; tablet requires no 3D.
- Preserve multi-stop A*, dust reroute, emergency Return to Hab and no-route behavior; lon/lat, scale, provenance, validated Send to Tablet/local recomputation, and approved Sol/reconnaissance features remain intact. No routing from globe texture colors or geology.
- Keyboard-accessible rotation/zoom and equivalent focusable mission/sector list, visible focus and predictable focus after transitions; reduced-motion handling with no forced animated descent or auto-spin; responsive fallback at 360 px and desktop; no information conveyed by color alone.
- Real browser acceptance covers globe interaction, mission sources, transitions in both directions, asset failure, unsupported/lost WebGL, local/offline loading, tablet flow, memory/performance against owner-approved limits and zero unintended console/network errors. All existing Node and browser tests pass, with regression coverage for new transition/marker validation/fallback logic. Report exact browser/device evidence; no invented passes.
- Pin/vendor/license and justify every new third-party file; record actual asset URL, credit, retrieval date, bytes, SHA-256 and any conversion manifest in DATA_SOURCES.md. Static no-backend/no-build architecture preserved.
- Update STATUS.md with actual commit and evidence. Only STATUS.md may mark the feature DONE. Move verified architecture from Part B to A only after acceptance. Failed gate leaves 2D working and 3D explicitly NOT IMPLEMENTED.

---

## Checklist for the owner before accepting a task

- [ ] Report is in the required format and says what was NOT verified.
- [ ] `npm test` output pasted; test count increased where expected.
- [ ] Opened in a real browser and clicked through the demo flow.
- [ ] No `?` characters where dashes belong; files are UTF-8.
- [ ] New assets recorded with source, credit, bytes, SHA-256.
- [ ] Labels visible: OBSERVED / DERIVED / INTERPRETED / SIMULATED.
- [ ] Disclaimer visible on every view including the tablet.
- [ ] Markdown committed with `git add -f`.
- [ ] Nothing from the film *The Martian* is included.
- [ ] STATUS.md rows updated with commit and evidence; no other document claims DONE.
- [ ] No new 2D screen-projection or CSS pan/zoom code outside Leaflet; any approved 3D renderer is confined to Planetary Mode.