> React migration update, 14 November 2026: the owner explicitly requested React + Vite integration using `react-ui-handoff/`. That request supersedes older build deferral statements here. Static hosting, existing algorithms, provenance, separate globe/elevation gates and release schedule remain applicable. Current architecture is in ARCHITECTURE.md; acceptance is recorded only in ../STATUS.md.

> CURRENT WORKFLOW: root README and STATUS are owner-approved entry points; docs/README is navigation. v0.3 globe scope, Sunday release gates and no-new-build rules in the addendum supersede the older restrictions below.

> Precedence: [AGENT_RULES_ADDENDUM.md](AGENT_RULES_ADDENDUM.md) takes precedence for its approved items; [STATUS.md](../STATUS.md) alone records migration completion.

# AGENTS.md — ARES-HUD agent operating instructions

## Owner-selected target technology stack

| Component | Recommendation |
| --- | --- |
| Frontend | React + Vite |
| Map display | Leaflet with a custom Mars image overlay |
| Route algorithm | JavaScript A* |
| Terrain processing | Python + NumPy, if needed |
| Data | NASA resources linked from the challenge |

This is the requested target stack, not a claim that migration is implemented. React, Vite, Leaflet and optional NumPy are approved dependencies. A Vite build step is allowed; the built application must remain statically hostable without a backend. Preserve the pure JavaScript A* behavior and its tests. Use a suitable custom Mars coordinate system for Leaflet; do not assume Earth/Web Mercator coordinates. An image overlay alone does not verify georeferencing, scale or terrain measurements. Terrain processing remains optional and gated on verified numerical data and provenance. Retain NASA attribution, simulation labels and the non-flight-qualified disclaimer.

This owner decision supersedes earlier plain-JavaScript-only, no-build, no-Leaflet and dependency restrictions for these technologies. Other scope and data-verification gates remain applicable.

**Owner:** Team Martian  
**Read first, in order:** [Tonight's build plan](BUILD_TONIGHT.md), [project README](README.md), [judging rules](JUDGING_CHECKLIST.md), [feasibility audit](ARES_HUD_ONE_DAY_AUDIT.md), [Global Offers](toolgiven.md).

## Owner amendments and working documentation

Read [AGENT_RULES_ADDENDUM.md](AGENT_RULES_ADDENDUM.md) immediately after this file. Its explicitly listed owner amendments take precedence for those items. Consult [FEATURE_PLAN.md](FEATURE_PLAN.md) and [AGENT_TASKS.md](AGENT_TASKS.md) for planned work; plans are not implementation evidence. Keep the working [README.md](README.md) current here in `docs/`; prepare the official root README only when the owner requests it. Commands and application/asset paths in these documents are relative to the repository root unless stated otherwise.

## Time-critical operating rule (Saturday 14 November 2026)

**Code freeze at 00:00 Sunday 15 November 2026, Europe/London time (midnight tonight).** The **official NASA submission** is due Sunday 15 November at 23:59 **in the team's event-local timezone**; do not confuse the two. The 30-second demo video will be prepared **after** the code freeze on Sunday.

Your job before midnight is a clean **deployable app** with tested routing, one actual correctly attributed NASA asset, a simple simulated dust-triggered reroute, and a clearly labeled Return to Hab. **Do not generate or edit the demo video tonight.** Do not start an optional feature after 21:30. Prioritize running code over plans. If source verification is blocked, show an honest placeholder, finish the route demo, and flag missing NASA integration to the owner explicitly.

**Prioritize tasks that improve official judging: Validity, Relevance, and Presentation.** Do not invent NASA observations. The judge's 2026 guide requires references to every external code/image/text asset, even if free/open-source. A solo Local Event team is eligible for Global Judging; a solo Universal Event team is not.

## Mission

Build **ARES-HUD v0.1** as a small, reliable, fully client-side *Mars EVA tactical mini-map demonstrator*. Its differentiator is a **real NASA-sourced Mars visual background** combined with **clearly simulated** grid costs, A* path planning, and a scenario-based reroute-to-Hab interaction.

The human owner controls the concept, approved NASA assets, citations, and submission. **Never invent NASA readings, imagery, coordinates, surface labels, provenance, flight safety limits, or live telemetry.**

## Scope boundary

**MUST implement:**

1. Accessible dark HUD screen displaying an actual *user-provided or verified downloaded* NASA Mars asset from the selected challenge's resource list. Until provided, use a **plain labeled placeholder**; never substitute an AI-generated 'NASA' image as evidence.
2. Display Hab and one clickable/selectable science waypoint on a conceptual **4 km × 4 km** map window.
3. Implement deterministic **40×40 grid** and **A*** route calculation with tests. Synthetic costs must be labeled `SIMULATED`.
4. Button **Simulate dust hazard** inserts a known hazard/blocked region and causes a **visible before/after reroute** where a detour is possible.
5. Button **Return to Hab** creates a route from selected/simulated current position to Hab; show 'No route available' if blocked.
6. Clear in-UI NASA credits/source link and prototype disclaimer, mobile-friendly styling, no broken navigation.

**MUST NOT implement until owner explicitly approves:** 3D globe, rover/astronaut LiDAR, Fog of War, live Mars weather, radiation physics, suit oxygen/battery forecasting, comms simulation, real astronaut-safe range rings, geologic sand-trap classification, automatic georeferencing by pixel color, paid cloud deployment, account/auth backend, premium custom domain, real-time sync.

**Nice-to-have only:** one properly credited Perseverance image (without implying it is a photo of a fictional waypoint), CSS-only compact HUD mode.

## Scientific and provenance rules

- Show `NASA SOURCE` only for genuine, documented NASA imagery/data. The exact asset URL, visible dataset/layer name when known, original source, credit, and attribution belong in `README.md`.
- Show `SIMULATED COST`, `SIMULATED HAZARD`, and `MODEL OUTPUT — SIMULATED INPUTS` for fictional routing assumptions.
- If a real georeferenced elevation grid is supplied, **only then** may the owner authorize `DERIVED SLOPE` after verification of spatial reference, vertical units, scale, and calculations.
- **Do not imply a 40×40 cell is a boulder-scale scan.** At 4 km across, each cell is nominally 100 m.
- Do not show fake lat/lon or fabricated rover image metadata. A waypoint not independently geolocated is `HYPOTHETICAL`.
- Persistent warning: **'Hackathon planning demonstrator. Routes and hazards are simulated; not flight-qualified navigation.'**

## Recommended minimal repository

```text
/
  index.html
  styles.css
  app.js
  pathfinding.js
  pathfinding.test.js
  assets/
    README.md         # provenance, exact image filename, source link
  README.md
  toolgiven.md
  ARES_HUD_ONE_DAY_AUDIT.md
  BUILD_TONIGHT.md
  JUDGING_CHECKLIST.md
  AGENTS.md
```

Use the owner-selected React + Vite frontend and Leaflet custom Mars image overlay for the migration; retain JavaScript A*. Python + NumPy may be used offline for verified terrain processing if needed. If testing with Node, use `node --test pathfinding.test.js`. Static hosting must work without a backend.

## Routing algorithm contract

- 40 × 40 deterministic cells; start, goal, cost penalty, blocked flag, hazard status.
- Eight directions (orthogonal weight 1, diagonal `sqrt(2)`); diagonal moves cannot squeeze between blocked orthogonal neighbors.
- Cost for entering a cell = step length × `(1 + max(0, penalty))`; cannot enter blocked cells.
- Use a Euclidean admissible A* heuristic. Implement a stable deterministic tie-break if useful.
- Recompute on destination selection, hazard toggle, and Return-to-Hab.
- Correct empty/no-path behavior; never render a straight-line escape through a barrier.
- Tests: straight line; symmetric blocked detour; fully enclosed goal; blocked start or goal; corner cutting; deterministic hazard reroute.

## Work order — complete the MUST features by midnight, log evidence at each milestone

1. **Skeleton:** usable HUD with empty map placeholder and source/legend footer. Browser works.
2. **Map & controls:** show actual *owner-approved* NASA asset and hypothetical Hab/waypoint. Document the asset's real provenance; no guessing.
3. **Routing:** implement grid, A*, visual path and self-tests. Report test command/results.
4. **Scenario:** simulated hazard redraws route. `Return to Hab` works, including no-route fallback.
5. **Polish & handoff:** responsive UI, clear legend, source attributions, deployment and tests. Prepare a short list of what to demonstrate **on Sunday**, but do not produce the video before the midnight freeze.

If the NASA asset is not ready, **proceed with UI and A* on a visibly synthetic grid**, but **block claims of complete challenge resource integration** until a real source is shown. Do not let asset download problems stall the rest of the implementation.

## Acceptance criteria

- One-click hazard changes a visible route; Return to Hab is functional.
- Tests run locally and cover path/no-path/corner-cut cases.
- No console errors or missing asset links in deployed site.
- Every display distinguishes actual NASA source from modeled/simulated content.
- Clearly sourced NASA data is *used in the project*, not merely linked in documentation.
- README and source register say exactly what was implemented; no speculative claims about scientific accuracy.

## Immediate Codex task to paste into the agent

> Read `BUILD_TONIGHT.md`, `AGENTS.md`, `JUDGING_CHECKLIST.md`, `ARES_HUD_ONE_DAY_AUDIT.md`, `README.md` and `toolgiven.md`. Deliver a working and deployed app by the internal code freeze, **00:00 on Sunday 15 November 2026**; demo video is tomorrow. Implement only the MUST scope for ARES-HUD v0.1 as an entirely static HTML/CSS/JavaScript app. Begin with a placeholder for NASA Mars imagery until I provide the verified asset. Implement and test 40×40 deterministic A* with a simulated dust-zone reroute and a Return-to-Hab control. Label all invented grid costs and hazards SIMULATED. Keep a source attribution area and explicit non-flight-qualified disclaimer. After each milestone, show files changed, local verification, and remaining risks. Do not add a backend, cloud services, real-time telemetry, or features outside the audit. Never invent scientific data or image provenance.

## Hard cutoffs / fallback rules

- If data-export or georeferencing is still blocked after **60–75 minutes**, stop research; continue with an explicitly sourced Mars visual and a clearly separate simulated grid. Mark Relevance risk honestly; no invented measurements.
- If routing does not pass tests by the midpoint, stop visual polish. Fix A* or use a rigorously tested Dijkstra fallback.
- **21:30 Saturday**: do not add new features.
- **22:30 Saturday**: freeze dependencies/data changes and run full tests.
- **23:15 Saturday**: public deploy checked and README accuracy audit.
- **23:45 Saturday**: commit and tag the code-freeze build; do not start a new feature.
- **00:00 Sunday**: code freeze; video and final Project tab work happen on Sunday.

## Submission handoff

- `README.md` states implemented features, source citations, limitations and local-run instructions.
- Public deployment link verified by the human owner in a private browser window.
- Required demonstration **≤30 seconds** or **≤7 slides**; longer video only supplementary.
- Include all AI assistants actually used in submission documentation, including Codex/GitHub Copilot if used.
- Submit via the Space Apps **Project** tab by 15 November 2026, **11:59 p.m. local event time**.

Sources: [2026 judging and awards guide](https://www.spaceappschallenge.org/resources/judging-awards-guide/) · [Challenge](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/) · [Mars Trek](https://trek.nasa.gov/mars/) · [2026 submission clarification](https://github.com/nasa/spaceapps/discussions/1991) · [NASA data requirement](https://github.com/nasa/spaceapps/discussions/1827).
