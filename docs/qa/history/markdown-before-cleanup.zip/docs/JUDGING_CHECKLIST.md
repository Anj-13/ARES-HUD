> ACTIVE REFERENCE - official-rule links and team-provided guide summary retained; not independently revalidated in Task 0D. Use [STATUS.md](../STATUS.md) for implementation/deployment evidence; submission eligibility remains owner-verified.

# JUDGING_CHECKLIST.md — NASA Space Apps 2026 official guide

**Source:** Team-provided PDF `NASA Space Apps Challenge.pdf` — **Judging & Awards Guide**, dated **13 November 2026**, 12 pages.  
**Official webpage:** https://www.spaceappschallenge.org/resources/judging-awards-guide/  
**Related team file:** [BUILD_TONIGHT.md](BUILD_TONIGHT.md).

This document paraphrases the supplied **2026** guide; it is not based on previous-year rules. Confirm event-local timing with the Local Lead if uncertain.

## Eligibility and submission (guide page 3)

- [ ] Project responds to an official 2026 Space Apps challenge: [Interplanetary Survival Guide: Martian Map](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/).
- [ ] Every team member is registered for the **same Local Event** and appears in the team **Members** tab; none is waitlisted. Teams have **at most 6 members**.
- [ ] **Local Event teams require at least 1 member** for Global Judging eligibility, so Team Martian may submit solo if appropriately registered. **Universal Event teams require at least 2 members.**
- [ ] Complete **all required fields** on the official team **Project** tab.
- [ ] Provide either a **maximum 30-second video** or **maximum 7-slide presentation** (including intro/title slides).
- [ ] Write the submission and linked materials in **English**. A video may speak another language **if it has English subtitles**.
- [ ] Submit by **Sunday 15 November 2026, 23:59 at the Local Event's local time**; if registered for the Universal Event, use the Team Owner's local time.
- [ ] Agree to the required submission terms, privacy and originality acknowledgments.
- [ ] Put **all external resources** used in the submission's **References** field: code, text, imagery, third-party libraries, NASA datasets and other assets **even if open source or free**. Ensure permission for copyrighted material. Transparently disclose AI assistance used.

**Internal team milestone:** code complete and frozen at **00:00 Sunday 15 November**; demo recorded afterwards. This is **not a NASA rule**.

## Judging criteria (guide pages 5–8)

All five categories receive a **1–5 score**, at every round.

| Criterion | Official emphasis | Concrete ARES-HUD evidence to demonstrate |
| --- | --- | --- |
| **Impact** | Size/importance of problem and who benefits | Local EVA excursion safety-planning use case, route-to-Hab task; do **not** claim actual flight readiness |
| **Creativity** | Original or meaningfully improved idea | Tactical visor/wrist mini-map framing, scenario-based rerouting with clear interaction |
| **Validity** | Scientific principles, technical and logical feasibility, usability | Working tests, deterministic A*, blocked route handling, transparent simulated inputs, clear limits |
| **Relevance** | Direct challenge fit and NASA data **integral rather than superficial** | Actually integrated NASA map/data, meaningful source-based map interactions, verifiable asset lineage; route costs labeled simulated unless measured |
| **Presentation** | Clearly explain problem, solution and significance | Single reproducible walkthrough from Hab to science target to hazard reroute, backed by clean UI and concise captions |

**Important Relevance warning:** A NASA image used solely as the backdrop for unrelated invented numbers is a weak integration. Treat the app's NASA map as genuine geographic context, record exact source/layer and extent if known, and, if verified numerical measurements exist, show a clearly derived map analysis. Never claim synthetic risk scores are measured science.

## Global Awards fit (guide page 12)

The guide lists ten award types. **Best Mission Concept** is plausibly relevant to a documented EVA planning concept; **Best Use of Data** requires convincing genuine data use; **Best Use of Technology** may be relevant to the route-planning interaction. These are **possible categories, not scores or endorsements**. All projects are still judged on the five criteria above.

## From the user's PDF: two critical copyright/originality cautions

1. You may name the team **Martian** and describe film inspiration, but **do not include copyrighted film clips, branded imagery or music** from *The Martian* without permission.
2. Even a NASA image or free JavaScript library must be **listed in References** with a direct link and credit. Check each asset's usage conditions; do not assume all image copyrights are identical.

## Submission evidence register — fill once app exists

| Evidence required | Real value | Check |
| --- | --- | --- |
| Team member/event eligibility | **Confirm with Space Apps account** | [ ] |
| Challenge source resource actually integrated | **See STATUS.md; owner eligibility review pending** | [ ] |
| Exact used NASA URL/layer, year/mission, attribution | **See STATUS.md; owner eligibility review pending** | [ ] |
| App public URL (works without login) | **No public URL verified; see STATUS.md** | [ ] |
| Git repository URL/revision | **Working-tree baseline over 5d79741; see STATUS.md** | [ ] |
| All third-party source/library/code/AI references | **Pending actual use** | [ ] |
| Demo URL (≤30 seconds) or slide deck (≤7 slides) | **To do Sunday** | [ ] |
| Space Apps submission confirmed | **To do Sunday before 23:59** | [ ] |

## Reference URLs

- [Official NASA 2026 Judging & Awards Guide](https://www.spaceappschallenge.org/resources/judging-awards-guide/)
- [Official 2026 challenge](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/)
- [NASA Mars Trek](https://trek.nasa.gov/mars/)
- [Mars 2020 Perseverance raw images](https://mars.nasa.gov/mars2020/multimedia/raw-images/)

*Accurate status matters more than an inflated demo: only mark capabilities complete when the code and sourced data actually work.*
