# Verified local Git history — re-read 14 November 2026

- f707f92 Nov-14: the legacy with old html, css, js files (2026-11-14 21:41:45 +0000)
- 0806320 Nov-14: Updating the skeleton (2026-11-14 21:41:11 +0000)
- 8393743 Nov-14: react-skeleton (2026-11-14 20:51:49 +0000)
- e7f5c4d Nov-14: Add tablet feature (2026-11-14 19:49:43 +0000)
- 500c115 Nov-14: revive the map (2026-11-14 19:04:44 +0000)
- 0036eac Nov-14: update the map (2026-11-14 17:03:38 +0000)
- 0662159 Nov-14: Add asset (2026-11-14 17:02:42 +0000)
- 900198f Nov-14: updated gitignore (2026-11-14 17:01:46 +0000)
- 5d79741 Nov-14: prototype 1 (2026-11-14 13:56:31 +0000)
- af9ac9e Nov-14: Add the initial files (2026-11-14 13:26:47 +0000)
- 802e097 Nov-14: Added gitignore file (2026-11-14 13:22:15 +0000)
- 4443777 Initial commit (2026-11-14 13:19:23 +0000)

No new commit or tag was created in the reconciliation pass. Historical claims below are retained separately and validated in the baseline closure evidence.

## Preserved historical changelog (unverified claims)

> STATUS: HISTORICAL - describes baseline af9ac9e on 14 November 2026. Superseded by [STATUS.md](../STATUS.md). Finding tags were checked on 14 November 2026. Original timings and claimed checks are retained, not rerun.

## Verified Git history at Task 0D

```text
5d79741 2026-11-14 13:56:31 +0000 Nov-14: prototype 1
af9ac9e 2026-11-14 13:26:47 +0000 Nov-14: Add the initial files
802e097 2026-11-14 13:22:15 +0000 Nov-14: Added gitignore file
4443777 2026-11-14 13:19:23 +0000 Initial commit
```

`5d79741` adds the first imagery prototype and initial-files snapshots; later multi-stop/explorer changes are uncommitted, not additional verified commits.

## Task 0D reconciliation annotations — rechecked 14 November 2026

- **[RESOLVED] H1 / missing NASA imagery:** 24 genuine local CTX tiles at levels 10–12, source manifest hashes and two NASA reference JPEGs verified. Fresh level-11/12 requests return 200 PNG. Challenge/team eligibility is a separate owner submission check.
- **[OPEN] H2 / public acceptance:** local Edge desktop/narrow/keyboard and static-build tests pass; public URL, deployed revision, private-window and physical-device acceptance remain unverified.
- **[RESOLVED] M1 / no-route UI:** original and React browser harnesses exercise a blocked grid/plan, show unavailable results, omit an active route and recover after reset.
- **[RESOLVED] M2 / identical-endpoint narrative:** browser-checked dust state says no detour is needed at an identical endpoint; other no-route/unchanged/detour states have conditional copy.
- **[RESOLVED] L2 / marker sizing:** every Hab/science native button measures 44 × 44 CSS px at desktop and 360 px; map projection checks pass after pan at three zooms.
- **[RESOLVED] L1 / stale handoff wording:** current README/STATUS identify the React working tree over real local Git history. No freeze tag, new commit or public deployment is invented.
- **[RESOLVED] Registered imagery / documentation baseline:** source matrix, 4 km sector, coordinates, distances, CTX/PDF comparison and local Markdown links rechecked. Eight/14/22/33-test and 16-tile claims below are historical only; current suite is 39 passing tests and cache is 24 tiles.
- **[OPEN] Numeric terrain / geology geometry:** no verified numeric DEM, slope, unit-to-grid overlay or operational safety model. The separately displayed USGS educational map is not a routing raster.
- **[UNVERIFIED] Original run metadata / official submission:** old timing, unavailable commit IDs, event portal, registration, official-guide and submission claims remain archival; fresh evidence does not retrospectively certify them.

Full finding-by-finding evidence, historical commit validation and comparison limits: [baseline closure report](BASELINE_CLOSURE_REPORT.md). [STATUS.md](../STATUS.md) alone records acceptance. The original record follows; its original present-tense statements and numeric results describe its historical revision.

# Changelog

Based only on available local Git history and reports. No release tag or public deployment is established. Commit times below are 14 November 2026, +0000.

## Documentation review — working tree

Updated README and added architecture, changelog, test report and data-source register. Corrected stale README repository status. Application and test code unchanged.

## af9ac9e — 13:26:32

**Nov-14: Add the initial files**

- Added static HUD, SVG renderer and scenario state.
- Added deterministic 40 × 40 grid, weighted eight-direction A*, corner-cut prevention and no-path handling.
- Added science selection, fixed dust reroute, position selection, Return to Hab and reset.
- Added eight routing tests and ES-module package configuration.
- Included simulation disclosures, NASA placeholder and prototype warning.
- Updated .gitignore, including Markdown exclusion.

## Repository setup

- `802e097`, 13:22:15: **Nov-14: Added gitignore file** — IDE/build-artifact ignore patterns.
- `4443777`, 13:19:23: **Initial commit** — MIT license, copyright 2026 Anjila Gurung.

## QA and fixes

[QA_REPORT.md](QA_REPORT.md) records passing routing checks and unresolved NASA integration, public/browser evidence, no-route UI coverage, identical-endpoint dust narrative, stale Git documentation and marker sizing findings.

[FIX_REPORT.md](FIX_REPORT.md) explicitly claims no production fix and says only that report was added. No bug-fix commit exists in the inspected history. This documentation pass corrects the stale README Git statement; remaining findings stay open. Reported checks are not additional implementation changes.
