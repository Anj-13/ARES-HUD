> HISTORICAL SNAPSHOT — reviewed 14 November 2026. Original baseline/test/schedule/commit statements below are archival, not current acceptance. Reconciliation: [baseline closure report](BASELINE_CLOSURE_REPORT.md). Only [root STATUS.md](../STATUS.md) records current task acceptance. Old root application paths map to `legacy/` or the current `src/`/`public/` locations in the migration report.

> HISTORICAL EVIDENCE: prior report, not current acceptance. [UNVERIFIED] Old test/commit claims unless independently repeated in [AUDIT_CURRENT.md](AUDIT_CURRENT.md). [STATUS.md](../STATUS.md) controls current migration status.

> STATUS: CURRENT - Task 1 evidence, recorded 14 November 2026 on the working tree over `155dd57`. Browser checks ran in headless Microsoft Edge on this machine; no public host, touch device or assistive technology was tested. [STATUS.md](../STATUS.md) alone records feature status.

# Task 1 report — registered Leaflet Surface Mode map

Baseline before this task: HEAD `155dd57` (`task-0` plus the tile-preflight fixes). Tests at start: `npm.cmd test` → 14 passed, 0 failed. Task 1 replaced the custom CSS-transform tile explorer and the separate SVG grid with one Leaflet map; it added no backend, build step or runtime CDN request.

## A. Leaflet spike (step 1, proved before the app was rewritten)

Leaflet 1.9.4 was vendored with `node scripts/vendor-leaflet.mjs` from `https://unpkg.com/leaflet@1.9.4/` (BSD-2-Clause). Files, bytes and SHA-256 values are in [DATA_SOURCES.md](DATA_SOURCES.md).

`map-crs.js` defines MarsEQ as `L.CRS.EPSG4326` plus `R = 3396190` (Mars 2000 sphere), with EPSG4326's own `L.Transformation(1/180, 1, -1/180, 0.5)`.

| Spike check | Expected | Measured | Result |
| --- | --- | --- | --- |
| Leaflet version | 1.9.4 | `L.version === "1.9.4"` | pass |
| a) Zoom 0 world size | 512 x 256 px; (90, -180) -> (0, 0), (-90, 180) -> (512, 256) | `0,0 -> 512,256` | pass |
| b) Level 10 tile row 403 / col 1463 NW corner | (1463*256, 403*256) within 0.01 px | `374528,103168` | pass |
| b) Level 12 tile row 1628 / col 5858 NW corner | (5858*256, 1628*256) within 0.01 px | `1499648,416768` | pass |
| c) `crs.distance`, 1 deg latitude | 59,274.7 m within 1 m | 59,274.698 m | pass |
| d) `map.distance`, 4,000 m apart | 4,000 m within 1 m | 4,000.000 m | pass |

Conclusion: Leaflet zoom equals the WMTS level with no `zoomOffset`, Leaflet's y equals the WMTS row, and the vendored `distance()` uses the CRS `R`. No fallback to CSS transforms or another library was needed.

The spike began as a temporary `leaflet-spike.html` and was then folded into `browser-test.html`; the temporary page was deleted.

## B. Sector placement (SIMULATED)

`sector.js` places `jezero-sector-1` at centre **18.51 N, 77.425 E**:

| Quantity | Value |
| --- | --- |
| Bounds | north 18.54374121 N, south 18.47625879 N, west 77.38941808 E, east 77.46058192 E |
| Size | 4 km x 4 km, 40 x 40 cells, 100 m nominal |
| Hab | cell (4, 20), west of the delta |
| Stops | delta front (23, 14), channel mouth (14, 10), distal lobe (28, 26) |
| Measured through Leaflet | 4,000.0 m north-south x 4,000.8 m east-west |

Placement was chosen from a level-12 composite of rows 1624-1629, columns 5856-5861 fetched for inspection (not added to the repository): the layered delta margin runs through the eastern half of the sector and the western half sits on the crater-wall approach, so a Hab-to-delta traverse is plausible. **Visually confirmed by the agent:** the delta is inside the sector. This is an agent observation of imagery, not a survey or a claim about the real landing site.

## C. Tile cache (step 4)

`node scripts/fetch-tiles.mjs` is idempotent: it hashes existing files instead of re-downloading and rewrites `assets/trek/manifest.json` with `level, row, col, url, file, bytes, sha256`.

| Level | Rows | Columns | Tiles |
| --- | --- | --- | --- |
| 10 | 406-407 | 1464 | 2 |
| 11 | 812-814 | 2928-2929 | 6 |
| 12 | 1625-1628 | 5856-5859 | 16 |

Total 24 tiles, **1,356,690 bytes (1,324.9 KiB)**. Run result: "downloaded 23 new tiles, 1,262.8 KiB added". Tiles now live at `assets/trek/{level}/{row}-{col}.png`, matching the Leaflet template `assets/trek/{z}/{y}-{x}.png`. The 16 previous level-10 tiles (rows 403-406, columns 1463-1466, ~1.0 MB) were deleted: they lie north of the new sector and are no longer served. All 24 manifest byte counts and SHA-256 values match the files.

## D. Modules, and removal of the old viewport (steps 2, 3, 5-11)

Added: `map-crs.js`, `sector.js`, `geo.js`, `geo.test.js`, `map.js`, `sector-layers.js`, `scripts/fetch-tiles.mjs`, `scripts/vendor-leaflet.mjs`, `vendor/leaflet/`.

Removed: `exploration.js`'s CSS-transform pan/zoom and `#tiles` image plane; `mission.js`'s `tileCoordinate` and its test; `app.js`'s SVG grid drawing. `exploration.js` now only builds source cards, the USGS panel and the surface-image fallback. The THEMIS image (PIA23386) is reference-only in Sources and is no longer drawn behind the grid.

`geo.js` is pure grid/sector maths (no Leaflet, no screen projection). `pathfinding.js` is untouched and still independent. `map.js` exports `createSectorMap(element, options)` for reuse by Task 3, with panes at the specified z-index (tiles 200, grid 410, hazards 420, fog 430, routes 450, markers 600), keyboard on, `maxBoundsViscosity: 1`, `zoomSnap: 0.5`, canvas renderer for grid/hazard/route geometry, and reduced-motion disabling of zoomAnimation/fadeAnimation/markerZoomAnimation/inertia.

## E. Browser checks (49/49)

`browser-test.html` was rewritten as a `type="module"` harness: the projection spike, then the real app in an iframe. Headless Microsoft Edge, `--virtual-time-budget=40000`, 1280 px window, virtual clock. Result: **PASS 49 (49 passed, 0 failed)**.

Grouped results:

- **Projection spike (6):** version, zoom-0 world, two tile-index checks, `crs.distance`, `map.distance`.
- **Map ownership (2):** Leaflet pane stack with scale-bar control; the map element really is a Leaflet container.
- **Tiles (2):** 5-8 cached tiles decoded at 256 px; the served tiles are level-12 sector tiles.
- **Markers and projection (4):** four markers for Hab plus three stops; every button has a descriptive `aria-label`; DOM centres match `latLngToContainerPoint` at zooms 11, 12 and 13 within 1.5 px (measured worst 1.00 px, integer rounding); 20 canvas route vertices match `latLngToLayerPoint` within 1 px (measured worst 0.00 px).
- **Measurement (3):** 4,000.0 x 4,000.8 m through `map.distance`; a 100 m cell is 11.0 px at zoom 12; sector extent text states the simulated footprint.
- **Readout (1):** pointer move reports the DERIVED cell (grid cell 20, 20).
- **Layer manager (4):** markers, imagery and the USGS panel toggle; opacity reaches the tile layer.
- **View (7):** zoom buttons reach 14, overzoom is disclosed, reset returns to the sector centre at zoom 12, Leaflet owns drag/touch/wheel/keyboard, panning moves the viewport, arrow key reaches Leaflet pan handling (80, 0 px), focus-visible style exists.
- **Keyboard (4):** `+` zooms, `-` zooms out, all four marker buttons are tabbable and take focus.
- **Failure tolerance (2):** a missing tile is reported and routing still works.
- **Mission flow (9):** three ordered segments, hazard recompute and copy, arrival leaves two stops, return to Hab, identical-endpoint status and copy, injected no-route, no-route explanation, recovery.
- **Disclosure (3):** OBSERVED/DERIVED/SIMULATED labels and the footer disclaimer are present.

Two harness accommodations are recorded rather than hidden: headless Edge throttles `requestAnimationFrame` for off-screen frames, so the harness sets `map._zoomAnimated = false` (cosmetic zoom animation only; zoom levels, projection, tiles and handlers are unchanged) and clears a stalled pan animation before the arrow-key check. Without this, Leaflet correctly ignores queued zoom and arrow input during a never-ending animation. The checks still drive real DOM clicks, keystrokes and events; nothing is stubbed in the app.

## F. Acceptance code checks (grep results)

Search scope: `app.js`, `exploration.js`, `map.js`, `map-crs.js`, `sector.js`, `sector-layers.js`, `geo.js`, `mission.js`, `pathfinding.js`, `datasets.js`, `styles.css`, `index.html`.

| Pattern | Result |
| --- | --- |
| `transform` | 3 hits, all in `map-crs.js`: the CRS `L.Transformation` definition and its comments. No CSS-transform pan/zoom. |
| `translate(` | no match |
| `scale(` (CSS) | 1 hit: `L.control.scale(...)`, the Leaflet scale bar |
| `getBoundingClientRect` | no match |
| `style.left` / `style.top` | no match |
| `latLngToPoint`, `latLngToLayerPoint`, `.project(`, `.unproject(`, `toPoint(` | no match |
| `* 256` / `/ 256` | no match |

Honest exception: `browser-test.html` (test code, not application code) does use `getBoundingClientRect` and `latLngToContainerPoint` to measure whether Leaflet's rendered output matches its own projection. That is the measurement the acceptance criterion asks for; it is not map positioning. `geo.js` contains `tileIndex(lon, lat, level)`, which is tile-matrix arithmetic for the download script and readouts, explicitly allowed by the task; it does not convert to screen pixels.

## G. Node tests and syntax

`npm test` → **22 passed, 0 failed** (`pathfinding.test.js` 8, `mission.test.js` 5, `geo.test.js` 9). `node --check` passes on every root `.js` file and both `scripts/*.mjs` files.

## H. Layout

Headless Edge screenshots inspected at 1280 px and at a 360 px iframe: one column on narrow screens, no horizontal overflow, the map, route and all four markers visible. The view now fits the sector bounds on load and on reset, so a narrow screen does not clip the Hab; on desktop this lands on zoom 12.

## I. Decisions and deviations

- **Default view fits the sector instead of a fixed zoom.** A fixed zoom 12 clipped the Hab at 360 px. `fitSector()` uses `fitBounds` with `maxZoom: 12`, so desktop stays at the verified native level 12 and narrow screens drop to 11.5.
- **Tiles restructured by level.** The old flat `assets/trek/{row}-{col}.png` names could not express three levels; files are now `{level}/{row}-{col}.png`. The manifest records the level.
- **Marker tolerance 1.5 px, not 1 px.** Leaflet rounds marker positions to whole pixels, so the observed worst case is 1.00 px. The check reports the measured value instead of claiming sub-pixel accuracy.
- **One tile failure probe.** `probeTileError()` adds a deliberately missing tile layer for 800 ms so the error path can be exercised deterministically; the app's own tileerror handler is unchanged.
- **Deleted tiles.** The unused level-10 block from Task 0 was removed rather than kept, because serving it would add ~1 MB with no sector coverage.

## J. Limits (not verified)

- No touch device, screen reader or assistive-technology run. Keyboard behaviour was exercised with synthetic events in headless Edge.
- No public deployment, HTTP/MIME or private-window check.
- Imagery is preliminary CTX; registration rests on the tile matrix alone. The sector, Hab, stops, grid, hazard and costs are SIMULATED, and no elevation, slope or terrain data exists.
- Zoom beyond level 12 enlarges level-12 imagery; the UI says so. Between 12 and 12.5 on narrow screens the map shows native tiles at a smaller scale.
