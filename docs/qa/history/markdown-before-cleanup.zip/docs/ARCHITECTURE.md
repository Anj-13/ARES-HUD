# ARES-HUD architecture

## Part A: Current implementation

The owner's React migration request authorizes a Vite build while preserving a statically hosted application. [STATUS.md](../STATUS.md) alone records acceptance. The [previous architecture](ARCHITECTURE_PRE_REACT.md) and all older QA reports are historical snapshots.

| Location | Responsibility |
| --- | --- |
| `index.html`, `src/main.jsx`, `src/App.jsx` | Vite/React mission entry, supplied navigation and dialogs |
| `tablet.html`, `src/tablet-main.jsx` | Independent tablet entry, hash changes and invalid-plan UI |
| `src/components/` | Supplied MissionPanel, MapPanel, TelemetryPanel, Timeline, TabletView, SourcesView and Modal |
| `src/state/mission-store.js` | One authoritative desktop input store; derive route, before-dust comparison, metrics, timeline/recon and handoff inputs |
| `src/domain/pathfinding.js`, `mission.js` | Original deterministic A*, multi-leg accumulation and ordering; no Leaflet or React imports |
| `src/domain/geo.js`, `map-crs.js`, `sector.js` | Original Mars sphere, pure grid/coordinate arithmetic and hypothetical operating area |
| `src/domain/plan.js` | Original schema/checksum/base64url input-only snapshot validation |
| `src/domain/sols.js`, `fog.js` | Original eight-Sol cost interpolation and simulated knowledge/uncertainty |
| `src/domain/datasets.js` | Original verified NASA/USGS source records with corrected current tile/registration description |
| `src/integrations/map.js`, `sector-layers.js` | Original Leaflet factory and grid/hazard/route/marker builders with updated imports |
| `src/integrations/use-mission.js` | React subscription and timer lifecycle; cleanup clears playback interval |
| `src/integrations/tablet-bridge.js` | Validate a received plan and create an independent store that recomputes A* |
| `src/styles/main.css` | Supplied UI styling plus original map marker styles and scoped integration/accessibility additions |
| `public/assets/`, `public/vendor/` | Original NASA/USGS files and locally vendored Leaflet 1.9.4/license |
| `scripts/prepare-public.mjs` | Copy current provenance and runtime licenses into static production assets |
| `tests/`, `scripts/*qa.mjs`, `docs/qa/` | Original/new Node tests, browser regression drivers and durable evidence |
| `legacy/` | Recoverable original implementation, original browser harness, assets, tests, older UI and initial snapshots |

State changes flow from native React controls into the mission store, then through the original pure engines into a stable immutable snapshot read with `useSyncExternalStore`. There is one desktop store and an intentionally isolated validated tablet snapshot store. The tablet has no dependency on desktop result objects or metrics. Planner actions leave timeline preview; handoff pauses without enabling preview and sends inputs from the reached cell. Reset restores the initial desktop scenario or received tablet snapshot.

Leaflet exclusively owns surface projection, tiles, keyboard/touch, pan/zoom, scale and attribution. MapPanel creates it once per mount, updates overlays independently, observes container resizing and removes the map on cleanup. Fullscreen and Globe keep that same instance. Size changes call `invalidateSize()` and restore the captured geographic view to avoid fractional-pixel coordinate drift. There is no CSS-transform map navigation or second projection. Fog uses unfilled planning-cell outlines; observed imagery is never treated as unknown. Routes have no straight-line fallback when A* fails.

Vite builds two entries with relative URLs. Runtime files are under `dist/`, including local imagery, Leaflet, source notes and licenses. Build tooling is absent from the runtime. `serve.py` and the Node static server are optional local tools. The development-only browser hooks are removed by the production build.

## Part B: Planned / gated

The Globe button remains a placeholder. No 3D renderer, new globe dataset, numerical elevation or terrain-based safety inference is integrated. Those retain their separate verification and owner gates. QR, synchronization, real-time telemetry, backend services and account flows are absent. Public-host and physical-device verification remain outstanding; see [STATUS.md](../STATUS.md).
